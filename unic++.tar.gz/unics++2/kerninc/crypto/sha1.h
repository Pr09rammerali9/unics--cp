#ifndef CRYPTO_SHA1_H
#define CRYPTO_SHA1_H

#include "../lib/bit/int.h"
#include "../lib/types.h"
#include "../lib/def.h"
#include "../lib/mem.h"

typedef struct {
    uint32_t stat[5]; //i was going to dare to make this uint64_t 
    uint32_t count[2];

    uchar buf[64];
} sha1_ctx;

void sha1_init(sha1_ctx *contxt);
void sha1_trans(uint32_t stat[5], uchar buf[64]);
void sha1_upd(sha1_ctx *contxt, const uchar *dat, uint32_t len);
void sha1_final(uchar digset[20], sha1_ctx *contxt);
void sha1_hash(str hash_out, const str s, uint32_t len);

#endif 
