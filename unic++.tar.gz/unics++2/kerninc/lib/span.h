#ifndef SPAN_H
#define SPAN_H

#include "def.h"

typedef struct {
    void *p;

    size_t count;
    size_t elem_size;
} span_t;

static inline span_t mk_span(void *p, size_t count, size_t elem_size) {
    span_t s;
    s.p = p;
    s.count = count;
    s.elem_size = elem_size;

    return s;
}

#endif
