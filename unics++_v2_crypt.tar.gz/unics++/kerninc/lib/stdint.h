#ifndef STDINT
#define STDINT 

typedef __uint8_t u8_t;
typedef __int8_t i8_t;
typedef __uint16_t u16_t;
typedef __int16_t i16_t;
typedef __int32_t i32_t;
typedef __uint32_t u32_t;
typedef __int64_t i64_t;
typedef __uint64_t u64_t;
typedef __uint128_t u128_t;
typedef __int128_t i128_t;

#endif
