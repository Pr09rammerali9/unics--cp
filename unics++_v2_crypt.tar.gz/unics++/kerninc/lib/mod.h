#ifndef MOD_H
#define MOD_H

typedef _BitInt(8) int8_t;

typedef int8_t (*initfn)(void);
typedef void (*exitfn)(void);

#define sec(s) __attribute__((section(s)))
#define used __attribute__((__used__))

#define __init sec(".init.text") used
#define __init_dat sec(".init.data") used
#define __init_rodat sec(".init.rodata") used
#define __init_bss sec(".init.bss") used
#define __exit sec(".exit.text") used
#define __exit_dat sec(".exit.data") used
#define __exit_rodat sec(".exit.rodata") used 
#define __exit_bss sec(".exit.bss") used

#define __early_init sec("init_early.text") used
#define __late_init sec(".init_late.text") used
#define __early_exit sec(".exit_early.text")
#define __late_exit sec(".exit_late.text")

#define mod_init(fn) \
     static initfn mod_init_##fn __init = &fn
#define mod_exit(fn) \
     static exitfn mod_exit##fn __exit = &fn
#define early_mod_init(fn) \
     static initfn mod_inite##fn __early_init = &fn
#define late_mod_init(fn) \
     static initfn mod_initl##fn __late_init = &fn
#define early_mod_exit(fn) \
     static exitfn mod_exite##fn __early_exit = &fn
#define late_mod_exit(fn) \
     static exitfn mod_exitl##fn __late_exit = &fn

#endif
