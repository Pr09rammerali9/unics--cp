#ifndef ARG_H
#define ARG_H

typedef __builtin_va_list va_list;

#define va_start(ap, last) __builtin_va_start(ap, last)
#define va_arg(ap, t) __builtin_va_arg(ap, t)
#define va_cpy(dest, src) __builtin_va_copy(dest, src)
#define va_end(ap) __builtin_va_end(ap)

#define __cdecl __attribute__((cdecl))
#define __stdcall __attribute((stdcall))

#endif
