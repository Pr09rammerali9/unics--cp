#include <crypto/sha1.h>
#include <lib/bit/ops.h>
#include <lib/end/utils.h>

typedef union {
    uchar c[64];
    
    ulong l[16];
} ch64_lng16;


