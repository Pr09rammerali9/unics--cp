#ifndef SYS_COROUTINE
#define SYS_COROUTINE

#include "../lib/bit/int.h"
#include "../lib/alloc.h"
#include "../lib/mem.h"
#include "jmp.h"

typedef unsigned _BitInt(2) kcoro_stat_t;

typedef struct kcoro_t {
    kcoro_stat_t stat;

    size_t stk_base;

    uint8_t stk_sz; //In KBs

    uint16_t id;

    kcoro_t *prev,
            *next;
} kcoro_t;

typedef struct {
    void (*init)(kcoro_t *coro);

    kcoro_t (*spawn)(void (*fn));

    void (*yield)(void);
    void (*kill)(kcoro_t *coro);
    unsigned _BitInt(2) (*stat)(kcoro_t *coro);
} __sys_coro_t;

#ifndef CR_SRC_IMPL

extern __sys_coro_t sys_coroutine;

#endif

#endif
