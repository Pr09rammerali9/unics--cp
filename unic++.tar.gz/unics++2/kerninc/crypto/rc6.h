#ifndef RC6_H
#define RC6_H

#include "../lib/def.h"
#include "../lib/mem.h"
#include "../lib/bit/int.h"
#include "../lib/bit/ops.h"

#define RC6_ROUNDS 20
#define RC6_BLK_SIZE 16
#define RC6_KEY_MIN_LEN 16
#define RC6_KEY_MAX_LEN 32

void rc6_key_schedule(const uint8_t* key, size_t key_len);
void rc_encyrpt(uint32_t *blk);
void rc_decyrpt(uint32_t *blk);

#endif
