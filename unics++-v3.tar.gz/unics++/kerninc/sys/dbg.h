#ifndef SYS_UART_H
#define SYS_UART_H

#ifdef _X86_

#include "../arch/uart.h"

#define klogch(c) arch_uart_wr(c)
#define klogs(c) arch_uart_puts(c)
#define klogr() arch_uart_rd()

#endif  

#define DBLVL_LOG 0b000
#define DBLVL_DB 0b001
#define DBLVL_WARN 0b010
#define DBLVL_ERR 0b011
#define DBLVL_EMERG 0b100
#define DBLVL_ALERT 0b101
#define DBLVL_INFO 0b110
#define DBLVL_PANIC 0b111

typedef struct {
    void (*klogf)(const char *,...);
    void (*klogrf)(const char *,...);

    int (*kprintdb)(_BitInt(3), const char *,...);
} __sysdbgt_ns;

#ifndef DB_SRC_IMPL

extern const __sysdbg_ns sys_dbg;

#endif

#endif
