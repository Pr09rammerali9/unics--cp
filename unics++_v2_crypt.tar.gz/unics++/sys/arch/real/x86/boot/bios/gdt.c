#include "gdt.h"

static uint64_t gdt_entry(uint32_t base, uint32_t limit, uint8_t access, uint8_t granularity) {
    uint64_t descriptor = 0;
    descriptor = INSERT_BITS(descriptor, limit, 0, 16);
    descriptor = INSERT_BITS(descriptor, limit >> 16, 48, 4);
    descriptor = INSERT_BITS(descriptor, base, 16, 16);
    descriptor = INSERT_BITS(descriptor, base >> 16, 32, 8);
    descriptor = INSERT_BITS(descriptor, base >> 24, 56, 8);
    descriptor = INSERT_BITS(descriptor, access, 40, 8);
    descriptor = INSERT_BITS(descriptor, granularity, 52, 4);
    return descriptor;
}

static gdtd gdt_arr[3] = {0};
static gdt_ptr gdtr;

typedef struct {
    uint32_t base;
    uint32_t limit;
    uint8_t access;
    uint8_t granularity;
} gdt_config;

void init_gdt() {
   
    const gdt_config *gdt_cfg = (const gdt_config[]){
        {0, 0, 0, 0},
        {0, 0xFFFFF, 0x9A, 0xC},
        {0, 0xFFFFF, 0x92, 0xC}
    };
    
    for (int i = 0; i < 3; i++) {
        gdt_arr[i] = gdt_entry(gdt_cfg[i].base, gdt_cfg[i].limit, gdt_cfg[i].access, gdt_cfg[i].granularity);
    }
    
    gdtr.limit = sizeof(gdt_arr) - 1;
    gdtr.base = (uint32_t)gdt_arr;
    
    __asm__ volatile("lgdt %0" 
        : 
        : "m"(gdtr)
    );

}

/*optional:
 * author:Pr09rammerali9
 * module:gdt.c
 * description:the global descriptor table source code
 * version:0.0.1
 * license:0BSD
 */
