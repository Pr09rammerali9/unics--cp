#include <crypto/chacha8.h>

static const uint32_t sigma[4] = {
    0x61707865,
    0x3320646e,
    0x79622d32,
    0x65746b20
};

static inline void chacha_quarter_round(uint32_t *a, uint32_t *b, uint32_t *c, uint32_t *d) {
    *a += *b;
    *d ^= *a;
    *d = ROTATE_LEFT(*d, 16);

    *c += *d;
    *b ^= *c;
    *b = ROTATE_LEFT(*b, 12);
    
    *a += *b;
    *d ^= *a;
    *d = ROTATE_LEFT(*d, 8);
    
    *c += *d;
    *b ^= *c;
    *b = ROTATE_LEFT(*b, 7);
}

void chacha_init(chacha_state_t *state, const chacha_key_t *key, const chacha_nonce_t *nonce, uint32_t counter) {
    
    state->state[0] = sigma[0];
    state->state[1] = sigma[1];
    state->state[2] = sigma[2];
    state->state[3] = sigma[3];

    memcpy(&state->state[4], key->key, CHACHA_KEY_SIZE);

    state->state[12] = counter;
    state->state[13] = nonce->nonce[0];
    state->state[14] = nonce->nonce[1];
    state->state[15] = nonce->nonce[2];
}

void chacha8_blk(chacha_state_t *state, uint32_t *out_blk) {

    chacha_state_t working_state;

    memcpy(working_state.state, state->state, CHACHA_STATE_SIZE);

    for (int i = 0; i < 4; ++i) {
        chacha_quarter_round(&working_state.state[0], &working_state.state[4], &working_state.state[8], &working_state.state[12]);
        chacha_quarter_round(&working_state.state[1], &working_state.state[5], &working_state.state[9], &working_state.state[13]);
        chacha_quarter_round(&working_state.state[2], &working_state.state[6], &working_state.state[10], &working_state.state[14]);
        chacha_quarter_round(&working_state.state[3], &working_state.state[7], &working_state.state[11], &working_state.state[15]);
        chacha_quarter_round(&working_state.state[0], &working_state.state[5], &working_state.state[10], &working_state.state[15]);
        chacha_quarter_round(&working_state.state[1], &working_state.state[6], &working_state.state[11], &working_state.state[12]);
        chacha_quarter_round(&working_state.state[2], &working_state.state[7], &working_state.state[8], &working_state.state[13]);
        chacha_quarter_round(&working_state.state[3], &working_state.state[4], &working_state.state[9], &working_state.state[14]);
    }

    for (int i = 0; i < 16; ++i)
        out_blk[i] = working_state.state[i] + state->state[i];

    state->state[12]++;

}

void chacha8_rng(chacha_state_t *state, uint8_t *dest, size_t len) {

    uint32_t blk[16];
    
    size_t off = 0;

    while (len > 0) {
    
        chacha8_blk(state, blk);
        
        size_t to_cp = (len < CHACHA_BLK_SIZE) ? len : CHACHA_BLK_SIZE;
        
        memcpy(dest + off, blk, to_cp);
        
        off += to_cp;
        
        len -= to_cp;
        
    }

}

