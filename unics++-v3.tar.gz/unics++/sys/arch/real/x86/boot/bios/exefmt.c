#include "exefmt.h"
#include <lib/mem.h>

int lod_kexe(void *img_base, kexe_t *out_exe) {

    kexe_filhdr *raw_hdr = (kexe_filhdr *)img_base;

    if (raw_hdr->mach != 0x014c)
        return 0;

    out_exe->filhdr = raw_hdr;
    out_exe->num_of_sections = (uint32_t)raw_hdr->num_of_sections;

    uint32_t off = sizeof(kexe_filhdr) + raw_hdr->sizeof_optional_hdr;

    out_exe->sechdr = (kexe_sechdr *)((uint8_t *)img_base + off);

    uint8_t *opt_hdr = (uint8_t *)img_base + sizeof(kexe_filhdr);

    out_exe->strt_addr = (void *)(uintptr_t)(*(uint32_t *)(opt_hdr + 16));

    for (uint32_t i = 0; i < out_exe->num_of_sections; i++) {

        kexe_sechdr *sec = &out_exe->sechdr[i];

        if (!sec->vaddr)
            continue;

        if (sec->szof_rawdat > 0)
            memcpy((void *)(uintptr_t)sec->vaddr, (uint8_t *)img_base + sec->ptr_to_rawdat, sec->szof_rawdat);

        if (sec->virsz > sec->szof_rawdat)
            memset((void *)(uintptr_t)(sec->vaddr + sec->szof_rawdat), 0, sec->virsz - sec->szof_rawdat);

    }

    if (out_exe->sechdr[0].ptr_to_relocs)
        out_exe->reloc_tbl = (kexe_reloc *)((uint8_t *)img_base + out_exe->sechdr[0].ptr_to_relocs);

    return 0;

}
