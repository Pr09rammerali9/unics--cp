#ifndef LIBMMIO_H
#define LIBMMIO_H

#include "bit/int.h"

#define dir_rdb(addr) (*(volatile uint8_t *)(addr))
#define dir_rdw(addr) (*(volatile uint16_t *)(addr))
#define dir_rdl(addr) (*(volatile uint32_t *)addr) 
#define dir_rdq(addr) (*(volatile uint64_t *)(addr))
#define dir_wrb(addr, val) (*(volatile uint8_t *)(addr) = (val))
#define dir_wrw(addr, val) (*(volatile uint16_t *)(addr) = (val))
#define dir_wrl(addr, val) (*(volatile uint32_t *)(addr) = (val))
#define dir_wrq(addr, val) (*(volatile uint64_t)(addr) = (val))

#endif
