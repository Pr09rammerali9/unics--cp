#ifndef LIBVEN_H
#define LIBVEN_H

typedef uint8_t ven_t;

#define VEN_QCOM 0x00
#define VEN_INTEL 0x01
#define VEN_NIVIDA 0x02
#define VEN_AMD 0x03
#define VEN_STM 0x04
#define VEN_RPI 0x05
#define VEN_ARUDINO 0x06
#define VEN_WDC 0x07
#define VEN_SAMSUNG 0x08
#define VEN_NINTENDO 0x09
#define VEN_HUWAEI 0x0a
#define VEN_HONOR 0x0b
#define VEN_TCL 0x0c
#define VEN_ASUS 0x0d
#define VEN_BROADCOM 0x0e
#define VEN

#endif
