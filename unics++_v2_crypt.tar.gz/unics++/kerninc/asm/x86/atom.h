#ifndef ASM_ATOM_H
#define ASM_ATOM_H

void atom_lock(void);
void atom_unlock(void);

#endif
