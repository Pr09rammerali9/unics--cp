/*works on some fucking compiler*/
#ifndef DEFER_H
#define DEFER_H

#define cleanup(f) __attribute__((cleanup(f)))

#define __DEFER__(fn, var) \
    void (^fn); \
    int var cleanup(fn); \
    void (^fn) = ^(void)
/*__DEFER__ code end*/

#define DEFER1(n) __DEFER__(DFN ## n, DVAR ## n)
#define DEFER2() DEFER1(__COUNTER__)
#define defer DEFER2()

#endif  // DEFER_H
