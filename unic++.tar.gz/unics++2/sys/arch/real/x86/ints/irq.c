#include "irq.h"

static void (*irq_fns[16])(regs_t *);

void irq_install(uint8_t irq, void (*handler)(regs_t *)) {

    if (irq >= 0 && irq <= 16)
        irq_fns[irq] = handler;

}

void irq_uninstall(uint8_t irq) {

    if (irq >= 0 && irq <= 16)
        irq_fns[irq] = NULL;

}

/*optional:
 * author:Pr09rammerali9
 * module:irq.c
 * description:an interrupt request driver
 * version:0.0.1
 * license:0BSD
 */
