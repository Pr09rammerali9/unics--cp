#ifndef TIMER_H
#define TIMER_H

#include "irq.h"
#include "pic.h"

void timer_init(uint32_t pit_freq, uint32_t freq);
void get_ticks(void);

#endif
