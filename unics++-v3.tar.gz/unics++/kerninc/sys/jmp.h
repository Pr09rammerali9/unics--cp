#ifndef SYSJMP_H
#define SYSJMP_H

#if defined(__i386__) || defined(__i686__)

#include "../arch/jmp.h"

#define klongjmp(x, y) arch_longjmp(x, y)
#define ksetjmp(x) arch_setjmp(x)

#endif

#endif
