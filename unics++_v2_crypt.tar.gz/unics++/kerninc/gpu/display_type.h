#ifndef DISPLAY_TYPE
#define DISPLAY_TYPE

typedef enum {
    DPTY_HDMI,
    DPTY_VGA,
    DPTY_DP,
    DPTY_EDP,
    DPTY_NON,
    DPTY_HDBASET,
    DPTY_MICRO_HDMI,
    DPTY_VESA,
    DPTY_SER,
    DPTY_LCD,
    DPTY_SVGA,
    DPTY_OLED,
    DPTY_TOUCH_LCD
} dp_ty;

typedef enum {
    NIVIDA,
    QCOM,
    APPLE,
    GOOGLE,
    AMD,
    INTEL,
    RPI,
    ARUDINO,
    STM,
    SAMSUNG,
    HUWAEI,
    ASUS,
    HONOR,
    NOKIA,
    OTHER
} vendor;  

#endif 
