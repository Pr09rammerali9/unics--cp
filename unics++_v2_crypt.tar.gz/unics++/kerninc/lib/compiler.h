#ifndef COMPILER_H
#define COMPILER_H

#define attr(...) __attribute__((__VA_ARGS__))
#define pack __attribute__((packed))
#define prag(...) _Pragma(#__VA_ARGS__)
#define constructor __attribute__((constructor))
#define deconstructor __attribute__((deconstructor))
#define err(...) _Static_assert(0, __VA_ARGS__)

#ifdef __cplusplus

#define __BEGIN_DECLS extern "C" {
#define __END_DECLS }

#else

#define __BEGIN_DECLS
#define __END_DECLS

#endif

#define __strong_alias(alias, sym) \
    __asm__(".global " #alias "\n" \
            #alias " = " #sym);

#define __P(protos)     protos

#define __CONCAT1(x,y)  x ## y
#define __CONCAT(x,y)   __CONCAT1(x,y)

#define __STRING(x)     #x
#define ___STRING(x)    __STRING(x)

#define __inline __inline__

#define __always_inline __attribute__((__always_inline__))
#define __attribute_const__ __attribute__((__const__))
#define __attribute_pure__ __attribute__((__pure__))
#define __dead __attribute__((__noreturn__))
#define __noreturn __attribute__((__noreturn__))
#define __mallocfunc  __attribute__((__malloc__))
#define __packed __attribute__((__packed__))
#define __returns_twice __attribute__((__returns_twice__))
#define __unused __attribute__((__unused__))
#define __used __attribute__((__used__))
#define __section(s) attr(section(s))
#define __printflike(x, y) __attribute__((__format__(printf, x, y)))
#define __scanflike(x, y) __attribute__((__format__(scanf, x, y)))
#define __strftimelike(x) __attribute__((__format__(strftime, x, 0)))

#define __predict_true(exp)     __builtin_expect((exp) != 0, 1)
#define __predict_false(exp)    __builtin_expect((exp) != 0, 0)

#define __wur __attribute__((__warn_unused_result__))

#define __errorattr(msg) __attribute__((__unavailable__(msg)))
#define __warnattr(msg) __attribute__((__deprecated__(msg)))
#define __warnattr_real(msg) __attribute__((__deprecated__(msg)))


#define usr_addr_spce address_space(4)
#define kern_addr_spce address_space(0)

#define __usr attr(noderef, usr_addr_spce)
#define __kern attr(kern_addr_spce)

#if defined(__clang__) || defined(__llvm__)

#define CC 0xc1a


#elif defined(__gcc__) || defined(__GNUC__)

#define CC 0x9cc

#elifdef __PCC__

#define CC 0xbcc 

#elifdef __CC65__

#define CC 0xcc65 

#endif

#endif
