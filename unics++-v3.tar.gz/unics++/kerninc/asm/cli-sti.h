#ifndef ASM_CLISTI
#define ASM_CLISTI

#if defined(__x86_64__) || defined(__amd64__) || defined(__i386__)

    #define cli() __asm__ __volatile__ ("cli"\
    :\
    :\
    : "memory"\
    )
    #define sti() __asm__ __volatile__ ("sti"\
    :\
    :\
    : "memory"\
    )

#elif defined(__aarch64__)

    #define cli() __asm__ __volatile__ ("msr daifset, #2"\
    :\
    :\
    : "memory"\
    )

    #define sti() __asm__ __volatile__ ("msr daifclr, #2"\
    :\
    :\
    : "memory"\
    )

#elif defined(__arm__)

    #define cli() __asm__ __volatile__ (\
        "mrs r0, cpsr \n"\
        "orr r0, r0, #0x80 \n"\
        "msr cpsr_c, r0"\
        :\
        :\
        : "r0", "memory"\
    )

    #define sti() __asm__ __volatile__ (\
        "mrs r0, cpsr \n"\
        "bic r0, r0, #0x80 \n"\
        "msr cpsr_c, r0"\
        :\
        :\
        : "r0", "memory"\
    )

#elif defined(__mips__)

    #define cli() __asm__ __volatile__ (\
        "mfc0 $k0, $12 \n"\
        "andi $k0, 0xFFFE \n"\
        "mtc0 $k0, $12"\
        :\
        :\
        : "$k0", "memory"\
    )

    #define sti() __asm__ __volatile__ (\
        "mfc0 $k0, $12 \n"\
        "ori $k0, 0x0001 \n"\
        "mtc0 $k0, $12"\
        :\
        :\
        : "$k0", "memory"\
    )

#elif defined(__riscv)

    #define cli() __asm__ __volatile__ ("csrrc zero, mstatus, 8"\
    :\
    :\
    : "memory"\
    )

    #define sti() __asm__ __volatile__ ("csrrs zero, mstatus, 8"\
    :\
    :\
    : "memory"\
    )

#elif defined(__pdp11__)

    #define cli() __asm__ __volatile__ ("mtps #7"\
    :\
    :\
    : "memory"\
    )

    #define sti() __asm__ __volatile__ ("mtps #0"\
    :\
    :\
    : "memory"\
    )

#elif defined(__65C816__)
    #define cli() __asm__ __volatile__ ("sei"\
    :\
    :\
    : "memory"\
    )

    #define sti() __asm__ __volatile__ ("cli"\
    :\
    :\
    : "memory"\
    )

#else

#error "Interrupt control macros (cli/sti) are not defined for this architecture."

#endif

#endif
