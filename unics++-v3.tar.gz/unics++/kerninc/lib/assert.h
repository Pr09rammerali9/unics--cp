#ifndef ASSERT_H
#define ASSERT_H

#include "def.h"
#include "abort.h"

#ifndef NDEBUG 

#define assert(expr, fn, ...) do {\
    if (!(expr)) {\
            fn(__VA_ARGS__); \
    } \
} while(0)

#define aassert(e) assert(e, abort)

#endif

#define bld_bug_on(e) ((void)sizeof(char[1 - 2 * !!e]))

#endif
