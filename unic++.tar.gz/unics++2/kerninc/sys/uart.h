#ifndef SYS_UART_H
#define SYS_UART_H

#ifdef _X86_

#include "../arch/x86/uart.h"

#define klogch(c) uart_wr(c)
#define klogs(c) uart_puts(c)

#endif

#endif
