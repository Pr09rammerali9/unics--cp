#ifndef _ASM_PAUSE_H
#define _ASM_PAUSE_H

/*sometimes, we risk our style for saving some space in compression and shorter writing, man i feel guility*/

#if defined(__x86_64__) || defined(__amd64__) || defined(__i386__)

    #define __asm_pause() __builtin_ia32_pause()

#elif defined(__aarch64__) || defined(__arm__)

    #define __asm_pause() __asm__ __volatile__("yield" ::: "memory")

#elif defined(__powerpc__) || defined(__ppc__)

    #define __asm_pause() __asm__ __volatile__("pause" ::: "memory")

#elif defined(__mips__)

    #define __asm_pause() __asm__ __volatile__("pause" ::: "memory")

#elif defined(__riscv)

    #define __asm_pause() __asm__ __volatile__("nop" ::: "memory")

#elif defined(__ia64__)

    #define __asm_pause() __asm__ __volatile__("hint @pause" ::: "memory")

#elif defined(__pdp11__)

    #define __asm_pause() __asm__("nop" ::: "memory")

#elif defined(__65C816__)

    #define __asm_pause() __asm__("nop" ::: "memory")

#else
 
    #define __asm_pause() __asm__("" ::: "memory")

#endif

#define pause() __asm_pause()

#endif
