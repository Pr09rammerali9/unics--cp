#ifndef END_UTILS_H
#define END_UTILS_H

#include "../compiler.h"
#include "../bit/compiler.h" 
#include "../bit/int.h"      
#include "../mem.h"          

#ifdef LILEND
#define __htobe16(x) __swp16(x)
#define __htobe32(x) __swp32(x)
#define __htobe64(x) __swp64(x)

#define __htole16(x) (x)
#define __htole32(x) (x)
#define __htole64(x) (x)

#else
#define __htobe16(x) (x)
#define __htobe32(x) (x)
#define __htobe64(x) (x)

#define __htole16(x) __swp16(x)
#define __htole32(x) __swp32(x)
#define __htole64(x) __swp64(x)
#endif 

#ifdef PDPEND

static attr(__always_inline__) uint32_t __htopdp32(uint32_t x) {

    return ((x & UINT32_C(0xFFFF0000)) >> 16) | ((x & UINT32_C(0x0000FFFF)) << 16);

}

static attr(__always_inline__) uint64_t __htopdp64(uint64_t x) {

    uint32_t hi = (uint32_t)(x >> 32);
    uint32_t lo = (uint32_t)x;
    uint32_t pdp_hi = __htopdp32(hi);
    uint32_t pdp_lo = __htopdp32(lo);
    
    return ((uint64_t)pdp_lo << 32) | pdp_hi;

}

#define __htopdp16(x) (x) 

#else
#define __htopdp32(x) (x) 
#define __htopdp16(x) (x)
#define __htopdp64(x) (x)
#endif

#define __le16toh(x) __htole16(x)
#define __le32toh(x) __htole32(x)
#define __le64toh(x) __htole64(x)

#define __be16toh(x) __htobe16(x)
#define __be32toh(x) __htobe32(x)
#define __be64toh(x) __htobe64(x)

#endif

