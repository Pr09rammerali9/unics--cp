#ifndef BOOTFS_H
#define BOOTFS_H

#include <lib/bit/int.h>

#define LFS_MAG 0x4C494C21
#define LFS_BLK_SZ 4096

typedef struct {
    uint32_t mag,
             ver,
             blk_sz,
             blk_count,
             root_addr,
             free_ptr,
             flgs;

    char vol_name[15];
} bootfs_super;

typedef struct {
    uint16_t mod,
             nlinks;

    uint32_t uid,
             gid,
             sz,
             atime,
             mtime,
             ctime,
             addr[10],
             chksum;
} bootfs_inode;

typedef struct {
    uint32_t inode_num;

    char name[28];
} bootfs_dirent;

int bootfs_mount(const char *dev);
int bootfs_fmt(const char *dev, bootfs_super *cfg);
int bootfs_rd(uint32_t inum, bootfs_inode *inode);
int bootfs_wr(uint32_t inim, bootfs_inode *inode);
int bootfs_lookup(const char *name);

#endif
