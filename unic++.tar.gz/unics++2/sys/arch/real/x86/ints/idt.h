#ifndef IDT_H
#define IDT_H

#include <lib/bit/int.h>
#include <lib/mem.h>
#include <lib/compiler.h>

typedef struct {
    uint16_t base_low;
    uint16_t seg_sel;

    uint8_t resrved;
    uint8_t flgs;

    uint16_t base_high;
} __packed idt_t;

typedef struct {
    uint32_t limit;

    uint16_t base;
} __packed idt_ptr;

void idt_init(void);

#endif
