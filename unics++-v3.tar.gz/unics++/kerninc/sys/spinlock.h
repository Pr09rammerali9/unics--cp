#ifndef SYS_SPINLOCK_H

#define SYS_SPINLOCK_H

#include "../asm/cli-sti.h"
#include "../asm/regs.h"
#include "../lib/atomic.h"
#include "../lib/mem.h"

typedef struct {
    _Atomic volatile bool state;

    asm_regs regs;
} spinlock_t;

typedef struct {
    void (*init)(spinlock_t *lock);
    void (*lock)(spinlock_t *lock, bool intr);
    void (*unlock)(spinlock_t *lock, bool intr);
} __sysspinlock_t;

#ifndef SL_SRC_IMPL

extern const __sysspinlock_t sys_spinlock;

#endif

#endif
