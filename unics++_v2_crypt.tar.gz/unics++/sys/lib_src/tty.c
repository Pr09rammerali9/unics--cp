#define TTYSRC
#include <lib/tty.h>
#include <lib/export.h>

static void scroll(vt_t *vt) {

    memmove(vt->buf, vt->buf + vt->cols, (vt->rows - 1) * vt->cols * sizeof(vt_ch));
    
    memset(vt->buf + (vt->rows - 1) * vt->cols, 0, vt->cols * sizeof(vt_ch));
}

static void advance_cursor(vt_t *vt) {
    
    vt->cur_col++;
    
    if (vt->cur_col >= vt->cols) {
    
        vt->cur_col = 0;
        vt->cur_row++;
        
        if (vt->cur_row >= vt->rows) {
        
            vt->cur_row = vt->rows - 1;
            
            scroll(vt);

        }

    }

}

static void handle_char(vt_t *vt, char c) {

    if (c == '\n') {

        vt->cur_col = 0;
        vt->cur_row++;
        
        if (vt->cur_row >= vt->rows) {
        
            vt->cur_row = vt->rows - 1;
            
            scroll(vt);

        }

    } else if (c == '\b') {

        if (vt->cur_col > 0)
            vt->cur_col--;
        else if (vt->cur_row > 0) {

            vt->cur_row--;
            
            vt->cur_col = vt->cols - 1;

        }

        vt->buf[vt->cur_row * vt->cols + vt->cur_col].c = ' ';

    } else {

        vt->buf[vt->cur_row * vt->cols + vt->cur_col].c = c;

        advance_cursor(vt);

    }

}

void *vt_init(vt_t *vt, size_t rows, size_t cols) {

    vt->rows = rows;
    vt->cols = cols;
    vt->cur_col = 0;
    vt->cur_row = 0;
    vt->handler = NULL;

    size_t size = rows * cols * sizeof(vt_ch);
    
    vt->buf = (vt_ch *)palloc(size);
    
    if (!vt->buf)
        return NULL;

    memset(vt->buf, 0, size);

    return vt->buf;

}

EXPORT(vt_init);

void vt_uninit(vt_t *vt) {

    if (vt->buf) {

        pfree(vt->buf);
        
        vt->buf = NULL;

    }

}

EXPORT(vt_uninit);

void vt_putch(vt_t *vt, char c, uint8_t clr) {

    handle_char(vt, c);

    vt->buf[vt->cur_row * vt->cols + vt->cur_col - 1].clr = clr;

    if (vt->handler)
        vt->handler(vt);
}

EXPORT(vt_putch);

void vt_putstr(vt_t *vt, const char *s, uint8_t clr) {

    for (size_t i = 0; i < strlen(s); i++) {
        
        handle_char(vt, s[i]);

        if (s[i] != '\n' && s[i] != '\b')
            vt->buf[vt->cur_row * vt->cols + vt->cur_col - 1].clr = clr;    

    }

    if (vt->handler)
        vt->handler(vt);

}

EXPORT(vt_putstr);
