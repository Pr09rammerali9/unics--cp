#ifndef ABORT_H
#define ABORT_H

#define abort() do { \
    __builtin_trap();\
    for (;;);\
} while (0)

#define exit(n) do {\
    if (n != 0) \
        abort(); \
} while (0)

#endif
