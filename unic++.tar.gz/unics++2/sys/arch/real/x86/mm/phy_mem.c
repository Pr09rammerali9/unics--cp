#include <arch/x86/mm.h>
#include <lib/mod.h>
#include <asm/x86/atom.h>
#include <lib/atomic.h>
#include <lib/mem.h>
#include <lib/def.h>
#include <lib/compiler.h>
#include <lib/bit/int.h>
#include <lib/export.h>

extern void st_pgdir(uint32_t val, uint16_t i);
extern uint32_t gt_pgdir(uint16_t i);
extern void atom_lock(void);
extern void atom_unlock(void);

typedef struct {
    uint64_t base_addr;
    uint64_t len;
    
    bool ty;
} mem_regi_t;

extern mem_regi_t mem_map_addr[];
extern uint16_t mem_map_count;

static uint32_t end_addr = 0;
static uint32_t pmm_mx_frme_i = 0;

static uatomic_t pmm_totl_frmes = 0;

static size_t pmm_bm_sz = 0;

static uint8_t *frme_bm = (uint8_t *)0x100000;

static void pmm_st_frme_used(uint32_t fidx) {
    
    size_t byidx = fidx / 8;
    
    uint8_t bitpos = fidx % 8;

    frme_bm[byidx] |= (1 << bitpos);

}

static void pmm_st_frme_free(uint32_t fidx) {
    
    size_t bidx = fidx / 8;

    uint8_t bitpos = fidx % 8;

    frme_bm[bidx] &= ~(1 << bitpos);

}

static int32_t pmm_find_1st_free(void) {
    
    uint32_t mx_frmes = pmm_mx_frme_i;

    for (size_t i = 0; i < pmm_bm_sz; i++) {
    
        if (frme_bm[i] != 0xff) {
        
            for (int j = 0; j < 8; j++) {
            
                uint32_t fidx = (i * 8) + j;

                if (fidx >= mx_frmes)
                    return -1;

                if (!(frme_bm[i] & (1 << j)))
                    return fidx;
            
            }

        }

    }
    
    return -1;

}

static int8_t init_pmm(void) {
    
    uint64_t mx_phy_addr = 0;

    uint32_t totl_usable_frmes = 0;

    uint16_t count = mem_map_count;

    mem_regi_t *map = mem_map_addr;

    for (uint16_t i = 0; i < count; i++) {
        mem_regi_t *r = &map[i];

        if (r->base_addr >= 0x100000000ULL)
            continue;

        uint64_t regi_end = r->base_addr + r->len;

        if (regi_end > 0x100000000ULL)
            regi_end = 0x100000000ULL;

        if (regi_end > mx_phy_addr)
            mx_phy_addr = regi_end;

        if (r->ty == true) {
            uint64_t usable_strt = r->base_addr;
            uint64_t usable_end = r->base_addr + r->len;

            if (usable_strt < 0x1000)
                usable_strt = 0x1000;

            if (usable_end > 0x100000000ULL)
                usable_end = 0x100000000ULL;

            if (usable_end > usable_strt)
                totl_usable_frmes += (uint32_t)((usable_end - usable_strt) / 0x1000);
        
        }

    }

    pmm_mx_frme_i = (uint32_t)(mx_phy_addr / 0x1000);

    pmm_bm_sz = pmm_mx_frme_i / 8;

    atomic_store(&pmm_totl_frmes, totl_usable_frmes);
   
    memset(frme_bm, 0xff, pmm_bm_sz);

    for (uint16_t i = 0; i < count; i++) {
        
        mem_regi_t *r = &map[i];

        if (r->base_addr >= 0x100000000ULL) 
            continue;

        if (r->ty != true) 
            continue;

        uint32_t strt_fidx = (uint32_t)(r->base_addr / 0x1000);
        
        uint64_t end_addr_regi = r->base_addr + r->len;

        if (end_addr_regi > 0x100000000ULL)
            end_addr_regi = 0x100000000ULL;
        
        uint32_t end_fidx = (uint32_t)(end_addr_regi / 0x1000);
        
        for (uint32_t j = strt_fidx; j < end_fidx; j++)
            pmm_st_frme_free(j);

    }
    
    uint32_t reserve_end_bytes = end_addr;
    
    if ((uint32_t)frme_bm + pmm_bm_sz > reserve_end_bytes)
        reserve_end_bytes = (uint32_t)frme_bm + pmm_bm_sz;

    uint32_t init_reserve_frames = (reserve_end_bytes + 0x1000 - 1) / 0x1000;

    for (uint32_t i = 0; i < init_reserve_frames; i++)
        pmm_st_frme_used(i);
    
    return 0;

}

void pmm_st(uint32_t kern_end_addr) {

    end_addr = kern_end_addr;

}

void *pgalloc(void) {

    atom_lock();

    int32_t fidx = pmm_find_1st_free();

    if (fidx == -1) {
        
        atom_unlock();
    
        return NULL;
    
    }

    pmm_st_frme_used(fidx);

    atom_unlock();
    
    return (void *)((uint32_t)fidx * 0x1000);

}

EXPORT(pgalloc);

void pgfree(void *p_addr) {

    uint32_t phy_addr = (uint32_t)p_addr;
    
    uint32_t fidx = phy_addr / 0x1000;
    
    if ((phy_addr % 0x1000) != 0 || phy_addr >= (pmm_mx_frme_i * 0x1000))
        return; 

    atom_lock();
    
    pmm_st_frme_free(fidx);
    
    atom_unlock();
}

EXPORT(pgfree);

early_mod_init(init_pmm)
