#ifndef LIB_FB_UTILS_H
#define LIB_FB_UTILS_H

#include "../lib/bit/int.h"
#include "../lib/def.h"
#include "display_type.h"

typedef struct {
    uint25_t **fb;

    size_t x,
           y;
    size_t sz_x,
           sz_y;
} fb_t;

typedef struct {
    fb_t fb;

    size_t height,
           width;

    char *title;

    dp_ty ty;
} win_t;

void fb_init(fb_t *fb, size_t x, size_t y);
void win_init(win_t *win, const char *name, size_t height, size_t width);
void fb_putpix(fb_t *fb, size_t x, size_t y, uint24_t clr);
void fb_des(fb_t *fb);
void fb_clr(uint24_t clr);
void fb_putch(uint24_t bg_clr,uint24_t fg_clr, const char c);
void win_mv(win_t *w, size_t nx, size_t ny);
void win_border(win_t *w, uint31_t clr, size_t thickness);
void win_redrw(win_t *w);

#endif 
