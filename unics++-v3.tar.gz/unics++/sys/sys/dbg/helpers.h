#ifndef PRDB_HELPERS_H
#define PRDB_HELPERS_H

inline static spinlock_t fmtlk;

static inline int __prdb_vscprf(char *b, size_t sz, const char fm[], va_list a) {

    sys_spinlock->lock(&fmtlk, true);

    int ret = vscnprintf(b, sz, fm, a);

    sys_spinlock->unlock(&fmtlk);

    return ret;

}

#endif
