#ifndef NS_H
#define NS_H

#define NS_FN(ret_type, fn, args) ret_type (*fn)args;
#define NS_OBJ(obj, type) type obj;
#define NS_CREAT(name, ...) \
    typedef struct { \
        ##__VA_ARGS__ \
    } name;

#endif
