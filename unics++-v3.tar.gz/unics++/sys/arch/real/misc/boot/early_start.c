#include "pdt.h"
#include "end.h"
#include "cons.h"
void early_start(void) {

    init_pdt();
    set_end('l'); /* Little Endiannes */
#ifdef TEXT_MOD
    con->init(TXTMOD, 80, 25)
#elifdef GUIMOD
    con->init(GUIMOD, MAX_RES);
#endif
    export_tokern();

    kmain();

}
