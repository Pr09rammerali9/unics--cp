#ifndef SYS_TYPES_H
#define SYS_TYPES_H

#include "../../lib/bit/int.h"
#include "../../lib/def.h"
#include "../syscall/args.h"
#include "../../lib/compiler.h"

typedef uint32_t dev_t;

typedef struct __packed {
    
    int devfd;
    
    size_t dargs[4];
}

typedef struct __packed {
    char name[7];
 
    uint32_t ven_id;
    uint32_t dev_id;

    uint8_t flgs;
    
    dev_t dependencies[4];
    dev_t drvr_id;

    uint8_t (*init_dev)(dev_args_t *args);
    uint8_t  (*exit_dev)(void);

    int (*open)(OPEN_ARGS,...);
    ssize_t (*write)(RDWR_ARGS);
    ssize_t (*read)(RDWR_ARGS);
    int (*close)(int fd);
    int (*ioctl)(int fd, int req,...);
    int (*fcntl)(int fd, int cmd,...);
    void *(*mmap)(void *addr, size_t len, int prot, int flgs, off_t off);
    off_t (*lseek)(int fd, off_t off, int whence);

} device;

#endif 
