#ifndef GUARD_H
#define GUARD_H

#define guard(condition, action) \
    if (!(condition)) { \
        action; \
    }

#endif // GUARD_H

