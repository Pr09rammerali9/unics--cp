#include <lib/str.h>
#include <lib/export.h>

char *strdup(AARGS const char s[]) {

    if (!s || !flavor_alloc)
        return NULL;

    size_t len = strlen(s) + 1;

    char *ns = flavor_alloc(len);

    if (!ns)
        return NULL;

    strcpy(ns, s);

    return ns;
}

EXPORT(strdup);
