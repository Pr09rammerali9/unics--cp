#ifndef SYSKERN_H
#define SYSKERN_H

typedef struct {
    void (*panic)(const char *s);
    void (*panicfmt)(const char *fmt,...);

} __syskern_api;

#ifndef SRC_IMPL

extern const __syskern_api syskern;

#endif

#endif
