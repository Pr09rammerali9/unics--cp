#ifndef SYS_SYSCALL_ARGS_H
#define SYS_SYSCALL_ARGS_H

#include "../../lib/types.h"
#include "../../lib/compiler.h"

#define OPEN_ARGS const char *path, int flags
#define RDWR_ARGS int fd, void __user *buf, size_t len
#endif 
