#ifndef END_DEFS_H
#define END_DEFS_H

#include "../compiler.h"
#include "../bit/compiler.h"


#if CC == 0xbcc

#if __TARGET_ENDIAN__ == __PDP_ENDIAN__

#define PDPEND

#endif

#endif

#endif
