#ifndef LS_H
#define LS_H

#include "any.h"

typedef struct linked_ls {
    any_t dat;

    struct linked_ls *next;

} linked_ls;

typedef struct dbl_linked_ls {
    any_t dat;

    struct dbl_linked_ls *prev;
    struct dbl_linked_ls *next;
} dbl_linked_ls;

#endif
