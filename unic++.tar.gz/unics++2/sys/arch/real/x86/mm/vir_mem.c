#include <lib/mod.h>
#include <lib/export.h>
#include <arch/x86/mm.h>
#include <lib/bit/int.h>
#include <lib/mem.h>
#include <asm/x86/atom.h>
#include <lib/types.h>  

extern void st_pgdir(uint32_t val, uint16_t i);
extern uint32_t gt_pgdir(uint16_t i);

#define get_cr3(var) __asm__ volatile("movl %%cr3, %0" : "=r"(var))
#define set_cr3(addr) __asm__ volatile("movl %0, %%cr3" : : "=r"(addr))
#define invlpg(addr) __asm__ volatile("invlpg (%0)" : : "r"(addr) : "memory");

static uint32_t get_ptbl_idx(vaddr_t addr) {
    
    return (addr >> 12) & 0x3ff;

}

static pg_tbl_t *gt_pgtbl(vaddr_t addr, bool alloc, int flgs) {

    uint32_t pdir_i = get_pgtbl_idx(addr),
             pde_val = gt_pgdir(pdir_i);

    if (pde_val & PTE_PRES)
        return (pg_tbl_t *)(pde_val & ~0xfff);

    if (!alloc)
        return NULL;

    void *np = pgalloc();
    
    if (!np)
        return NULL;

    memset(np, 0, 0x1000);

    uint32_t new_pde_val = (uint32_t)np | PTE_PRES | PTE_RW;

    if (flgs & PTE_USR)
        new_pde_val |= PTE_USR;

    st_pgdir(new_pde_val, pdir_i);

    return (pg_tbl_t *)np;

}

void *kmmap(void *paddr, void *vaddr, int flags) {

    vaddr_t viaddr = (vaddr_t)vaddr & ~0xfff;
    
    paddr_t phaddr = (paddr_t)paddr & ~0xfff;

    atom_lock();

    pg_tbl_t *pt = get_pgtbl(v_addr, true, flgs);

    if (pt == NULL) {

        atom_unlock();
        
        return NULL;

    }

    uint32_t ptbl_idx = get_pgtbl_idx(v_addr);

    pg_tbl_t *pte = &pt[ptbl_idx];

    pte->pg_frme_addr = p_addr >> 12;
    pte->present = (flgs & PTE_PRES) ? true : false;
    pte->rw = (flgs & PTE_RW) ? true : false;
    pte->usr_suprvisior = (flgs & PTE_USR) ? true : false;
    pte->acced = (flgs & PTE_ACCED) ? true : false;
    pte->dirty = (flgs & PTE_DIRTY) ? true : false;
    pte->globl = (flgs & PTE_GLOBL) ? true : false;

    pte->wr_through = false;
    pte->cache_disabled = false;
    pte->pg_sz = false;

    invlpg(vaddr);

    atom_unlock();

    return vaddr;

}

EXPORT(kmmap);

void pgmap(void *addr, int flags) {

    vaddr_t vaddr = (vaddr_t)addr & ~0xfff;

    atom_lock();

    void *p = pgalloc();

    if (!p) {

        atom_unlock();

        return;

    }

    kmmap((void *)vaddr, p, flags);

}

EXPORT(pgmap);

static int8_t init_vmm(void) {

    if (vmm_gt_pgdir() != 0x0)
        vmm_st_pgdir(0x0);

    return 0;

}

early_mod_init(init_vmm);
