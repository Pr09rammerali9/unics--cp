#include "pic.h"

void pic_remap(int offset1, int offset2) {

    uint8_t a1, a2;

    a1 = inb(PIC1_DAT);
    a2 = inb(PIC2_DAT);

    outb(PIC1_CMD, 0x11);
    outb(PIC2_CMD, 0x11);

    outb(PIC1_DAT, offset1);
    outb(PIC2_DAT, offset2);

    outb(PIC1_DAT, 0x04);
    outb(PIC2_DAT, 0x02);

    outb(PIC1_DAT, 0x01);
    outb(PIC2_DAT, 0x01);

    outb(PIC1_DAT, a1);
    outb(PIC2_DAT, a2);

}

void pic_eoi(uint8_t irq) {
    if (irq >= 8)
        outb(PIC2_CMD, PIC_EOI);

    outb(PIC1_CMD, PIC_EOI);

}

void irq_mask(uint8_t irq) {

    uint16_t port;
    
    uint8_t mask;

    if (irq < 8)
        port = PIC1_DAT;
    else {

        port = PIC2_DAT;
        
        irq -= 8;

    }

    mask = inb(port) | (1 << irq);

    outb(port, mask);

}

void irq_unmask(uint8_t irq) {
    
    uint16_t port;
    
    uint8_t mask;

    if (irq < 8)
        port = PIC1_DAT;
    else {

        port = PIC2_DAT;
        
        irq -= 8;

    }

    mask = inb(port) & ~(1 << irq);
    
    outb(port, mask);

}

/*optional:
 * author:Pr09rammerali9
 * module:pic.c
 * description:an programmable interrupt controler driver for 8259A
 * version:0.0.1
 * licnese:0BSD
 */
