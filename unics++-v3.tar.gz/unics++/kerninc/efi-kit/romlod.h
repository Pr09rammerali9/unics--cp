#ifndef EFIKIT_ROMLOD_H
#define EFIKIT_ROMLOD_H

#include "../lib/bit/int.h"
#include "../lib/compiler.h"

typedef struct __packed {
    uint8_t pcids_sig[4];

    uint16_t ven_id,
             dev_id,
             vpd_off,
             sz;

    uint8_t rev,
            class_cod[3];

    uint16_t img_len,
             rev_lvl;

    uint8_t cod_ty,
            indi;

    uint16_t rsvd;
} efi_pci_dat;

typedef struct __packed {
    uint16_t sz;

    uint32_t hdr_sig;

    uint16_t sub_sys,
             mach_ty;

    uint8_t resvd;

    uint16_t efi_off;
} arch_dat;

typedef struct __packed {
    uint16_t rom_sig;

    arch_dat arch_data;

    uint16_t pcids_off;

    uint8_t resvd[38];
} rom_hdr;
    
#endif
