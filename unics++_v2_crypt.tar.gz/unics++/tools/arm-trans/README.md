This Tool:
    arm-trans
Is A Transpiler That Takes AT&T-Like Arm Syntax To Standard Arm Syntax

To Use It:
    arm-trans <file.s-.S-.asm-.inc>
    Then It Makes:out.<.s-.S-.asm-.inc>
    Or:
    arm-trans <file.s-.S-.asm-.inc> -o <file.s-.S-.asm-.inc>

Simple As Drinking Water, No Need For Flags And Other Things 
