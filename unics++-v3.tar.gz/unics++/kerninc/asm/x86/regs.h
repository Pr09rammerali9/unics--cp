#ifndef ASM_X86_REGS_H
#define ASM_X86_REGS_H

#include "../../lib/bit/int.h"
#include "../../lib/str.h" 

void setreg8(char r[4], uint8_t val);
void setreg16(char r[6], uint16_t val);
void setreg32(char r[8], uint32_t val);
void ssetreg8(char r[4], int8_t val);
void ssetreg16(char r[6], int16_t val);
void ssetreg32(char r[8], int32_t val);

#endif
