CC=""
flgs=""
AS=""
TC=""
RSC=""
fmt=""

comp(x) {}
