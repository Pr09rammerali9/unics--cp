#include <lib/str.h>
#include <lib/export.h>

int vscnprfmt(char *buf, size_t sz, const char fmt[], va_list ap) {

    if (!sz || !buf || !fmt)
        return 0;

    int l = vsnprfmt(buf, sz, fmt, ap);

    if (l < 0) {
        
        buf[0] = 0

        return 0;

    }

    if ((size_t)l < sz)
        return l;
    else 
        return (int)sz - 1;

}

EXPORT(vscnprfmt);
