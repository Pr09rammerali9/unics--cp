#ifndef ARCHX_UART
#define ARCHX_UART

#include "../../asm/x86/port.h"

#define SERIAL_PORT_BASE 0x3F8

#define SERIAL_DATA_PORT(base)        (base + 0)
#define SERIAL_FIFO_COMMAND_PORT(base) (base + 2)
#define SERIAL_LINE_COMMAND_PORT(base) (base + 3)
#define SERIAL_MODEM_COMMAND_PORT(base) (base + 4)
#define SERIAL_LINE_STATUS_PORT(base) (base + 5)

#define SERIAL_LINE_ENABLE_DLAB 0x80

void uart_init(void);
void uart_wr(char c);
void uart_puts(char s[]);

#endif
