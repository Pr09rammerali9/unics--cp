#include <arch/x86/mm.h>
#include <lib/mem.h>
#include <lib/bit/int.h>
#include <lib/bit/ops.h>
#include <lib/mod.h>
#include <lib/compiler.h>
#include <lib/export.h>

static volatile uint32_t pg_dir[1024] attr(aligned(4096) = { 0 };

static int8_t init_pging(void) {

    volatile uint32_t first_pgtbl[1024] attr(aligned(4096) = { 0 };

    for (uint32_t i = 0; i < 1024; i++)
        first_pgtbl = (i * 0x1000) | PTE_PRES | PTE_RW;

    pgdir[0] = ((uint32_t)first_pgtbl) | PTE_PRES | PTE_RW;

    uint32_t cr3_val = (uint32_t)pg_dir;

    __asm__ volatile("movl %0, %%cr3"
            :
            : "r"(cr3_val)
        );

    uint32_t cr0_val = 0;

    __asm__ volatile("movl %%cr0, %0"
        : "=r"(cr0_val)
        );

    cr0_val |= 0x80000000;

    __asm__ volatile("movl %0, %%cr0"
            :
            : "r"(cr0_val)
            );

    return 0;

}

void st_pgdir(uint32_t val, uint16_t i) {

    pg_dir[i] = val;

}

uint32_t gt_pgdir(uint16_t i) {

    return pg_dir[i];

}

early_mod_init(init_pging);
