#include <lib/rng.h>
#include <lib/mem.h>
#include <lib/export.h>

uint64_t next_u64_via_u32(rng_core_t *rng) {

    uint64_t x = (uint64_t)rng->next_u32(rng),
             y = (uint64_t)rng->next_u32(rng);

    return (y << 32) | x;

}

EXPORT(next_u64_via_fill);

void fill_bytes(rng_core_t *rng, uint8_t *dest, size_t len) {

    size_t off = 0;

    while (len - off >= 8) {

        uint64_t chnk_val = rng->next_u64(rng);

        memcpy(dest + off, &chnk_val, 8);

        off += 8;

    }

    size_t rem = len - off;

    if (rem > 4) {

        uint64_t chnk_val = rng->next_u64(rng);

        memcpy(dest + off, &chnk_val, rem);

    } else if (rem > 0) {

        uint32_t chnk_val = rng->next_u32(rng);

        memcpy(dest + off, &chnk_val, rem);

    }

}

EXPORT(fill_bytes);

void u32_to_le_bytes(uint32_t val, uint8_t *bytes) {

    bytes[0] = (uint8_t)(val & 0xff);
    bytes[1] = (uint8_t)(val >> 8);
    bytes[2] = (uint8_t)((val >> 16) & 0xff);
    bytes[3] = (uint8_t)((val >> 24) & 0xff);

}

EXPORT(u32_to_le_bytes);

void u64_to_le_bytes(uint64_t val, uint8_t *bytes) {

    bytes[0] = (uint8_t)(val & 0xFF);
    bytes[1] = (uint8_t)((val >> 8) & 0xFF);
    bytes[2] = (uint8_t)((val >> 16) & 0xFF);
    bytes[3] = (uint8_t)((val >> 24) & 0xFF);
    bytes[4] = (uint8_t)((val >> 32) & 0xFF);
    bytes[5] = (uint8_t)((val >> 40) & 0xFF);
    bytes[6] = (uint8_t)((val >> 48) & 0xFF);
    bytes[7] = (uint8_t)((val >> 56) & 0xFF);

}

EXPORT(u64_to_le_bytes);

size_t fill_via_next_u32_chnks(const uint32_t *src, size_t src_len, uint8_t *dest, size_t dst_len, size_t *filled_dst_bytes) {
    size_t size = sizeof(uint32_t),
           consumed_src = 0;

    while (consumed_src < src_len && (*filled_dst_bytes + size) <= dst_len) {

        u32_to_le_bytes(src[consumed_src], dest + *filled_dst_bytes);

        consumed_src++;
        *filled_dst_bytes += size;
    }

    if (consumed_src < src_len && *filled_dst_bytes < dst_len) {

        uint8_t tmp[4] = { 0 };

        u32_to_le_bytes(src[consumed_src], tmp);

        size_t bytes_to_cp = dst_len - *filled_dst_bytes;

        if (bytes_to_cp > size)
            bytes_to_cp = size;

        memcpy(dest + *filled_dst_bytes, tmp, bytes_to_cp);

        consumed_src++;
        *filled_dst_bytes += bytes_to_cp;

    }

    return consumed_src;

}

EXPORT(fill_via_next_u32_chnks);

size_t fill_via_next_u64_chnks(const uint64_t *src, size_t src_len, uint8_t *dest, size_t dst_len, size_t *filled_dst_bytes) {
    size_t size = sizeof(uint64_t),
           consumed_src = 0;

    while (consumed_src < src_len && (*filled_dst_bytes + size) <= dst_len) {

        u64_to_le_bytes(src[consumed_src], dest + *filled_dst_bytes);

        consumed_src++;
        *filled_dst_bytes += size;

    }

    if (consumed_src < src_len && *filled_dst_bytes < dst_len) {

        uint8_t tmp[8] = { 0 };

        u64_to_le_bytes(src[consumed_src], tmp);

        size_t bytes_to_cp = dst_len - *filled_dst_bytes;

        if (bytes_to_cp > size)
            bytes_to_cp = size;

        memcpy(dest + *filled_dst_bytes, tmp, bytes_to_cp);

        consumed_src++;
        *filled_dst_bytes += bytes_to_cp;

    }

    return consumed_src;

}

EXPORT(fill_via_next_u64_chnks);

uint32_t next_u32_via_fill(rng_core_t *rng) {

    uint8_t buf[4];

    rng->fill_bytes(rng, buf, 4);

    return (uint32_t)((uint32_t)buf[0] | ((uint32_t)buf[1] << 8) | ((uint32_t)buf[2] << 16) | ((uint32_t)buf[3] << 24));

}

EXPORT(next_u32_via_fill);

uint64_t next_u64_via_fill(rng_core_t *rng) {

    uint8_t buf[8];

    rng->fill_bytes(rng, buf, 8);

    return (uint64_t)((uint64_t)buf[0] | ((uint64_t)buf[1] << 8) | ((uint64_t)buf[2] << 16) | ((uint64_t)buf[3] << 24) | ((uint64_t)buf[4] << 32) | ((uint64_t)buf[5] << 40) | ((uint64_t)buf[6] << 48) | ((uint64_t)buf[7] << 56));

}

EXPORT(next_u64_via_fill);
