#ifndef EFI_SMBIOS_H
#define EFI_SMBIOS_H

#include "../lib/bit/int.h"
#include "../lib/compiler.h"
#include "types.h"

typedef struct __packed {
    uint8_t anchor_str[4],
            entry_point_struct_chksum,
            entry_point_len,
            major_ver,
            minor_ver;

    uint16_t max_struct_sz;

    uint8_t entry_point_revision,
            fmted_area[5],
            intmd_anchor_str[5],
            intmd_chksum;

    uint16_t tbl_len;

    uint32_t tbl_addr;

    uint16_t num_of_smbios_structs;

    uint8_t smbios_bcd_revision;
} smbios_struct_tbl;

typedef struct __packed {
    uint8_t anchor_str[5],
            entry_point_struct_chksum,
            entry_point_len,
            major_ver,
            minor_ver,
            doc_rev,
            entry_point_revision,
            res;

    uint32_t tbl_max_sz;
    
    uint64_t tbl_addr;
} smbios3_struct_tbl;

typedef struct __packed {
    uint8_t ty,
            len,
            handle[2];
} smbios_hdr;

typedef struct __packed {
    smbios_hdr hdr;

    uint8_t ven,
            bios_ver,
            bios_seg[2],
            bios_release_date,
            bios_sz,
            bios_chistics[8];
} smbios_ty;

typedef struct __packed {
    smbios_hdr hdr;

    uint8_t manufacturer,
            prod_name,
            ver,
            ser_num;

    efi_guid uuid;

    uint8_t wake_up_time;   
} smbios_ty1;

typedef struct __packed {
    smbios_hdr hdr;

    uint8_t manufacturer,
            prod_name,
            ver,
            ser_num;    
} smbios_ty2;

typedef struct __packed {
    smbios_hdr hdr;

    uint8_t manufacturer,
            ty,
            ver,
            ser_num,
            assest_tag,
            bootup_stat,
            pow_supply_stat,
            thermal_stat,
            secuirty_stat,
            oem_defed[4];
} smbios_ty3;

typedef struct __packed {
    smbios_hdr hdr;

    uint8_t sock,
            proc_ty,
            proc_family,
            proc_manufacturer,
            proc_id[4],
            proc_ver,
            volt,
            extrn_clk[2],
            max_speed[2],
            cur_speed[2],
            stat,
            proc_upgrade,
            l1_cache_handle[2],
            l2_cache_handle[2],
            l3_cache_handle[2];
} smbios_ty4;

typedef struct __packed {
    smbios_hdr *hdr;

    smbios_ty *ty0;

    smbios_ty1 *ty1;

    smbios_ty2 *ty2;

    smbios_ty3 *ty3;

    smbios_ty4 *ty4;

    uint8_t *raw;
} smbios_struct_ptr;

#endif 
