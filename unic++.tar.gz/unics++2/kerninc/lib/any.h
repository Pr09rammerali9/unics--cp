#ifndef ANY_H
#define ANY_H

#include "bit/int.h"
#include "bit/ptr.h"

typedef union {
    char c;
    int i;
    short s;
    long l;
    long long ll;
    float f;
    double d;
    long double ld;

    int8_t i8;
    uint8_t u8;
    int16_t i16;
    uint16_t u16;                                     int32_t i32;
    uint32_t u32;                                     int64_t i64;
    uint64_t u64;

    void* v;                                          char* cp;
    int* ip;
    short* sp;
    long* lp;
    long long* llp;
    float* fp;
    double* dp;
    long double* ldp;
    int8_t* i8p;
    uint8_t* u8p;
    int16_t* i16p;
    uint16_t* u16p;
    int32_t* i32p;
    uint32_t* u32p;
    int64_t* i64p;
    uint64_t* u64p;

    uintptr_t uint_ptr;
    intptr_t int_ptr;
} any_val;

typedef enum {
    ANY_I8,
    ANY_U8,
    ANY_I16,
    ANY_U16,
    ANY_I32,
    ANY_U32,
    ANY_I64,
    ANY_U64,
    ANY_FLOAT,
    ANY_DOUBLE,
    ANY_LONG_DOUBLE,
    ANY_INTPTR,
    ANY_UINTPTR,
    ANY_VPTR,
    ANY_I8P,
    ANY_U8P,
    ANY_I16P,
    ANY_U16P,
    ANY_I32P,
    ANY_U32P,
    ANY_I64P,
    ANY_U64P
} any_type;

typedef struct {
    any_val val;
    any_type type;
} any;

#define is_eqtype(var, type) \
    _Generic((var), \
        char: (type == ANY_I8 || type == ANY_U8), \
        unsigned char: (type == ANY_U8), \
        short: (type == ANY_I16), \
        unsigned short: (type == ANY_U16), \
        int: (type == ANY_I32), \
        unsigned int: (type == ANY_U32), \
        long: (type == ANY_I64), \
        unsigned long: (type == ANY_U64), \
        long long: (type == ANY_I64), \
        unsigned long long: (type == ANY_U64), \
        float: (type == ANY_FLOAT), \
        double: (type == ANY_DOUBLE), \
        long double: (type == ANY_LONG_DOUBLE), \
        void*: (type == ANY_VPTR), \
        char*: (type == ANY_I8P), \
        unsigned char*: (type == ANY_U8P), \
        short*: (type == ANY_I16P), \
        unsigned short*: (type == ANY_U16P), \
        int*: (type == ANY_I32P), \
        unsigned int*: (type == ANY_U32P), \
        long*: (type == ANY_I64P), \
        unsigned long*: (type == ANY_U64P), \
        long long*: (type == ANY_I64P), \
        unsigned long long*: (type == ANY_U64P), \
        float*: (type == ANY_FLOAT), \
        double*: (type == ANY_DOUBLE), \
        long double*: (type == ANY_LONG_DOUBLE), \
        int8_t: (type == ANY_I8), \
        uint8_t: (type == ANY_U8), \
        int16_t: (type == ANY_I16), \
        uint16_t: (type == ANY_U16), \
        int32_t: (type == ANY_I32), \
        uint32_t: (type == ANY_U32), \
        int64_t: (type == ANY_I64), \
        uint64_t: (type == ANY_U64), \
        intptr_t: (type == ANY_INTPTR), \
        uintptr_t: (type == ANY_UINTPTR), \
        default: 0 \
    )

#endif
