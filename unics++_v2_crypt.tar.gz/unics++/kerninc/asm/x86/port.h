#ifndef PORT_H
#define PORT_H

#include "../../lib/bit/int.h"

void outb(uint16_t port, uint8_t val);
void outw(uint16_t port, uint16_t val);
void outl(uint16_t port, uint32_t val);

#define INARG uint16_t port

uint8_t inb(INARG);
uint16_t inw(INARG);
uint32_t inl(INARG);

#endif
