#include <lib/alloc.h>
#include <lib/export.h>

static unsigned char pool[1024] = { 0 };

static size_t off = 0;

void *balloc(size_t size, size_t alignment) {

    if (!size) //size is zero, this is similar to if (size == 0)
        return NULL;

    uintptr_t cur_addr = (uintptr_t)pool + off;

    size_t padding = 0;

    if (alignment > 0) {

        size_t rem = cur_addr % alignment;

        if (rem != 0)
            padding = alignment - rem;
    }

    if (off + padding + size > 1024)
        return NULL;

    unsigned char *alloced_ptr = pool + off + padding;
    
    off += (padding + size);

    return (void *)alloced_ptr;

}

EXPORT(balloc);

void breset(void) {

    off = 0;

    memset(pool, 0, 2048);

}

EXPORT(breset);

size_t bget_used(void) {

    return off;

}

EXPORT(bget_used);

size_t bget_remaining(void) {

    return POOL_SIZE - off;

}

EXPORT(bget_remaining);
