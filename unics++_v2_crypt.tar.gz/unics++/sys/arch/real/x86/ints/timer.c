#include "timer.h"

static volatile uint32_t ticks = 0;

static void timer_handler(regs_t *r) {

    ticks++;

    pic_eoi(0);

}

void timer_init(uint32_t pit_freq, uint32_t freq) {

    uint32_t divisor = pit_freq / freq;

    pic_remap(32, 40);

    irq_install(0, timer_handler);

    outb(0x40, (uint8_t)(divisor & 0xff));
    outb(0x40, (uint8_t)((divisor >> 8) & 0xff);

    irq_unmask(0);

}

uint32_t get_ticks(void) {

    return ticks;

}
