#include "bootfs.h"
#include <asm/x86/port.h>

static uint8_t selected_drive = 0xE0;

static bootfs_super active_sb;

static void ide_wait() {
    
    for(int i = 0; i < 4; i++)
        inb(0x1F7);
    
    while (inb(0x1F7) & 0x80) 
        __builtin_ia32_pause();

    while (!(inb(0x1F7) & 0x08)) 
        __builtin_ia32_pause();

}

static int ide_read(uint32_t lba, uint32_t count, void *buf) {
    while (inb(0x1F7) & 0x80) __builtin_ia32_pause();

    outb(0x1F6, selected_drive | ((lba >> 24) & 0x0F));
    outb(0x1F2, (uint8_t)count);
    outb(0x1F3, (uint8_t)lba);
    outb(0x1F4, (uint8_t)(lba >> 8));
    outb(0x1F5, (uint8_t)(lba >> 16));
    outb(0x1F7, 0x20);

    uint16_t *ptr = (uint16_t *)buf;

    for (uint32_t i = 0; i < count; i++) {
        
        ide_wait();

        for (int j = 0; j < 256; j++)
            *ptr++ = inw(0x1F0);
    
    }

    return 0;

}

int bootfs_mount(const char *dev) {
    
    selected_drive = 0xE0;

    if (ide_read(0, 8, &active_sb) != 0 || active_sb.mag != LFS_MAG) {
        
        selected_drive = 0xF0;

        if (ide_read(0, 8, &active_sb) != 0 || active_sb.mag != LFS_MAG)
            return -1;

    }
    
    return 0;

}

int bootfs_rd(uint32_t inum, bootfs_inode *inode) {
    
    uint32_t inodes_per_blk = LFS_BLK_SZ / sizeof(bootfs_inode);
    uint32_t lfs_blk = 1 + (inum / inodes_per_blk);
    uint32_t offset = (inum % inodes_per_blk) * sizeof(bootfs_inode);

    static uint8_t scratch[LFS_BLK_SZ];
    
    ide_read(lfs_blk * 8, 8, scratch);

    uint8_t *src = scratch + offset;
    uint8_t *dst = (uint8_t*)inode;

    for(uint32_t i = 0; i < sizeof(bootfs_inode); i++)
        dst[i] = src[i];
    
    return 0;

}

uint32_t bootfs_lookup(const char *name) {
    
    bootfs_inode root_inode;

    if (bootfs_rd(active_sb.root_addr, &root_inode) != 0) 
        return 0;

    static uint8_t dir_buf[LFS_BLK_SZ];
    
    ide_read(root_inode.addr[0] * 8, 8, dir_buf);

    bootfs_dirent *ent = (bootfs_dirent*)dir_buf;

    uint32_t max_ent = LFS_BLK_SZ / sizeof(bootfs_dirent);

    for (uint32_t i = 0; i < max_ent; i++) {
        
        if (ent[i].inode_num == 0) 
            continue;

        int match = 1;

        for(int j = 0; j < 28; j++) {
            
            if (ent[i].name[j] != name[j]) { 
                match = 0; 

                break; 
            
            }

            if (name[j] == '\0') 
                break;
        }

        if (match) 
            return ent[i].inode_num;
    
    }

    return 0;

}
