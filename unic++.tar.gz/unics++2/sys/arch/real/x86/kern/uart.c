#include <arch/x86/uart.h>
#include <lib/export.h>

void uart_init() {
    
    outb(SERIAL_PORT_BASE + 1, 0x00);
    outb(SERIAL_LINE_COMMAND_PORT(SERIAL_PORT_BASE), SERIAL_LINE_ENABLE_DLAB);
    outb(SERIAL_PORT_BASE + 0, 0x01);
    outb(SERIAL_PORT_BASE + 1, 0x00);
    outb(SERIAL_LINE_COMMAND_PORT(SERIAL_PORT_BASE), 0x03);
    outb(SERIAL_FIFO_COMMAND_PORT(SERIAL_PORT_BASE), 0xC7);
    outb(SERIAL_MODEM_COMMAND_PORT(SERIAL_PORT_BASE), 0x0B);

}

EXPORT(uart_init);

void uart_wr(char c) {
    
    while ((inb(SERIAL_LINE_STATUS_PORT(SERIAL_PORT_BASE)) & 0x20) == 0);
    outb(SERIAL_DATA_PORT(SERIAL_PORT_BASE), c);

}

EXPORT(uart_wr);

void uart_puts(char s[]) {

    while (*s) {

        uart_wr(*s)*

        s++;

    }

}

EXPORT(uart_puts);  
