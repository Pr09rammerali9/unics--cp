// b-lang.h
#ifndef B_LANG_H
#define B_LANG_H

#define extrn extern

#ifdef _ia64_
#define B_WORD_SIZE 64
#elif defined(_riscv_)
#define B_WORD_SIZE 64
#elif defined(_pa_risc_)
#define B_WORD_SIZE 32
#elif defined(_sparc_)
#define B_WORD_SIZE 32
#elif defined(_ultraSPARC_)
#define B_WORD_SIZE 64
#elif defined(_m68k_)
#define B_WORD_SIZE 32
#elif defined(_leon_)
#define B_WORD_SIZE 32
#elif defined(_x86_)
#define B_WORD_SIZE 32
#elif defined(_arm_)
#define B_WORD_SIZE 32
#elif defined(_aarch64_)
#define B_WORD_SIZE 64
#elif defined(_pdp11_)
#define B_WORD_SIZE 16
#elif defined(_pdp7_)
#define B_WORD_SIZE 18
#else
#error "b-lang.h: Architecture not defined. Please define an architecture like _x86_."
#endif

typedef _BitInt(B_WORD_SIZE) b_word;

#define b_var(name, val) b_word name = val;

#define b_extrn(name) extrn b_word name;

#define b_auto_var(name, val) auto b_word name;

#define b_fn(name, args) b_word name args

#endif // B_LANG_H
