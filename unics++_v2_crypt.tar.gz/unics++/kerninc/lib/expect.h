#ifndef EXPECT_H
#define EXPECT_H

#define expected(e) __builtin_expect(e, 1)
#define unexpected(e) __builtin_expect(e, 0)
#define likely(e) __builtin_expect(!!(e), 1)
#define unlikely(e) __builtin_expect(!!(e), 0)
#define assume(e) __builtin_assume((e))

#endif
