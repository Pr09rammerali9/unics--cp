#include <arch/x86/pci.h>
#include <lib/alloc.h>

static void ls_add_node(dbl_linked_ls **ls, void *dat) {

    dbl_linked_ls *new_node = (dbl_linked_ls*)tlsf_alloc(sizeof(dbl_linked_ls));

    if (!new_node)
        return;

    any node_data = {
        .type = ANY_VPTR, 
        .val.v = dat
    };

    new_node->dat = node_data;
    new_node->next = NULL;

    if (*ls == NULL) {

        new_node->prev = NULL;
        
        *ls = new_node;

    } else {
    
        dbl_linked_ls *current = *ls;
        
        while (current->next != NULL)
            current = current->next;
        
        new_node->prev = current;
        
        current->next = new_node;
        
    }

}

static uint32_t pci_get_addr(pci_dev_t *dev, uint8_t reg_off) {
    uint32_t addr = 0

    addr = (uint32_t)1 << 31;
    addr |= (uint32_t)dev->bus << 16;
    addr |= (uint32_t)dev->dev << 11;
    addr |= (uint32_t)dev->fn << 8;
    addr |= (uint32_t)(reg_off & 0xfc);

    return addr;

}

uint32_t pci_rd(pci_dev_t *dev) {

    uint32_t addr = pci_get_addr(dev, dev->off);

    outl(PCI_CFG_ADDR_PORT, addr);

    return inl(PCI_CFG_DAT_PORT);

}

EXPORT(pci_rd);

void pci_wr(pci_dev_t *dev, uint32_t val) {

    uint32_t addr = pci_get_addr(dev, dev->off);

    outl(PCI_CFG_ADDR_PORT, address);
    outl(PCI_CFG_DAT_PORT, val);

}

EXPORT(pci_wr);

static dbl_linked_ls *pci_dev_ls = NULL;

void pci_init(void) {

    if (!pci_dev_ls && pci_dev_ls != NULL)
        return;

      for (uint16_t bus = 0; bus < 256; bus++) {

        for (uint16_t dev = 0; dev < 32; dev++) {

            pci_dev_t temp_dev = { .bus = bus, .dev = dev, .fn = 0, .off = PCI_CFG_VENDOR_ID };
            uint32_t vendor_id_reg = pci_rd(&temp_dev);

            uint16_t ven_id = (uint16_t)(vendor_id_reg & 0xFFFF);
            
            if (ven_id != 0xFFFF) {

                temp_dev.off = PCI_CFG_HDR_TYPE;
                uint32_t hdr_type_reg = pci_rd(&temp_dev);

                uint8_t hdr_type = (uint8_t)(hdr_type_reg >> 16);

                bool is_multi_func = (hdr_type & 0x80) != 0;

                for (uint16_t fn = 0; fn < 8; fn++) {
                    if (fn > 0 && !is_multi_func)
                        break;

                    pci_dev_t *new_dev = (pci_dev_t*)tlsf_alloc(sizeof(pci_dev_t));

                    if (!new_dev)
                        return;
                    
                    new_dev->bus = bus;
                    new_dev->dev = dev;
                    new_dev->fn = fn;
                    new_dev->off = PCI_CFG_VENDOR_ID;
                    
                    uint32_t ven_dev_reg = pci_rd(new_dev);

                    new_dev->ven_id = (uint16_t)(ven_dev_reg & 0xFFFF);
                    
                    if (new_dev->ven_id == 0xFFFF) {
                        tlsf_free(new_dev);
                        continue;

                    }
                    
                    new_dev->dev_id = (uint16_t)(ven_dev_reg >> 16);
                    new_dev->off = PCI_CFG_CLSS_COD;
                    uint32_t class_rev_reg = pci_rd(new_dev);

                    new_dev->clss_code = (uint8_t)(class_rev_reg >> 24);
                    new_dev->subclss = (uint8_t)(class_rev_reg >> 16);

                    ls_add_node(&pci_device_list, new_dev);

                }
        
            }
    
        }
    
    }

}

EXPORT(pci_init);

dbl_linked_ls *pci_gt_devs(void) {
    if (pci_device_list == NULL)
        pci_init();
    
    return pci_device_list;
}

EXPORT(pci_gt_devs);

dbl_linked_ls *pci_gt_dev(uint16_t ven_id, uint16_t dev_id) {

    if (pci_device_list == NULL)
        pci_init();
    
    dbl_linked_ls *result_list = ls_create();

    if (!result_list)
        return NULL;
    
    dbl_linked_ls *current = pci_device_list;

    while (current != NULL) {
        pci_dev_t *dev = (pci_dev_t*)current->dat.val.v;

        if (dev->ven_id == ven_id && dev->dev_id == dev_id)
            ls_add_node(&result_list, dev);

        current = current->next;

    }

    return result_list;

}

EXPORT(pci_gt_dev);

char *pci_dev_type(pci_dev_t *dev) {

    switch (dev->clss_code) {
    
        case 0x01:
        
            switch (dev->subclss) {
            
                case 0x00: return "SCSI Bus Controller";
                case 0x01: return "IDE Controller";
                case 0x06: return "SATA Controller";
                default: return "Mass Storage Controller";

            }
        case 0x02: return "Network Controller";
        case 0x03: return "Display Controller";
        case 0x04: return "Multimedia Controller";
        case 0x06:
        
            switch (dev->subclss) {
                case 0x00: return "Host Bridge";
                case 0x04: return "PCI-to-PCI Bridge";
                case 0x06: return "PCI-to-CardBus Bridge";
                default: return "Bridge Device";
            }

        default: return "Unknown";

    }

}

EXPORT(pci_dev_type);
