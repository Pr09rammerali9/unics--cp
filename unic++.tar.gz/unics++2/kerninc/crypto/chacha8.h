#ifndef CHACHA8_H
#define CHACHA8_H

#include "../lib/rng.h"
#include "../lib/def.h"
#include "../lib/mem.h"
#include "../lib/bit/ops.h"
#include "../lib/bit/int.h"

#define CHACHA_STATE_SIZE (16 * sizeof(uint32_t))
#define CHACHA_BLK_SIZE CHACHA_STATE_SIZE
#define CHACHA_KEY_SIZE (8 * sizeof(uint32_t))
#define CHACHA_NONCE_SIZE (3 * sizeof(uint32_t))

typedef struct {
    uint32_t state[16];
} chacha_state_t;

typedef struct {
    uint32_t key[8];
} chacha_key_t;

typedef struct {
    uint32_t nonce[3];
} chacha_nonce_t;

void chacha_init(chacha_state_t *state, const chacha_key_t *key, const chacha_nonce_t *nonce, uint32_t counter);
void chacha8_blk(chacha_state_t *state, uint32_t *out_blk);
void chacha8_rng(chacha_state_t *state, uint8_t *dest, size_t len);

#endif 
