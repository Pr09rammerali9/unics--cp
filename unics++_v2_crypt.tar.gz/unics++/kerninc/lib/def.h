#ifndef DEF
#define DEF

typedef unsigned long size_t;
typedef signed long ssize_t;
typedef signed long ptrdiff_t;
typedef unsigned int wchar_t;

#ifndef TYPES_ONLY

#define NULL ((void *)0)   
#define WNUL L'\0'

//offset of macro
//sense we are not using __builtin_offsetof wewill implent this from scratch
#define offof(type, member) ((size_t)((char *)&(((type *)0)->member) - (char *)0))
//another version of offset of macro
//using __builtin_offsetof
#define offsetof(t, m) __builtin_offsetof(t, m)
#define cnt_of(p, t, m) const typeof(((t *)0)->m) *__mp = (p); \
        (t *)((char *)__mp - offsetof(t, m))

#endif

#define        fldoff(str, fld)        ((int)&(((struct str *)0)->fld))
#define        fldsiz(str, fld)        (sizeof(((struct str *)0)->fld))
#define        strbase(str, ptr, fld)        ((struct str *)((char *)(ptr)-fldoff(str, fld)))

#endif
