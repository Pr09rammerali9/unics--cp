#define CR_SRC_IMPL
#include <sys/coroutines.h>
#include <asm/defs.h>
#include <asm/stk.h>
#include <lib/bit/int.h>
#include <asm/regs.h>
#include <asm/ip.h>
#include <asm/jmpbuf.h>

#define ALIGN_UP(s, a) (((s) + (a) - 1) & ~((a) - 1))
#define REAL_STK_SZ ALIGN_UP(COROSTK_SZ, ARCH_ALIGN)

static uint8_t coro_stacks[COROMAX][REAL_STK_SZ] ALIGNMENT;

static kcoro_t coro_pool[COROMAX] ALIGNMENT;

static jmpbuf_t coro_contexts[COROMAX] ALIGNMENT;

static kcoro_t *current_coro = (kcoro_t*)0;

static jmpbuf_t sched_ctx;

static void coro_init(kcoro_t *coro) {
    if (!coro) 
        return;

    coro->stat = 3; 
    coro->stk_sz = COROSTK_SZ / 1024;
    coro->stk_base = 0;
    coro->prev = (kcoro_t*)0;
    coro->next = (kcoro_t*)0;

}

static kcoro_t coro_spawn(void (*fn)(void)) {

    for (int i = 0; i < COROMAX; i++) {

        if (coro_pool[i].stat == 3) {
        
            kcoro_t *c = &coro_pool[i];
            
            c->id = i;
            c->stat = 0; 
            c->stk_base = (size_t)coro_stacks[i];
            c->stk_sz = COROSTK_SZ / 1024;
 
            asm_regs_t *regs = (asm_regs_t *)coro_contexts[i];
            
            set_sp(regs, stack_top - sizeof(size_t));
            
            set_ip(regs, (size_t)fn);
            
            set_bp(regs, 0);

            return *c;
    
        }
    
    }

    kcoro_t empty = {0};

    return empty;

}

static void coro_yield(void) {
    
    if (!current_coro) 
        return;

    if (ksetjmp(coro_contexts[current_coro->id]) == 0) {
        
        current_coro->stat = 2; 
        
        klongjmp(sched_ctx, 1);

    }
    
    current_coro->stat = 1; 

}

static void coro_kill(kcoro_t *coro) {
    
    if (!coro) 
        return;
    
    coro->stat = 3;
    coro->stk_base = 0;

}

static kcoro_stat_t coro_get_stat(kcoro_t *coro) {
    
    if (!coro) 
        return 3;

    return coro->stat;

}

__sys_coro_t sys_coroutine = {
    .init = &coro_init,
    .spawn = &coro_spawn,
    .yield = &coro_yield,
    .kill = &coro_kill,
    .stat = &coro_get_stat
};
