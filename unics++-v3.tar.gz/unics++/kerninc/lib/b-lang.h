// b-lang.h
#ifndef B_LANG_H
#define B_LANG_H

#define extrn extern


typedef unsigned long long b_word;

#define b_var(name, val) b_word name = val;

#define b_extrn(name) extrn b_word name;

#define b_auto_var(name, val) auto b_word name;

#define b_fn(name, args) b_word name args

#endif // B_LANG_H
