#ifndef STR_H
#define STR_H

#include "def.h"   

#define strlen(s)           __builtin_strlen(s)
#define strcpy(dest, src)   __builtin_strcpy(dest, src)
#define strncpy(dest, src, n) __builtin_strncpy(dest, src, n)
#define strcat(dest, src)   __builtin_strcat(dest, src)
#define strncat(dest, src, n) __builtin_strncat(dest, src, n)
#define strcmp(s1, s2)      __builtin_strcmp(s1, s2)
#define strncmp(s1, s2, n)  __builtin_strncmp(s1, s2, n)
#define strchr(s, c)        __builtin_strchr(s, c)
#define strrchr(s, c)       __builtin_strrchr(s, c)
#define strstr(haystack, needle) __builtin_strstr(haystack, needle)
#define strcspn(s1, s2)     __builtin_strcspn(s1, s2)
#define strpbrk(s1, s2)     __builtin_strpbrk(s1, s2)
#define strspn(s1, s2)      __builtin_strspn(s1, s2)

void sprfmt(char *buf, const char fmt[], ...);

#define AARGS void *(*flavor_alloc)(size_t size),

char *strdup(AARGS const char s[]);

#endif 
