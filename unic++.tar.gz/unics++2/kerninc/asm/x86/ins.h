#ifndef INS_H
#define INS_H

#define hlt() __asm__ volatile("hlt")
#define wait() __asm__ volatile("wait")
#define fwait() __asm__ volatile("fwait")
#define pause() __asm__ volatile("pause")
#define cli() __asm__ volatile("cli")
#define sti() __asm__ volatile("sti")
#define nop() __asm__ volatile("nop")
#define std() __asm__ volatile("std")
#define cld() __asm__ volatile("cld")
#define clc() __asm__ volatile("clc")
#define stc() __asm__ volatile("stc")
#define sahf() __asm__ volatile("sahf")
#define cmc() __asm__ volatile("cmc")
#define popf() __asm__ volatile("popf")
#define popfd() __asm__ volatile("popfd")
#define popfq() __asm__ volatile("popfq")
#define lahf() __asm__ volatile("lahf")

#endif
