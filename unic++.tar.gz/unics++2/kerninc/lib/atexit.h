#ifndef ATEXIT_H
#define ATEXIT_H

#include "def.h"
#include "alloc.h"

void fns_on_exit(void);

int atexit(void (*fn)(void));

#endif
