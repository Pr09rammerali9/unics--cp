#ifndef ARCH_X86_JMP
#define ARCH_X86_JMP

#include "../../asm/jmpbuf.h"
#include "../../lib/bit/int.h"

extern void arch_longjmp(jmpbuf_t, uint32_t);

extern int arch_setjmp(jmpbuf_t);

#endif
