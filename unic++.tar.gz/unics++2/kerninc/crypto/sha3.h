#ifndef SHA3_H
#define SHA3_H

#include "../lib/bit/int.h"
#include "../lib/def.h"
#include "../lib/mem.h"

#define SHA3_STATE_WIDTH 5
#define SHA3_STATE_LANE_BITS 64
#define SHA3_STATE_SIZE_BITS (SHA3_STATE_WIDTH * SHA3_STATE_WIDTH * SHA3_STATE_LANE_BITS)
#define SHA3_STATE_SIZE_BYTES (SHA3_STATE_SIZE_BITS / 8)

#define SHA3_256_RATE_BITS 1088
#define SHA3_256_RATE_BYTES (SHA3_256_RATE_BITS / 8)
#define SHA3_256_CAPACITY_BITS 512
#define SHA3_256_CAPACITY_BYTES (SHA3_256_CAPACITY_BITS / 8)
#define SHA3_256_OUTPUT_BITS 256
#define SHA3_256_OUTPUT_BYTES (SHA3_256_OUTPUT_BITS / 8)

typedef struct {
    uint64_t state[SHA3_STATE_WIDTH][SHA3_STATE_WIDTH];

    uint8_t buf[SHA3_256_RATE_BYTES];
    
    size_t bufed_bytes;
} sha3_ctx_t;

void sha3_init(sha3_ctx_t *ctx);
void sha3_update(sha3_ctx_t *ctx, const void *data, size_t len);
void sha3_final(sha3_ctx_t *ctx, uint8_t *digest);

void sha3_keccak_f(uint64_t state[SHA3_STATE_WIDTH][SHA3_STATE_WIDTH]);

#endif // SHA3_H 
