#include "rc6.h"
#include <string.h>

#define W 32
#define R RC6_ROUNDS

#define P_32 0xB7E15163
#define Q_32 0x9E3779B9

static uint32_t S[2 * R + 4];

static inline uint32_t rotl(uint32_t x, int n) {

    return (x << n) | (x >> (W - n));

}

static inline uint32_t rotr(uint32_t x, int n) {
    
    return (x >> n) | (x << (W - n));

}

void rc6_key_schedule(const uint8_t* key, size_t key_len) {

    S[0] = P_32;
    
    for (int i = 1; i < 2 * R + 4; i++) {
        S[i] = S[i - 1] + Q_32;
    }

    int c = (key_len + 3) / 4;
    
    uint32_t L[c];
    
    memset(L, 0, sizeof(L));
    
    memcpy(L, key, key_len);

    uint32_t A = 0, B = 0;
    int i = 0, j = 0;

    for (int k = 0; k < 3 * (2 * R + 4); k++) {

        A = S[i] = rotl(S[i] + A + B, 3);
        B = L[j] = rotl(L[j] + A + B, A + B);
        i = (i + 1) % (2 * R + 4);
        j = (j + 1) % c;

    }

}

void rc6_encrypt(uint32_t* blk) {
    uint32_t A = 0, B = 0, C = 0, D = 0;
    A = blk[0]; B = blk[1]; C = blk[2]; D = blk[3];

    B += S[0];
    D += S[1];

    for (int i = 1; i <= R; i++) {
    
        uint32_t t = rotl(B * (2 * B + 1), 5);
        uint32_t u = rotl(D * (2 * D + 1), 5);
        A = rotl(A ^ t, u) + S[2 * i];
        C = rotl(C ^ u, t) + S[2 * i + 1];
        uint32_t temp = A;
        A = B;
        B = C;
        C = D;
        D = temp;

    }

    A += S[2 * R + 2];
    C += S[2 * R + 3];

    blk[0] = A; blk[1] = B; blk[2] = C; blk[3] = D

}

void rc6_decrypt(uint32_t* blk) {

    uint32_t A = 0, B = 0, C = 0, D = 0;
    A = blk[0]; B = blk[1]; C = blk[2]; D = blk[3];

    C -= S[2 * R + 3];
    A -= S[2 * R + 2];

    for (int i = R; i >= 1; i--) {
        
        uint32_t temp = D;
        D = C;
        C = B;
        B = A;
        A = temp;
        uint32_t t = rotl(B * (2 * B + 1), 5);
        uint32_t u = rotl(D * (2 * D + 1), 5);

        C = rotr(C - S[2 * i + 1], t) ^ u;
        A = rotr(A - S[2 * i], u) ^ t;

    }

    D -= S[1];
    B -= S[0];

    blk[0] = A; blk[1] = B; blk[2] = C; blk[3] = D;

}
