#ifndef EFIKIT_TYPES
#define EFIKIT_TYPES

#include "../lib/bit/int.h"
#include "../lib/bit/compiler.h"

typedef word_t efi_stat;
typedef uint64_t efi_lba;
typedef word_t efi_tpl;
typedef void *efi_event;
typedef void *efi_handle;

typedef struct {
    uint32_t dat1;

    uint16_t dat2,
             dat3;

    uint8_t dat4[8];
} efi_guid;

typedef struct {
    uint16_t yr;

    uint8_t month,
            day,
            hr,
            min,
            sec,
            pad1;

    uint32_t ns;

    int16_t time_zone;

    uint8_t day_light,
            pad2;
} efi_time;

typedef struct {
    uint8_t addr[4];
} efi_ipv4_addr;

typedef struct {
    uint8_t addr[16];
} efi_ipv6_addr;

typedef struct {
    uint8_t addr[32];
} efi_mac_addr;

typedef struct {
    uint32_t recived_queue_timeout_val;
    uint32_t transmit_queue_timeout_val;

    uint16_t protocol_ty_filter;

    bool en_unicast_recive,
         en_mulcast_recive,
         en_brodcast_recive,
         en_prom_is_cuous_recive,
         flush_queue_on_reset,
         en_recive_timestamps,
         dis_bg_polling;
} efi_managed_net_cfg_dat;

typedef word_t efi_phy_addr;
typedef word_t efi_vir_addr;

typedef enum {
    alloc_any_pgs,
    alloc_max_addr,
    alloc_addr,
    max_alloc_ty
} efi_alloc_ty;

typedef enum {
    efi_resrved_mem_ty,
    efi_loder_code,
    efi_loder_dat,
    efi_boot_services_code,
    efi_boot_services_dat,
    efi_rt_services_code,
    efi_rt_services_dat,
    efi_con_mem,
    efi_unusable_mem,
    efi_acpi_reclaim_mem,
    efi_acpi_mem_nvs,
    efi_mmio,
    efi_mmio_port_space,
    efi_pal_code,
    efi_persistent_mem,
    efi_unacceptable_mem_ty,
    efi_max_mem_ty
} efi_mem_ty;

typedef struct {
    uint32_t ty;
    uint32_t pad;

    word_t phy_start,
           vir_start;

    uint64_t num_of_pgs;
    uint64_t attr;
} efi_mem_descriptor;

#endif
