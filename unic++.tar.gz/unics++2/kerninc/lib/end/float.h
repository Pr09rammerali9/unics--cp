#ifndef END_FLOAT_H
#define END_FLOAT_H

#include "../compiler.h"
#include "../bit/compiler.h" 
#include "../bit/int.h"      
#include "../mem.h"          

static attr(__always_inline__) _Float32 __swpf(_Float32 x) {

    union {
        
        _Float32 f;
    
        uint32_t i;
    
    } u = { .f = x };
    
    u.i = __swp32(u.i);

    return u.f;

}

static attr(__always_inline__) _Float64 __swpdl(_Float64 x) {

    union {
    
        _Float64 d;
        
        uint64_t i;
    
    } u = { .d = x };
    
    u.i = __swp64(u.i);

    return u.d;

}

#ifdef LILEND

#define __htobef(x) __swpf(x)
#define __htobedl(x) __swpdl(x)

#define __htolef(x) (x)
#define __htoledl(x) (x)

#else 

#define __htobef(x) (x)
#define __htobedl(x) (x)

#define __htolef(x) __swpf(x)
#define __htoledl(x) __swpdl(x)

#endif 

#define __beftohf(x) __htobef(x)
#define __bedltohd(x) __htobedl(x)
#define __leftohf(x) __htolef(x)
#define __ledltohd(x) __htoledl(x)

#endif
