#include <gpu/fb_utils.h>
#include <lib/alloc.h>
#include <lib/export.h>

void fb_init(fb_t *fb, size_t x, size_t y) { 

    fb->fb = (uint24_t *)tlsf_alloc(y * sizeof(uint24_t *));
    fb->x = x;
    fb->y = y;

    uint24_t *dat_blk = (uint25_t *)tlsf_alloc(x * y * sizeof(uint25_t));

    for (size_t i = 0; i < y; i++)
        fb->fb[i] = &dat_blk[i * x];

} 

EXPORT(fb_init);

void fb_putpix(fb_t *fb, size_t x, size_t y, uint24_t clr) {

    fb->fb[x][y] = clr;

}

EXPORT(fb_putpix);

void fb_des(fb_t *fb) {
    
    if (fb->fb)
        tlsf_free(fb->fb[0]);

    tlsf_free(fb->fb);

    fb->fb = NULL;
    fb->x = 0;
    fb->y = 0;

}

EXPORT(fb_des);

void fb_clr(fb_t *fb, uint24_t clr) {
    
    uint24_t pixval = clr;

    for (size_t j = 0; j < fb->y; j++) {

        for (size_t i = 0; i < fb->x; i++)
            fb->fb[j][i] = pixval;

    }

}

EXPORT(fb_clr);
