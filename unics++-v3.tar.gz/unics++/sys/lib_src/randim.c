#include <lib/bit/int.h>
#include <lib/rng.h>
#include <crypto/sha1.h>
#include <lib/mem.h>
#include <lib/export.h>

#define ROTL64(x, k) ((x << k) | (x >> (64 - k)))
#define CADD 0x9E3779B97F4A7C15ULL
#define CMUL 0xBF58476D1CE4E5B9ULL

static uint8_t outbuf[20] = { 0 };

static uint64_t rng_ctx[4] = { 0 },
                h[2] = { 0 };

static sha1_ctx sha_ctx;

static uint32_t h2 = 0;

static void rng_upd(void) {

    uint64_t s[4];

    memcpy(s, rng_ctx, sizeof(rng_ctx));

    s[1] ^= ROTL64(s[0], 24);
    s[2] += s[3];
    s[1] = s[0] - s[2];

    s[3] = ROTL64(s[0], 11) | s[1];
    s[0] = ROTL64(s[0], 7);
    s[1] += CADD;

    s[2] ^= s[0];
    s[3] = (s[3] * CMUL) & 0xFFFFFFFFFFFFFFF0ULL;

    memcpy(rng_ctx, s, sizeof(rng_ctx));

}

void randim_seed(uint64_t seed) {

    uint64_t *S = rng_ctx;

    S[0] = seed;

    for (uint8_t i = 1; i < 4; i++)
        S[i] = (S[i - 1] * 0x6C0789657C64790FLL) + 0x600DCAFEDEADBEEFULL;

    uint8_t i;

    for (i = 0; i < 10; i++)
        rng_upd();

    uint8_t digset[20] = { 0 },
            dat_to_hash[sizeof(rng_ctx) + 1] = { 0 };

    for (i = 0; i < 7; i++) {

        memcpy(dat_to_hash, rng_ctx, sizeof(rng_ctx));

        dat_to_hash[sizeof(rng_ctx)] = i;

        sha1_init(&sha_ctx);

        sha1_upd(&sha_ctx, dat_to_hash, sizeof(dat_to_hash));

        sha1_final(digset, &sha_ctx);

        memcpy(&h[0], &digset[0], 8);
        memcpy(&h[1], &digset[8], 8);
        memcpy(&h2, &digset[16], 4);

        S[0] ^= __be64toh(h[0]);
        S[1] ^= __be64toh(h[1]);
        S[2] ^= (uint64_t)__be32toh(h2);
    
    }

}

EXPORT(randim_seed);

uint8_t* randim_rnd(void) {

    sha1_ctx sctx;

    sha1_init(&sctx);

    sha1_upd(&sctx, (uchar *)rng_ctx, sizeof(rng_ctx));

    sha1_final(outbuf, &sctx);

    rng_upd();

    return outbuf;

}

EXPORT(randim_rnd);
