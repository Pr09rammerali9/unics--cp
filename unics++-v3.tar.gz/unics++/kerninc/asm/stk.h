#ifndef STK_H
#define STK_H

#include "../lib/bit/ptr.h"

static inline void set_sp(uintptr_t sp) {

#if defined(__i386__) || defined(__i686__)

    __asm__ volatile(
        "mov %0, %%esp"
        :
        : "r" (sp)
        : "memory"
    );

#elif defined(__x86_64__)
    
    __asm__ volatile(
        "mov %0, %%rsp"
        :
        : "r" (sp)
        : "memory"
    );

#elif defined(__aarch64__) || defined(__arm__)
    
    __asm__ volatile(
        "mov sp, %0"
        :
        : "r" (sp)
        : "memory"
    );

#elif defined(__riscv)
    
    __asm__ volatile(
        "mv sp, %0"
        :
        : "r" (sp)
        : "memory"
    );

#elif defined(__pdp11__)
    
    __asm__ volatile(
        "mov %0, sp"
        :
        : "r" (sp)
        : "memory"
    );

#elif defined(__m68k__)

    __asm__ volatile(
        "moveal %0, %%sp"
        :
        : "r" (sp)
        : "memory"
    );

#elif defined(__vax__)
    
    __asm__ volatile(
        "movl %0, sp"
        :
        : "r" (sp)
        : "memory"
    );

#elif defined(__ia64__)
    
    __asm__ volatile(
        "mov r12 = %0"
        :
        : "r" (sp)
        : "memory"
    );

#elif defined(__mips__)
    
    __asm__ volatile(
        "move $sp, %0"
        :
        : "r" (sp)
        : "memory"
    );

#elif defined(__sparc__)
    
    __asm__ volatile(
        "mov %0, %%sp"
        :
        : "r" (sp)
        : "memory"
    );

#elif defined(__W65C816__)

    __asm__ volatile(
        "tcs"
        :
        : "a" (sp)
        : "memory"
    );

#endif

}

static inline void set_bp(uintptr_t bp) {
#if defined(__i386__) || defined(__i686__)
    
    __asm__ volatile(
        "mov %0, %%ebp"
        :
        : "r" (bp)
        : "memory"
    );

#elif defined(__x86_64__)
    
    __asm__ volatile(
        "mov %0, %%rbp"
        :
        : "r" (bp)
        : "memory"
    );

#elif defined(__m68k__)

    __asm__ volatile(
        "moveal %0, %%a6"
        :
        : "r" (bp)
        : "memory"
    );

#elif defined(__vax__)
    
    __asm__ volatile(
        "movl %0, fp"
        :
        : "r" (bp)
        : "memory"
    );

#elif defined(__mips__)

    __asm__ volatile(
        "move $fp, %0"
        :
        : "r" (bp)
        : "memory"
    );

#else

    (void)bp;

#endif

}

static inline void stk_push(uintptr_t val) {

#if defined(__i386__) || defined(__x86_64__)

    __asm__ volatile(
        "push %0"
        :
        : "r" (val)
        : "memory"
    );

#elif defined(__aarch64__)
    
    __asm__ volatile(
        "str %0, [sp, #-16]!"
        :
        : "r" (val)
        : "memory"
    );

#elif defined(__arm__)

    __asm__ volatile(
        "push {%0}"
        :
        : "r" (val)
        : "memory"
    );

#elif defined(__riscv)

#if __riscv_xlen == 64
    
    __asm__ volatile(
        "addi sp, sp, -8; sd %0, 0(sp)"
        :
        : "r" (val)
        : "memory"
    );

#else

    __asm__ volatile(
        "addi sp, sp, -4; sw %0, 0(sp)"
        :
        : "r" (val)
        : "memory"
    );

#endif

#elif defined(__m68k__)

    __asm__ volatile(
        "move %0, -(%%sp)"
        :
        : "r" (val)
        : "memory"
    );

#elif defined(__pdp11__)

    __asm__ volatile(
        "mov %0, -(sp)"
        :
        : "r" (val)
        : "memory"
    );

#endif

}

static inline uintptr_t stk_pop(void) {

    uintptr_t val;

#if defined(__i386__) || defined(__x86_64__)

    __asm__ volatile(
        "pop %0"
        : "=r" (val)
        :
        : "memory"
    );

#elif defined(__aarch64__)
    
    __asm__ volatile(
        "ldr %0, [sp], #16"
        : "=r" (val)
        :
        : "memory"
    );

#elif defined(__arm__)
    
    __asm__ volatile(
        "pop {%0}"
        : "=r" (val)
        :
        : "memory"
    );

#elif defined(__m68k__)
    
    __asm__ volatile(
        "move (%%sp)+, %0"
        : "=r" (val)
        :
        : "memory"
    );

#elif defined(__pdp11__)
    
    __asm__ volatile(
        "mov (sp)+, %0"
        : "=r" (val)
        :
        : "memory"
    );

#endif

    return val;

}

static inline void stk_pusha(void) {

#if defined(__i386__) || defined(__i686__)
    
    __asm__ volatile(
        "pushal"
        :
        :
        : "memory"
    );

#elif defined(__x86_64__)

    __asm__ volatile(
        "push %%rax; push %%rcx; push %%rdx; push %%rbx; push %%rsi; push %%rdi; push %%r8; push %%r9; push %%r10; push %%r11; push %%r12; push %%r13; push %%r14; push %%r15"
        :
        :
        : "memory"
    );

#elif defined(__m68k__)
    
    __asm__ volatile(
        "moveml %%d0-%%d7/%%a0-%%a6, -(%%sp)"
        :
        :
        : "memory"
    );

#elif defined(__vax__)

    __asm__ volatile(
        "pushr $0x3FFF"
        :
        :
        : "memory"
    );

#elif defined(__arm__)

    __asm__ volatile(
        "stmdb sp!, {r0-r12, lr}"
        :
        :
        : "memory"
    );

#endif

}

static inline void stk_popa(void) {

#if defined(__i386__) || defined(__i686__)
    
    __asm__ volatile(
        "popal"
        :
        :
        : "memory"
    );

#elif defined(__x86_64__)
    
    __asm__ volatile(
        "pop %%r15; pop %%r14; pop %%r13; pop %%r12; pop %%r11; pop %%r10; pop %%r9; pop %%r8; pop %%rdi; pop %%rsi; pop %%rbx; pop %%rdx; pop %%rcx; pop %%rax"
        :
        :
        : "memory"
    );

#elif defined(__m68k__)
    
    __asm__ volatile(
        "moveml (%%sp)+, %%d0-%%d7/%%a0-%%a6"
        :
        :
        : "memory"
    );

#elif defined(__vax__)

    __asm__ volatile(
        "popr $0x3FFF"
        :
        :
        : "memory"
    );

#elif defined(__arm__)

    __asm__ volatile(
        "ldmia sp!, {r0-r12, lr}"
        :
        :
        : "memory"
    );

#endif

}

#endif
