#ifndef TTY_H
#define TTY_H

#include "def.h"
#include "alloc.h"
#include "bit/int.h"
#include "mem.h"
#include "abort.h"
#include "str.h"

typedef struct vt_t vt_t;

typedef struct {
    char c;
    uint8_t clr;
} vt_ch;

typedef void (*scr_handler)(vt_t *vt);

typedef struct vt_t {
    size_t rows;
    size_t cols;
    size_t cur_col;
    size_t cur_row;

    vt_ch *buf;

    scr_handler handler;
} vt_t;

#ifndef TTYSRC

static vt_t term = {0, 0, 0, 0, NULL, NULL};

#endif

void *vt_init(vt_t *vt, size_t rows, size_t cols);
void vt_putch(vt_t *vt, char c, uint8_t clr);
void vt_putstr(vt_t *vt, const char *s, uint8_t clr);
void vt_uninit(vt_t *vt);

#define vt_info(vt, s, clr) vt_putstr(vt, "[INFO]" s, clr)
#define vt_db(vt, s, clr) vt_putstr(vt, "[DB]" s, clr)
#define vt_warn(vt, s, clr) vt_putstr(vt, "[WARN]" s, clr)
#define vt_err(vt, s, clr) vt_putstr(vt, "[ERR]" s, clr)
#define vt_panic(vt, s, clr) do { vt_putstr(vt, "[PANIC]" s, clr); abort(); } while (0)

#define TTY_LOG(handler, rows, cols) \
    do { \
        term.handler = handler; \
        term.rows = rows; \
        term.cols = cols; \
        vt_init(&term, rows, cols); \
    } while (0)

#endif
