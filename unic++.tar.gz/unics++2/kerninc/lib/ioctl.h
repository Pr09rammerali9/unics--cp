#ifndef LIB_IOCTL_H
#define LIB_IOCTL_H

#define IOC_NRMSK ((1 << 8) - 1)
#define IOC_TYMSK ((1 << 8) - 1)
#define IOC_SZMSK ((1 << 14) -1)
#define IOC_DIRMSK ((1 << 2) - 1)

#define IOC_TYSH (0 + 8)
#define IOC_SZSH (IOC_TYSH + 8)
#define IOC_DIRSH (IOC_SZSH + 14)

#define _IOC(dir, ty, nr, sz) \
    (((dir) << IOC_DIRSH) | ((ty) << IOC_TYSH) | ((nr) << 0) | ((sz) << IOC_SZSH))

#define _IO(ty, nr) _IOC(0U, (ty), (nr), 0)
#define _IOR(ty, nr, argty) _IOC(2U, (ty), (nr), sizeof(argty))
#define _IOW(ty, nr, argty) _IOC(1U, (ty), (nr), sizeof(argty))
#define _IOWR(ty, nr, argty) _IOC(1U | 2U, (ty), (nr), sizeof(argty))

#define _IOC_DIR(nr) (((nr) >> IOC_DIRSH) & IOC_DIRMSK)
#define _IOC_TY(nr) (((nr) >> IOC_TYSH) & IOC_TYMSK)
#define _IOC_NR(nr) (((nr) >> IOC_NRSH) & IOC_NRMSK)
#define _IOC_SZ(nr) (((nr) >> IOC_SZSH) & IOC_SZMSK)

#define IOC_IN (1U << IOC_DIRSH)
#define IOC_OUT (2U << IOC_DIRSH)
#define IOC_INOUT ((1U | 2U) << IOC_DIRSH)
#define IOCSZ_MSK (IOC_SZMSK << IOC_SZSH)
#define IOCSZ_SH (IOC_SZSH) 

#endif
