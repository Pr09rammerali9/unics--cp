#ifndef BOOTEXEFMT_H
#define BOOTEXEFMT_H

#include <lib/bit/int.h>
#include <lib/def.h>
#include <lib/compiler.h>

typedef struct __packed {
    uint16_t mach;
    uint16_t num_of_sections;
    
    uint32_t time_dates_stamp;
    uint32_t ptr_to_symtbl;
    uint32_t num_of_syms;

    uint16_t sizeof_optional_hdr;
    uint16_t characteristics;
} kexe_filhdr;

typedef struct __packed {
    char name[12];

    uint32_t virsz;
    uint32_t vaddr;
    uint32_t szof_rawdat;
    uint32_t ptr_to_rawdat;
    uint32_t ptr_to_relocs;
    uint32_t ptr_to_line_nums;

    uint16_t num_of_relocs;
    uint16_t num_of_line_nums;

    uint32_t characteristics;
} kexe_sechdr;

typedef struct __packed {
    uint32_t vaddr;
    uint32_t symtbl_idx;

    uint16_t ty;
} kexe_reloc;

typedef struct __packed {
    kexe_filhdr *filhdr;

    kexe_sechdr *sechdr;

    kexe_reloc *reloc_tbl;

    void *strt_addr;

    uint32_t num_of_sections;
} kexe_t;

#endif 
