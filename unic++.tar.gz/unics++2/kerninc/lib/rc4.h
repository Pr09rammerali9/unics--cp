#ifndef RC4_H
#define RC4_H

#warning "DONT INCLUDE THIS IF UR SHIT IS SECURE"

#include "def.h"
#include "bit/int.h"
#include "mem.h"

typedef struct {
    uint8_t S[256];
    uint8_t i;
    uint8_t j;
} rc4_ctx;

void rc4_init(rc4_ctx *ctx, const uint8_t *key, size_t len);

void rc4_encrypt(rc4_ctx *ctx, const uint8_t *in, uint8_t *out, size_t len);

void rc4_crypt(rc4_ctx *ctx, uint8_t *data, size_t len);

void rc4_rand(rc4_ctx *ctx, uint8_t *out, size_t len);

#endif // RC4_H
