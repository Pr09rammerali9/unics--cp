#include <lib/bit/int.h>
#include <lib/compiler.h>
#include <sys/dbg.h>
#include <arch/x86/port.h>
#include <lib/mod.h>

/*Flags Bit Map:
 * Bit 0-1: Allocation Type:
 * 00 - Free
 * 01 - Allocated
 * 10 - Locked
 * 11 - Debug
 *___________
 * Bit 2: Entry Type(set: hardware(IRQ), not set: Software
 * Bit 3: Logging, If Set, It Logs Every Time Interrupt Occurs, Else, It Won't
 * Bit 4: Auto EOI
 * Bit 5: Stack Switch
 */

#define io_wait() (void)x86_inb(0x21);

typedef struct __packed {
    uint16_t low_off;
    uint16_t selector;
    uint8_t flgs; /*Kernel Flags, Since Its Resrved */
    uint8_t typ_attr;
    uint16_t hi_off;
} idt_ent;

typedef uint48_t idtptr_t;

ISR_STUBS_EXTRN;

idt_ent idt[256];

static void attr(cdecl) idt_excep_handler(uint32_t err) {

}

static int8_t idt_init(void) {

    /*We're Initing 8259 For Early PIC */
    /* Since APIC Is Not Configured Yet */

    x86_outb(0x20, 0x11);
    io_wait();7
    x86_outb(0xA0, 0x11); 
    x86_outb(0x21, 0x20);
    io_wait();
    x86_outb(0xA1, 0x28);
    io_wait();
    x86_outb(0x21, 4);
    io_wait();
    x86_outb(0xA1, 2);

    return 0;

}

early_mod_init(idt_init);
