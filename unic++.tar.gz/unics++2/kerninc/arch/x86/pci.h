#ifndef X86_PCI
#define X86_PCI

#include "../../lib/bit/ops.h"
#include "../../lib/bit/int.h"
#include "../../lib/ls.h"
#include "../../asm/x86/port.h"

#define PCI_CFG_ADDR_PORT 0xcf8
#define PCI_CFG_DAT_PORT 0xcfc
#define PCI_CFG_VENDOR_ID 0
#define PCI_CFG_DEV_ID 0x02
#define PCI_CFG_CMD 0x04
#define PCI_CFG_STATUS 0x06
#define PCI_CFG_REVN_ID 0x08
#define PCI_CFG_PROG_IF 0x09
#define PCI_CFG_SUBCLSS 0x0a
#define PCI_CFG_CLSS_COD 0x0b
#define PCI_CFG_BIST 0x0f
#define PCI_CFG_HDR_TYPE 0x0e
#define PCI_CFG_BAR0 0x10
#define PCI_CFG_BAR1 0x14
#define PCI_CFG_BAR2 0x18
#define PCI_CFG_BAR3 0x1C
#define PCI_CFG_BAR4 0x20
#define PCI_CFG_BAR5 0x24 
#define PCI_HDR_TYPE_NORM 0
#define PCI_HDR_TYPE_BRIDGE 0x01
#define PCI_HDR_TYPE_CRDBUS 0x02

typedef struct {
    uint8_t bus;
    uint8_t dev;
    uint8_t fn;
    uint8_t off;
    
    uint16_t ven_id;
    uint16_t dev_id;

    uint8_t clss_code;
    uint8_t subclss;
} pci_dev_t;

void pci_init(void);

uint32_t pci_rd(pci_dev_t *dev);

void pci_wr(pci_dev_t *dev, uint32_t val);

dbl_linked_ls *pci_gt_devs(void);
dbl_linked_ls *pci_gt_dev(uint16_t ven_id, uint16_t dev_id);

char *pci_dev_type(pci_dev_t *dev);

#endif
