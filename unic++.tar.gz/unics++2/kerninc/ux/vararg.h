/*unix v7:stdarg.h*/
#ifndef VARARG_H
#define VARARG_H

typedef char *ux_va_list;
# define ux_va_dcl int va_alist;
# define ux_va_start(list) list = (char *) &va_alist
# define ux_va_end(list)
# define ux_va_arg(list,mode) ((mode *)(list += sizeof(mode)))[-1]

#endif
