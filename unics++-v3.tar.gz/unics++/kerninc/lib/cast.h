#ifndef LIB_CAST_H
#define LIB_CAST_H

#include "mem.h"
#include "bit/int.h"

static inline uint8_t cast_uint8(const void *p) {

    if (!p)
        return 0;

    uint8_t val = 0;

    memcpy(&val, p, 1);

    return val;

}

#define cast_int8(p) cast_uint8(p)

static inline uint16_t cast_uint16(const void *p) {

    if (!p)
        return 0;

    uint16_t val = 0;

    memcpy(&val, p, 2);

    return val;

}

#define cast_int16(p) cast_uint16(p)

static inline uint32_t cast_uint32(const void *p) {

    if (!p)
        return 0;

    uint32_t val = 0;

    memcpy(&val, p, 4);

    return val;


}

#define cast_int32(p) cast_uint32(p)

static inline uint64_t cast_uint64(const void *p) {

    if (!p)
        return 0;

    uint64_t val = 0;

    memcpy(&val, p, 8);

    return val;

}

#define cast_typ(typ, p, store_var) do { \
    if (p) \
        memcpy(&store_var, p, sizeof(typ));\
    else \
        store_var = 0;
    } while (0)

#define cast(p, v) _Generic((var), \
    uint8_t:  var = cast_uint8(p), \
    uint16_t: var = cast_uint16(p), \
    uint32_t: var = cast_uint32(p), \
    uint64_t: var = cast_uint64(p), \
    int8_t:  var = cast_int8(p), \
    int16_t: var = cast_int16(p), \
    int32_t: var = cast_int32(p), \
    int64_t: var = cast_int64(p) \
    )

#endif
