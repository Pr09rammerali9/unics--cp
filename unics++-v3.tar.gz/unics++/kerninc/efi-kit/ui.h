/*for stupid ui stuff*/
#ifndef EFI_UI_H
#define EFI_UI_H

#include "../lib/bit/int.h"

#define EFI_UI_INTERFACE_PROTC_GUID { 0x32dd7981, 0x2d27, 0x11d4, {0xbc, 0x8b, 0x0, 0x80, 0xc7, 0x3c, 0x88, 0x81} }
#define EFI_UI_PROTC EFI_UI_INTERFACE_PROTC_GUID
#define EFI_UI_VER 0x0001000

typedef enum {
    ui_dev_str,
    ui_ven_str,
    ui_max_str
} ui_str_ty;

typedef struct {
    uint8_t *lang_code;

    uint16_t *ui_str;
} ui_str;

typedef ui_str ui_str_entry;

typedef struct {
    uint32_t ver;

    ui_str *entry;
} ui_interface;

#endif 
