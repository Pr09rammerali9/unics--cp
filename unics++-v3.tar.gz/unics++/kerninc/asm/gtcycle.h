#ifndef ASM_DLY
#define ASM_DLY

#include <stdint.h>
#include <stddef.h> // Required for size_t

static inline size_t get_cycle(void) {

#if defined(__x86_64__)

    uint32_t low, high;
    
    asm volatile("rdtscp" 
            : "=a"(low), "=d"(high) 
            :
            : "rcx"
            );
    
    return (size_t)(((uint64_t)high << 32) | low);

#elif defined(__i386__)
    
    uint32_t val;
    
    asm volatile("rdtsc" : "=a"(val) 
            :
            : "edx"
            );
    
    return (size_t)val;

#elif defined(__aarch64__)

    uint64_t val;
    
    asm volatile("isb; mrs %0, cntpct_el0" 
            : "=r"(val)
            );
    
    return (size_t)val;

#elif defined(__arm__)

    uint32_t low;
    
    asm volatile("mrrc p15, 0, %0, r1, c14" 
            : "=r"(low)
            );
    
    return (size_t)low;

#elif defined(__riscv)

    #if __riscv_xlen == 64

        uint64_t val;
        
        asm volatile("rdtime %0" 
                : "=r"(val)
                );
    
        return (size_t)val;

    #else
        
        uint32_t lo;

        asm volatile("rdtime %0" 
                : "=r"(lo)
                );
    
        return (size_t)lo;
    
    #endif

#elif defined(__mips__)

    uint32_t val;
    
    asm volatile("mfc0 %0, $9" 
            : "=r"(val)
            );

    return (size_t)val;

#elif defined(__sparc__)
    #if defined(__arch64__) || defined(__sparc_v9__)

        uint64_t val;
        
        asm volatile("rd %%tick, %0" 
                : "=r"(val)
                );
    
        return (size_t)val;

    #else

        uint32_t lo;

        asm volatile("rd %%tick, %0" 
                : "=r"(lo)
                );
    
        return (size_t)lo;

    #endif

#elif defined(__ia64__)
    
    uint64_t val;
    
    asm volatile("mov %0 = ar.itc" 
            : "=r"(val)
            );
    
    return (size_t)val;

#elif defined(__hppa__)

    uintptr_t val;
    
    asm volatile("mfctl 16, %0" 
            : "=r"(val)
            );
    
    return (size_t)val;

#elif defined(__pdp11__)

    return (size_t)(*(volatile uint16_t*)0177546);

#elifdef __m88k__

    uint32_t val;

    asm volatile("mrcc p15, 0, %0, r1, c14"
            : "=r" (val)
            );
    
    return (size_t)val;

#else

    return 0;

#endif

}

#endif
