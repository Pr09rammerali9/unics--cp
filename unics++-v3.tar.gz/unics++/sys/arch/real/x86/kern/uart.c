#include <arch/x86/uart.h>
#include <lib/export.h>

static int detected_uart_type = 0;
#define SERIAL_IIR_PORT(base)       ((base) + 2)
#define SERIAL_FCR_PORT(base)       ((base) + 2)
#define SERIAL_SCR_PORT(base)       ((base) + 7)

void arch_uart_init() {

    unsigned char iir_val;

    outb(SERIAL_PORT_BASE + 1, 0x00);
    outb(SERIAL_LINE_COMMAND_PORT(SERIAL_PORT_BASE), SERIAL_LINE_ENABLE_DLAB);
    outb(SERIAL_PORT_BASE + 0, 0x01);
    outb(SERIAL_PORT_BASE + 1, 0x00);
    outb(SERIAL_LINE_COMMAND_PORT(SERIAL_PORT_BASE), 0x03);
    outb(SERIAL_FIFO_COMMAND_PORT(SERIAL_PORT_BASE), 0xC7);
    outb(SERIAL_MODEM_COMMAND_PORT(SERIAL_PORT_BASE), 0x0B);

    iir_val = inb(SERIAL_IIR_PORT(SERIAL_PORT_BASE));

    if (iir_val & 0xC0) {
        detected_uart_type = 1;

        outb(SERIAL_SCR_PORT(SERIAL_PORT_BASE), 0xAE);

        if (inb(SERIAL_SCR_PORT(SERIAL_PORT_BASE)) == 0xAE)
            detected_uart_type = 2;

        outb(SERIAL_SCR_PORT(SERIAL_PORT_BASE), 0x00);

    } else {

        detected_uart_type = 0;
        
        outb(SERIAL_FIFO_COMMAND_PORT(SERIAL_PORT_BASE), 0x00);

    }

    if (detected_uart_type >= 1)
        outb(SERIAL_FIFO_COMMAND_PORT(SERIAL_PORT_BASE), 0xC7);

}

EXPORT(uart_init);

void arch_uart_wr(char c) {

    while ((inb(SERIAL_LINE_STATUS_PORT(SERIAL_PORT_BASE)) & 0x20) == 0);
    
    outb(SERIAL_DATA_PORT(SERIAL_PORT_BASE), c);

}

EXPORT(uart_wr);

void arch_uart_puts(char s[]) {

    while (*s) {
    
        uart_wr(*s);
        
        s++;

    }

}

EXPORT(uart_puts);

char arch_uart_rd(void) {
    
     while ((inb(SERIAL_LINE_STATUS_PORT(SERIAL_PORT_BASE)) & 0x01) == 0);

     return inb(SERIAL_DATA_PORT(SERIAL_PORT_BASE));

}
