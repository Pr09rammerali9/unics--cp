/*
 * Clean room implementation of glibc atomic.h
 * This header is free from any kind of gpl licensed code
 * Any blames is not correct
 * For legal issues, please contact the owner:
 * Pr09rammerali9 on github in issues
 */
#ifndef ATOMIC_H
#define ATOMIC_H

#include "bit/int.h"

typedef _Atomic volatile int atomic_t;
typedef _Atomic volatile unsigned int uatomic_t;
typedef _Atomic volatile char catomic_t;
typedef _Atomic volatile unsigned char ucatomic_t;
typedef _Atomic volatile short satomic_t;
typedef _Atomic volatile unsigned short usatomic_t;
typedef _Atomic volatile long latomic_t;
typedef _Atomic volatile unsigned long ulatomic_t;
typedef _Atomic volatile long long llatomic_t;
typedef _Atomic volatile unsigned long long ullatomic_t;

#define atom_var(type, name) _Atomic volatile type name
#define atom_ty(bse_ty, ty) typedef _Atomic volatile bse_ty ty

#ifdef USE_SYNC
#define ATOMIC_RELAXED
#define ATOMIC_ACQUIRE
#define ATOMIC_RELEASE
#define ATOMIC_ACQ_REL
#define ATOMIC_SEQ_CST

#define atomic_load_explicit(ptr, order) \
    __sync_fetch_and_add((ptr), 0)

#define atomic_store_explicit(ptr, val, order) \
    __sync_lock_test_and_set((ptr), (val))

#define atomic_exchange_explicit(ptr, val, order) \
    __sync_lock_test_and_set((ptr), (val))

#define atomic_compare_exchange_explicit(ptr, expected, desired, success_order, failure_order) \
    __sync_bool_compare_and_swap((ptr), *(expected), (desired))

#define atomic_thread_fence(order) \
    __sync_synchronize()

#define atomic_fetch_add_explicit(ptr, val, order) \
    __sync_fetch_and_add((ptr), (val))

#define atomic_fetch_sub_explicit(ptr, val, order) \
    __sync_fetch_and_sub((ptr), (val))

#define atomic_fetch_and_explicit(ptr, val, order) \
    __sync_fetch_and_and((ptr), (val))

#define atomic_fetch_or_explicit(ptr, val, order) \
    __sync_fetch_and_or((ptr), (val))

#define atomic_fetch_xor_explicit(ptr, val, order) \
    __sync_fetch_and_xor((ptr), (val))

#else
#define ATOMIC_RELAXED __ATOMIC_RELAXED
#define ATOMIC_ACQUIRE __ATOMIC_ACQUIRE
#define ATOMIC_RELEASE __ATOMIC_RELEASE
#define ATOMIC_ACQ_REL __ATOMIC_ACQ_REL
#define ATOMIC_SEQ_CST __ATOMIC_SEQ_CST

#define atomic_load_explicit(ptr, order) \
    __atomic_load_n((_Atomic __typeof__(*(ptr)) *)(ptr), (order))

#define atomic_store_explicit(ptr, val, order) \
    __atomic_store_n((_Atomic __typeof__(*(ptr)) *)(ptr), (val), (order))

#define atomic_exchange_explicit(ptr, val, order) \
    __atomic_exchange_n((_Atomic __typeof__(*(ptr)) *)(ptr), (val), (order))

#define atomic_compare_exchange_explicit(ptr, expected, desired, success_order, failure_order) \
    __atomic_compare_exchange_n((_Atomic __typeof__(*(ptr)) *)(ptr), (expected), (desired), 0, (success_order), (failure_order))

#define atomic_thread_fence(order) \
    __atomic_thread_fence(order)

#define atomic_fetch_add_explicit(ptr, val, order) \
    __atomic_fetch_add((ptr), (val), (order))

#define atomic_fetch_sub_explicit(ptr, val, order) \
    __atomic_fetch_sub((ptr), (val), (order))

#define atomic_fetch_and_explicit(ptr, val, order) \
    __atomic_fetch_and((ptr), (val), (order))

#define atomic_fetch_or_explicit(ptr, val, order) \
    __atomic_fetch_or((ptr), (val), (order))

#define atomic_fetch_xor_explicit(ptr, val, order) \
    __atomic_fetch_xor((ptr), (val), (order))
#endif

#define atomic_load(ptr) \
    atomic_load_explicit((ptr), ATOMIC_SEQ_CST)

#define atomic_store(ptr, val) \
    atomic_store_explicit((ptr), (val), ATOMIC_SEQ_CST)

#define atomic_exchange(ptr, val) \
    atomic_exchange_explicit((ptr), (val), ATOMIC_SEQ_CST)

#define atomic_compare_exchange(ptr, expected, desired) \
    atomic_compare_exchange_explicit((ptr), (expected), (desired), ATOMIC_SEQ_CST, ATOMIC_SEQ_CST)

#define atomic_add(ptr, val) \
    (void)atomic_fetch_add_explicit((ptr), (val), ATOMIC_SEQ_CST)

#define atomic_sub(ptr, val) \
    (void)atomic_fetch_sub_explicit((ptr), (val), ATOMIC_SEQ_CST)

#define atomic_increment(ptr) \
    (void)atomic_fetch_add_explicit((ptr), 1, ATOMIC_SEQ_CST)

#define atomic_decrement(ptr) \
    (void)atomic_fetch_sub_explicit((ptr), 1, ATOMIC_SEQ_CST)

#define atomic_max(ptr, val) \
    do { \
        __typeof__(*(ptr)) oldval; \
        do { \
            oldval = atomic_load_explicit((ptr), ATOMIC_RELAXED); \
            if (oldval >= (val)) break; \
        } while (!atomic_compare_exchange_explicit((ptr), &oldval, (val), ATOMIC_SEQ_CST, ATOMIC_RELAXED)); \
    } while (0)

#define atomic_min(ptr, val) \
    do { \
        __typeof__(*(ptr)) oldval; \
        do { \
            oldval = atomic_load_explicit((ptr), ATOMIC_RELAXED); \
            if (oldval <= (val)) break; \
        } while (!atomic_compare_exchange_explicit((ptr), &oldval, (val), ATOMIC_SEQ_CST, ATOMIC_RELAXED)); \
    } while (0)

#endif
