#include <lib/str.h>
#include <lib/arg.h>
#include <lib/def.h>
#include <lib/bit/int.h>
#include <lib/bit/limits.h>
#include <lib/export.h>

#define flgs_LEFT_JUSTIFY   0x01
#define flgs_SIGN_ALWAYS    0x02
#define flgs_SIGN_SPACE     0x04
#define flgs_ZERO_PAD       0x08
#define flgs_ALTERNATE      0x10
#define flgs_UPPERCASE      0x20

#define len_NONE            0
#define len_L               1
#define len_LL              2

typedef struct {
    int flgs;
    int width;
    int precision;
    int length;

    char specifier;
} fmt_spec_t;

typedef struct {
    size_t sz;
    size_t written;

    char *buf;
    va_list arg;
} vsprf_t;

static const char* _parse_spec(const char *fmt, format_spec_t *spec, vsprf_t *state);

static size_t _i_format_int(vsprf_t *state, const format_spec_t *spec);
static size_t _i_format_str(vsprf_t *state, const format_spec_t *spec);

static void _write_char(vsprf_t *state, char c);

static size_t _utoa_base(uintmax_t val, int base, char *buf, size_t buf_len, int uppercase);

static void _write_string_padded(vsprf_t *state, const char *str, size_t len, const format_spec_t *spec, char sign_prefix);

int vsnprfmt(char *buf, size_t sz, const char fmt[], va_list arg) {

    vsprf_t state;
    state.sz = sz;
    state.written = 0;
    state.buf = buf;
    va_copy(state.arg, arg); 

    if (sz > 0)
        state.buf[0] = '\0';
    else
        state.buf = NULL;

    const char *p = fmt;
    
    while (*p) {
    
        if (*p != '%') {

            _write_char(&state, *p++);
            
            continue;
            
        }

        fmt_spec_t spec = { 0 };

        p = _parse_spec(p + 1, &spec, &state);
        if (!p)
            break;

        switch (spec.specifier) {
            case 'd': 
            case 'i': 
            case 'u': 
            case 'x': 
            case 'X':

                _i_format_int(&state, &spec);
                break;

            case 's':
                
                _i_format_str(&state, &spec);
                break;

            case 'c': {
                
                char c = (char)va_arg(state.arg, int);
                char pad_char = (spec.flgs & flgs_ZERO_PAD) ? '0' : ' ';
                
                int pad_count = (spec.width > 1) ? spec.width - 1 : 0;
                
                if (!(spec.flgs & flgs_LEFT_JUSTIFY))
                    while (pad_count-- > 0) _write_char(&state, pad_char);

                _write_char(&state, c);

                if (spec.flgs & flgs_LEFT_JUSTIFY)
                    while (pad_count-- > 0) _write_char(&state, pad_char);

                break;

            }

            case '%':

                _write_char(&state, '%');
                
                break;

            default:

                _write_char(&state, '%');
                _write_char(&state, spec.specifier);
                break;
        }
    }

    va_end(state.arg);

    return (int)state.written;

}

EXPORT(vsprfmt);

static void _write_char(vsprf_t *state, char c) {
    
    if (state->buf && state->written < state->sz - 1)
        state->buf[state->written] = c;
    
    state->written++;
    
    if (state->sz > 0) {

        size_t null_pos = (state->written < state->sz) ? state->written : state->sz - 1;
        
        if (state->buf && null_pos < state->sz)
            state->buf[null_pos] = '\0';
    }
}

static size_t _utoa_base(uintmax_t val, int base, char *buf, size_t buf_len, int uppercase) {

    char tmp_buf[32];

    if (buf_len == 0)
        return 0;
    
    int i = 0;
    
    if (val == 0) {

        if (buf_len >= 1) 
            buf[0] = '0';

        if (buf_len >= 2) 
            buf[1] = '\0';

        return 1;
    
    }

    while (val > 0 && i < sizeof(tmp_buf) - 1) {
    
        uintmax_t remainder = val % base;
        
        char digit;
        
        if (remainder < 10)
            digit = '0' + (char)remainder;
        else
            digit = (uppercase ? 'A' : 'a') + (char)(remainder - 10);
        
        tmp_buf[i++] = digit;

        val /= base;
    
    }

    size_t len = 0;
    
    for (int j = i - 1; j >= 0 && len < buf_len - 1; j--)
        buf[len++] = tmp_buf[j];
    
    if (buf_len > 0)
        buf[len] = '\0';
        
    return len;
}

static void _write_string_padded(vsprf_t *state, const char *str, size_t len, const fmtt_spec_t *spec, char sign_prefix) {
    
    int total_chars = len + (sign_prefix ? 1 : 0);
    
    char pad_char = ((spec->flgs & flgs_ZERO_PAD) && !(spec->flgs & flgs_LEFT_JUSTIFY)) ? '0' : ' ';
    
    int padding = (spec->width > total_chars) ? (spec->width - total_chars) : 0;

    if (!(spec->flgs & flgs_LEFT_JUSTIFY) && pad_char == ' ')
        while (padding-- > 0) _write_char(state, ' ');

    if (sign_prefix)
        _write_char(state, sign_prefix);
    
    if (!(spec->flgs & flgs_LEFT_JUSTIFY) && pad_char == '0')
        while (padding-- > 0) _write_char(state, '0');

    if (len > 0)
        for (size_t i = 0; i < len; i++)
            _write_char(state, str[i]);

    if (spec->flgs & flgs_LEFT_JUSTIFY)
        while (padding-- > 0) _write_char(state, ' ');

}

static const char* _parse_spec(const char *fmt, fmt_spec_t *spec, vsprf_t *state) {
    const char *p = fmt;

    for (;;) {

        switch (*p) {

            case '-': 
                
                spec->flgs |= flgs_LEFT_JUSTIFY; 
                
                p++; 
                
                break;

            case '+': 


                spec->flgs |= flgs_SIGN_ALWAYS; 
                
                p++; 

                break;

            case ' ': 

                spec->flgs |= flgs_SIGN_SPACE; 

                p++; 

                break;

            case '0': 
                
                spec->flgs |= flgs_ZERO_PAD;

                p++; 

                break;
            case '#': 
                
                spec->flgs |= flgs_ALTERNATE;

                p++; 

                break;

            default: goto end_flags;

        }

    }

end_flags:;
    
    if (spec->flgs & flgs_LEFT_JUSTIFY)
        spec->flgs &= ~flgs_ZERO_PAD;

    if (*p == '*') {

        spec->width = va_arg(state->arg, int);
        p++;

    } else 
        while (*p >= '0' && *p <= '9')
            spec->width = spec->width * 10 + (*p++ - '0');

    if (spec->width < 0) {

        spec->flgs |= flgs_LEFT_JUSTIFY;
        
        spec->width = -spec->width;

    }

    spec->precision = -1;

    if (*p == '.') {
    
        p++;
        
        spec->precision = 0;

        if (*p == '*') {
            
            spec->precision = va_arg(state->arg, int);
        
            p++;

        } else 
            while (*p >= '0' && *p <= '9')
                spec->precision = spec->precision * 10 + (*p++ - '0');

        if (spec->precision >= 0)
            spec->flgs &= ~flgs_ZERO_PAD;

    }

    if (*p == 'l') {
        
        p++;
        
        spec->length = (*p == 'l') ? len_LL : len_L;
        
        if (spec->length == len_LL)
            p++;

    }

    spec->specifier = *p;

    if (*p)
        p++;
    
    if (spec->flgs & flgs_SIGN_ALWAYS)
        spec->flgs &= ~flgs_SIGN_SPACE;

    return p;
}

static size_t _i_format_str(vsprf_t *state, const fmt_spec_t *spec) {

    const char *s = va_arg(state->arg, const char *);

    if (s == NULL)
        s = "(null)";
    
    size_t len = strlen(s);
    
    if (spec->precision >= 0 && (size_t)spec->precision < len)
        len = (size_t)spec->precision;

    _write_string_padded(state, s, len, spec, 0);

    return len;
}


static size_t _i_format_int(vsprf_t *state, const fmt_spec_t *spec) {

    char num_buf[32];
    
    uintmax_t unsigned_val;
    
    char sign_prefix = 0;
    
    int base = 10;
    int uppercase;
    
    size_t actual_len;
    
    int precision_pad;
    
    size_t total_content_len;

    int prefix_len = 0;
    int field_len;
    int padding;
    
    char pad_char;
    
    if (spec->specifier == 'd' || spec->specifier == 'i') {
    
        intmax_t signed_val;

        if (spec->length == len_LL)
            signed_val = va_arg(state->arg, long long);
        else if (spec->length == len_L)
            signed_val = va_arg(state->arg, long);
        else
            signed_val = va_arg(state->arg, int);
        
        if (signed_val < 0) {

            sign_prefix = '-';
            
            unsigned_val = (uintmax_t)(-signed_val);

        } else {
            
            unsigned_val = (uintmax_t)signed_val;
            if (spec->flgs & flgs_SIGN_ALWAYS)
                sign_prefix = '+';
            else if (spec->flgs & flgs_SIGN_SPACE)
                sign_prefix = ' ';
        }

    } else {

        if (spec->length == len_LL)
            unsigned_val = va_arg(state->arg, unsigned long long);
        else if (spec->length == len_L)
            unsigned_val = va_arg(state->arg, unsigned long);
        else
            unsigned_val = va_arg(state->arg, unsigned int);

        if (spec->specifier == 'x' || spec->specifier == 'X') {

            base = 16;

            if (spec->specifier == 'X')
                spec->flgs |= flgs_UPPERCASE;

        }

    }

    uppercase = (spec->flgs & flgs_UPPERCASE);

    actual_len = _utoa_base(unsigned_val, base, num_buf, sizeof(num_buf), uppercase);
    
    if (unsigned_val == 0 && spec->precision == 0) {

        actual_len = 0;
        num_buf[0] = 0;
    }
    
    precision_pad = (spec->precision > (int)actual_len) ? (spec->precision - (int)actual_len) : 0;

        total_content_len = actual_len + precision_pad;
    
    if (spec->flgs & flgs_ALTERNATE) {

        if (base == 16 && unsigned_val != 0)
            prefix_len = 2
        else if (base == 8 && unsigned_val != 0)
            prefix_len = 1;

    }

    field_len = (int)total_content_len + (sign_prefix ? 1 : 0) + prefix_len;

    padding = (spec->width > field_len) ? (spec->width - field_len) : 0;
    
    pad_char = (spec->flgs & flgs_ZERO_PAD) ? '0' : ' ';
    
    if (!(spec->flgs & flgs_LEFT_JUSTIFY) && pad_char == ' ')
        while (padding-- > 0) 
            _write_char(state, ' ');
    
    if (sign_prefix)
        _write_char(state, sign_prefix);

    if (prefix_len > 0) {
        if (base == 16 && unsigned_val != 0) {

             _write_char(state, '0');
             _write_char(state, (spec->flgs & flgs_UPPERCASE) ? 'X' : 'x');
        
        } else if (base == 8 && unsigned_val != 0)
            _write_char(state, '0');

    }

    if (!(spec->flgs & flgs_LEFT_JUSTIFY) && pad_char == '0')
        while (padding-- > 0) _write_char(state, '0');

    while (precision_pad-- > 0)
        _write_char(state, '0');

    if (actual_len > 0)
        for (size_t i = 0; i < actual_len; i++)
            _write_char(state, num_buf[i]);

    if (spec->flgs & flgs_LEFT_JUSTIFY)
        while (padding-- > 0) _write_char(state, ' ');

    return total_content_len;

}
