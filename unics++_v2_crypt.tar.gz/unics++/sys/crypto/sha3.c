#include <crypto/sha3.h>

#include <lib/bit/ops.h>

static const uint64_t keccak_round_const[24] = {
    0x0000000000000001ULL, 0x0000000000008082ULL, 0x800000000000808aULL,
    0x8000000080008000ULL, 0x000000000000808bULL, 0x0000000080000001ULL,
    0x8000000080008081ULL, 0x8000000000008009ULL, 0x000000000000008aULL,
    0x0000000000000088ULL, 0x0000000080008009ULL, 0x000000008000000aULL,
    0x000000008000808bULL, 0x800000000000008bULL, 0x8000000000008089ULL,
    0x8000000000008003ULL, 0x8000000000008002ULL, 0x8000000000000080ULL,
    0x000000000000800aULL, 0x800000008000000aULL, 0x8000000080008081ULL,
    0x8000000000008080ULL, 0x0000000080000001ULL, 0x8000000080008008ULL
};

static void sha3_keccak_f(uint64_t state[SHA3_STATE_WIDTH][SHA3_STATE_WIDTH]) {

    uint64_t temp_C[5];
    uint64_t temp_D[5];
    uint64_t temp_E[5][5];

    for (int round = 0; round < 24; round++) {
    
        for (int x = 0; x < 5; x++) {

            temp_C[x] = state[x][0] ^ state[x][1] ^ state[x][2] ^ state[x][3] ^ state[x][4];
        }

        for (int x = 0; x < 5; x++) {
        
            temp_D[x] = temp_C[(x + 4) % 5] ^ ROTATE_LEFT(temp_C[(x + 1) % 5], 1);
            
            for (int y = 0; y < 5; y++)
                state[x][y] ^= temp_D[x];

        }

        int x = 1, y = 0;
        
        uint64_t current = state[x][y];
        
        for (int i = 0; i < 24; i++) {

            int new_x = y;
            int new_y = (2 * x + 3 * y) % 5;
            
            uint64_t rotated = ROTATE_LEFT(current, (i + 1) * (i + 2) / 2);
            
            current = state[new_x][new_y];
            
            state[new_x][new_y] = rotated;
            
            x = new_x;
            y = new_y;

        }

        for (int y = 0; y < 5; y++) {

            for (int x = 0; x < 5; x++)
                temp_E[x][y] = state[x][y] ^ ((~state[(x + 1) % 5][y]) & state[(x + 2) % 5][y]);

        }

        for (int x = 0; x < 5; x++) {

            for (int y = 0; y < 5; y++)
                state[x][y] = temp_E[x][y];

        }

        state[0][0] ^= keccak_round_const[round];

    }

}

static void sha3_absorb(sha3_ctx_t *ctx, const uint8_t *in_block) {

    uint64_t *state_ptr = (uint64_t *)ctx->state;
    const uint64_t *in_ptr = (const uint64_t *)in_block;

    for (size_t i = 0; i < SHA3_256_RATE_BYTES / sizeof(uint64_t); ++i)
        state_ptr[i] ^= in_ptr[i];

    sha3_keccak_f(ctx->state);

}

void sha3_init(sha3_ctx_t *ctx) {
    
    memset(ctx->state, 0, SHA3_STATE_SIZE_BYTES);
    memset(ctx->buf, 0, SHA3_256_RATE_BYTES);
    
    ctx->bufed_bytes = 0;
}

void sha3_update(sha3_ctx_t *ctx, const void *data, size_t len) {
    const uint8_t *in = (const uint8_t *)data;

    while (len > 0) {

        size_t block_space = SHA3_256_RATE_BYTES - ctx->bufed_bytes;
        size_t copy_size = (len < block_space) ? len : block_space;

        memcpy(ctx->buf + ctx->bufed_bytes, in, copy_size);
        
        ctx->bufed_bytes += copy_size;
        
        in += copy_size;
        len -= copy_size;

        if (ctx->bufed_bytes == SHA3_256_RATE_BYTES) {
            
            sha3_absorb(ctx, ctx->buf);
            ctx->bufed_bytes = 0;
        }
    }
}

void sha3_final(sha3_ctx_t *ctx, uint8_t *digest) {

    ctx->buf[ctx->bufed_bytes++] = 0x06;

    memset(ctx->buf + ctx->bufed_bytes, 0, SHA3_256_RATE_BYTES - ctx->bufed_bytes);
    
    ctx->buf[SHA3_256_RATE_BYTES - 1] |= 0x80;

    sha3_absorb(ctx, ctx->buf);

    uint64_t *state_ptr = (uint64_t *)ctx->state;
    uint64_t *digest_ptr = (uint64_t *)digest;

    for (size_t i = 0; i < SHA3_256_OUTPUT_BYTES / sizeof(uint64_t); i++)
        digest_ptr[i] = state_ptr[i];

}

