#ifndef RS_H 
#define RS_H

#include "../bit/int.h"

typedef int8_t rs_mut_i8;
typedef uint8_t rs_mut_u8;
typedef int16_t rs_mut_i16;
typedef uint16_t rs_mut_u16;

#endif
