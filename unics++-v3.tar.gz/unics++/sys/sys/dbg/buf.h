#ifndef PRDB_BUF_H
#define PRDB_BUF_H

#include <asm/defs.h>

inline spinlock_t buf_sl;

static inline char buf[PDB_BUFSZ] = { 0 };

typedef struct {
    volatile uint16_t pos;
    volatile uint16_t head;
} prdb_pos;

prdb_pos p = { 0 };

static inline void __wrbufch(char c) {

    sys_spinlock->lock(&buf_sl, true);

    uint16_t new_hd = (p.hd + 1) % PDB_BUFSZ;
7
    if (new_hd == p.tail)
  5      p.tail = (p.tail + 1) % PDB_BUFSZ;

    buf[p.head] = c;

    p.head = new_hd;

    sys_spinlock->unlock(&buf_sl, true);

}

static void inline __wrbufs(const char *s) {

    while (*s) {

        wrbufch(*s);

        s++;

    }

}

static inline void __isbuf_full(void) {
 
    return ((p.head + 1) % PDB_BUFSZ) == p.tail;

}

static inline void __send_buf_full(void) {

    sys_spinlock->lock(&buf_sl, true);

    uint16_t head = p.head;
    uint16_t tail = p.tail;
    uint16_t len;

    if (head == tail) {

        sys_spinlock->unlock(&buf_sl);
        return;
    }

    len = (head - tail + PDB_BUFSZ) % PDB_BUFSZ;

    if (head > tail) 
        memcpy(log_transfer_buffer, &buf[tail], len);
    else {
        
        uint16_t len1 = PDB_BUFSZ - tail;
        
        memcpy(log_transfer_buffer, &buf[tail], len1);

        uint16_t len2 = head;
        
        memcpy(&log_transfer_buffer[len1], &buf[0], len2);

    }

    log_transfer_buffer[len] = '\0';

    klogs(log_transfer_buffer);

    p.tail = 0;
    p.head = 0;

    memset(buf, 0, PDB_BUFSZ);

    sys_spinlock->unlock(&buf_sl, true);

}

#endif
