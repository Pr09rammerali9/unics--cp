#ifndef RNG_H
#define RNG_H

#include "bit/int.h"
#include "def.h"
#include "mem.h"

#if __STDC_VERSION__ < 202311L

#include "bool.h"

#endif

typedef struct rng_core_t {
    uint32_t (*next_u32)(struct rng_core_t *rng);
    
    uint64_t (*next_u64)(struct rng_core_t *rng);

    void (*fill_bytes)(struct rng_core_t *rng, uint8_t *dest, size_t len);
} rng_core_t;

typedef struct {
    void *state;
    void (*gen)(void *state, void *ress);
} blk_rng_cor_t;

typedef struct {
    blk_rng_cor_t *cor;

    uint32_t ress[32];

    size_t i;
} blk_rng_t;

typedef struct {
    blk_rng_cor_t *cor;

    uint64_t ress[16];

    size_t i;

    bool half_used;
} blk_rng_64_t;

void srand(unsigned seed);

unsigned long long llrand(void);
#define lrand() (unsigned long)llrand()
#define rand() (unsigned int)llrand()

/*impl.c*/
uint64_t next_u64_via_u32(rng_core_t *rng);

void fill_bytes_via_next(rng_core_t *rng, uint8_t *dest, size_t len);
void u32_to_le_bytes(uint32_t val, uint8_t *bytes);
void u64_to_le_bytes(uint64_t val, uint8_t *bytes);

size_t fill_via_next_u32_chnks(const uint32_t *src, size_t src_len, uint8_t *dest, size_t dst_len, size_t *filled_dst_bytes);
size_t fill_via_next_u64_chnks(const uint64_t *src, size_t src_len, uint8_t *dest, size_t dst_len, size_t *filled_dst_bytes);

uint32_t next_u32_via_fill(rng_core_t *rng);

uint64_t next_u64_via_fill(rng_core_t *rng);

/*blk.c*/
void blk_rng_init(blk_rng_t *rng, blk_rng_cor_t *cor);

uint32_t blk_rng_nxt_u32(blk_rng_t *rng);

uint64_t blk_rng_nxt_u64(blk_rng_t *rng);

void blk_rng_fill_bytes(blk_rng_t *rng, uint8_t *dest, size_t len);
void blk_rng_64_init(blk_rng_64_t *rng, blk_rng_cor_t *cor);

uint32_t blk_rng_64_nxt_u32(blk_rng_64_t *rng);

uint64_t blk_rng_64_nxt_u64(blk_rng_64_t *rng);

void blk_rng_64_fill_bytes(blk_rng_64_t *rng, uint8_t *dest, size_t len);
/*le.c*/
void rd_u32_into(const uint8_t *src, size_t src_len, uint32_t *dest, size_t dst_len);
void rd_u64_into(const uint8_t *src, size_t src_len, uint64_t *dst, size_t dst_len);

void mt_srand(unsigned seed);
unsigned long long  mt_llrand(void);
#define mt_lrand() (unsigned long)mt_llrand()
#define mt_rand() (unsigned int)mt_rand()

#endif 
