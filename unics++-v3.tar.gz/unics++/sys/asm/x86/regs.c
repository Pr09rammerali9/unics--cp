#include <asm/x86/regs.h>
#include <lib/def.h>

#define __GENERATE_SETREG_BLOCK(_reg_str, _reg_asm, _suffix, _clobber) \
    if (strcmp(r, _reg_str) == 0) {                                      \
        __asm__ __volatile__ (                                           \
            "mov" _suffix " %0, %%"_reg_asm                             \
            :                                                            \
            : "r" (val)                                                  \
            : _clobber                                                   \
        );                                                               \
        return;                                                          \
    }

#define sr8gen(r, er) __GENERATE_SETREG_BLOCK(__STRINGIFY(r), __STRINGIFY
