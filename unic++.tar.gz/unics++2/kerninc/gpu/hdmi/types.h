#ifndef TYPES_H
#define TYPES_H

#if __STDC_VERSION < 202311L 

#include "../../lib/bool.h"

#endif

#include "../../lib/bit/int.h"
#include "../../lib/def.h"

typedef enum {
    NUL = 0x00,
    AUD_CLK_REG = 0x01,
    AUD_SAMP = 0x02,
    GEN_CTL = 0x03,
    ACP = 0x04,
    ISRC1 = 0x05,
    ISRC2 = 0x06,
    ONE_BIT_AUD_SAMP = 0x07,
    DST_AUD = 0x08,
    HBR_AUD_STR = 0x09,
    GAMUT_METADAT = 0x0a,
} hdmi_packet_type_t;

typedef enum {
    INF_TYP_VEND = 0x81,
    INF_TYP_AVI = 0x82,
    INF_TYP_SPD = 0x83,
    INF_TYP_AUD = 0x84,
    INF_TYP_DRM = 0x87,
} hdmi_infoframe_type_t;

typedef struct {
    hdmi_infoframe_type_t typ;

    uint8_t ver, len;
} hdmi_any_infoframe_t;

typedef enum {
    CLR_SPC_RGB,
    CLR_SPC_YUV422,
    CLR_SPC_YUV444,
    CLR_SPC_YUV420,
    CLR_SPC_RES4,
    CLR_SPC_RES5,
    CLR_SPC_RES6,
    CLR_SPC_IDO_DEF,
} hdmi_colorspace_t;

typedef enum {
    SCN_MOD_NON,
    SCN_MOD_OVR,
    SCN_MOD_UND,
    SCN_MOD_RES,
} hdmi_scan_mod_t;

typedef enum {
    CLR_MTRY_NON,
    CLR_MTRY_ITU601,
    CLR_MTRY_ITU709,
    CLR_MTRY_EXT,
} hdmi_colorimetry_t;

typedef enum {
    PIC_ASP_NON,
    PIC_ASP_4_3,
    PIC_ASP_16_9,
    PIC_ASP_64_27,
    PIC_ASP_256_135,
    PIC_ASP_RES,
} hdmi_picture_aspect_t;

typedef enum {
    ACT_ASP_16_9_TOP = 2,
    ACT_ASP_14_9_TOP = 3,
    ACT_ASP_16_9_CEN = 4,
    ACT_ASP_PIC = 8,
    ACT_ASP_4_3 = 9,
    ACT_ASP_16_9 = 10,
    ACT_ASP_14_9 = 11,
    ACT_ASP_4_3_SP_14_9 = 13,
    ACT_ASP_16_9_SP_14_9 = 14,
    ACT_ASP_16_9_SP_4_3 = 15,
} hdmi_active_aspect_t;

typedef enum {
    EXT_CLR_MTRY_XV_YCC_601,
    EXT_CLR_MTRY_XV_YCC_709,
    EXT_CLR_MTRY_S_YCC_601,
    EXT_CLR_MTRY_OPYCC_601,
    EXT_CLR_MTRY_OPRGB,
    EXT_CLR_MTRY_BT2020_CST_LUM,
    EXT_CLR_MTRY_BT2020,
    EXT_CLR_MTRY_RES,
} hdmi_extended_colorimetry_t;

typedef enum {
    QU_RNG_DEF,
    QU_RNG_LIM,
    QU_RNG_FUL,
    QU_RNG_RES,
} hdmi_quantization_range_t;

typedef enum {
    NUPS_UNK,
    NUPS_HOR,
    NUPS_VER,
    NUPS_BOT,
} hdmi_nups_t;

typedef enum {
    YCC_QU_RNG_LIM,
    YCC_QU_RNG_FUL,
} hdmi_ycc_quantization_range_t;

typedef enum {
    CON_TYP_GRA,
    CON_TYP_PHO,
    CON_TYP_CIN,
    CON_TYP_GAM,
} hdmi_content_type_t;

typedef struct hdmi_avi_infoframe {
    hdmi_infoframe_type_t typ;

    uint8_t ver, len;

    bool itc;

    uint8_t pix_rp;

    hdmi_colorspace_t clr_spc;
    hdmi_scan_mod_t scn_mod;
    hdmi_colorimetry_t clr_mty;
    hdmi_picture_aspect_t pic_asp;
    hdmi_active_aspect_t act_asp;
    hdmi_extended_colorimetry_t ext_clr_mty;
    hdmi_quantization_range_t qu_rng;
    hdmi_nups_t nups;

    uint8_t vid_cod;

    hdmi_ycc_quantization_range_t ycc_qu_rng;
    hdmi_content_type_t con_typ;

    uint16_t top_bar, bot_bar, lef_bar, rig_bar;
} hdmi_avi_infoframe_t;

typedef enum {
    METADAT_TYP_STA_METADAT_TYP1 = 0,
} hdmi_metadata_type_t;

typedef enum {
    EOTF_TRA_GAM_SDR,
    EOTF_TRA_GAM_HDR,
    EOTF_SMPTE_ST2084,
    EOTF_BT_2100_HLG,
} hdmi_eotf_t;

typedef struct {
    uint16_t x, y;
} hdmi_point_t;

typedef struct hdmi_drm_infoframe {
    hdmi_infoframe_type_t typ;

    uint8_t ver, len;

    hdmi_eotf_t eotf;
    hdmi_metadata_type_t metadat_typ;

    hdmi_point_t disp_pri[3];
    hdmi_point_t wh_pnt;

    uint16_t max_disp_mas_lum, min_disp_mas_lum, max_cll, max_fall;
} hdmi_drm_infoframe_t;

typedef enum {
    SPD_SDI_UNK,
    SPD_SDI_DSTB,
    SPD_SDI_DVDP,
    SPD_SDI_DVHS,
    SPD_SDI_HDDVR,
    SPD_SDI_DVC,
    SPD_SDI_DSC,
    SPD_SDI_VCD,
    SPD_SDI_GAM,
    SPD_SDI_PC,
    SPD_SDI_BD,
    SPD_SDI_SACD,
    SPD_SDI_HDDVD,
    SPD_SDI_PMP,
} hdmi_spd_sdi_t;

typedef struct hdmi_spd_infoframe {
    hdmi_infoframe_type_t typ;

    uint8_t ver, len;

    char vend[8], prod[16];

    hdmi_spd_sdi_t sdi;
} hdmi_spd_infoframe_t;

typedef enum {
    AUD_COD_TYP_STR,
    AUD_COD_TYP_PCM,
    AUD_COD_TYP_AC3,
    AUD_COD_TYP_MPEG1,
    AUD_COD_TYP_MP3,
    AUD_COD_TYP_MPEG2,
    AUD_COD_TYP_AAC_LC,
    AUD_COD_TYP_DTS,
    AUD_COD_TYP_ATRAC,
    AUD_COD_TYP_DSD,
    AUD_COD_TYP_EAC3,
    AUD_COD_TYP_DTS_HD,
    AUD_COD_TYP_MLP,
    AUD_COD_TYP_DST,
    AUD_COD_TYP_WMA_PRO,
    AUD_COD_TYP_CXT,
} hdmi_audio_coding_type_t;

typedef enum {
    AUD_SAMP_SIZ_STR,
    AUD_SAMP_SIZ_16,
    AUD_SAMP_SIZ_20,
    AUD_SAMP_SIZ_24,
} hdmi_audio_sample_size_t;

typedef enum {
    AUD_SAMP_FRE_STR,
    AUD_SAMP_FRE_32000,
    AUD_SAMP_FRE_44100,
    AUD_SAMP_FRE_48000,
    AUD_SAMP_FRE_88200,
    AUD_SAMP_FRE_96000,
    AUD_SAMP_FRE_176400,
    AUD_SAMP_FRE_192000,
} hdmi_audio_sample_frequency_t;

typedef enum {
    AUD_COD_TYP_EXT_CT,
    AUD_COD_TYP_EXT_HE_AAC,
    AUD_COD_TYP_EXT_HE_AAC_V2,
    AUD_COD_TYP_EXT_MPEG_SURROUND,
    AUD_COD_TYP_EXT_MPEG4_HE_AAC,
    AUD_COD_TYP_EXT_MPEG4_HE_AAC_V2,
    AUD_COD_TYP_EXT_MPEG4_AAC_LC,
    AUD_COD_TYP_EXT_DRA,
    AUD_COD_TYP_EXT_MPEG4_HE_AAC_SUR,
    AUD_COD_TYP_EXT_MPEG4_AAC_LC_SUR = 10,
} hdmi_audio_coding_type_ext_t;

typedef struct hdmi_audio_infoframe {
    hdmi_infoframe_type_t typ;

    uint8_t ver, len, chnls;

    hdmi_audio_coding_type_t cod_typ;
    hdmi_audio_sample_size_t samp_siz;
    hdmi_audio_sample_frequency_t samp_fre;
    hdmi_audio_coding_type_ext_t cod_typ_ext;

    uint8_t chnl_alloc, lvl_shf_val;

    bool downmix_inh;
} hdmi_audio_infoframe_t;

typedef enum {
    STRUC_INV = -1,
    STRUC_FRM_PAC = 0,
    STRUC_FLD_ALT,
    STRUC_LIN_ALT,
    STRUC_SID_BY_SID_FUL,
    STRUC_L_DEP,
    STRUC_L_DEP_GFX_GFX_DEP,
    STRUC_TOP_AND_BOT,
    STRUC_SID_BY_SID_HAF = 8,
} hdmi_3d_structure_t;

typedef struct hdmi_vendor_infoframe {
    hdmi_infoframe_type_t typ;

    uint8_t ver, len, vic;

    uint32_t oui, s3d_ext_dat;

    hdmi_3d_structure_t s3d_struc;
} hdmi_vendor_infoframe_t;

typedef struct hdr_static_metadata {
    uint8_t eotf, metadat_typ;

    uint16_t max_cll, max_fall, min_cll;
} hdr_static_metadata_t;

typedef struct hdr_sink_metadata {
    uint32_t metadat_typ;

    union {
        hdr_static_metadata_t hdmi_type1;
    };
} hdr_sink_metadata_t;

typedef union {
    struct {
        hdmi_infoframe_type_t typ;
    
        uint8_t ver, len;
        uint32_t oui;
    } any;

    hdmi_vendor_infoframe_t hdmi;
} hdmi_vendor_any_infoframe_t;

typedef union {
    hdmi_any_infoframe_t any;
    hdmi_avi_infoframe_t avi;
    hdmi_spd_infoframe_t spd;
    hdmi_vendor_any_infoframe_t vend;
    hdmi_audio_infoframe_t aud;
    hdmi_drm_infoframe_t drm;
} hdmi_infoframe_t;

#endif
