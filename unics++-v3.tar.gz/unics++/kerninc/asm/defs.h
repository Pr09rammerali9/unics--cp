#ifndef ASMDEFS_H
#define ASMDEFS_H

#if defined(__i386__) || defined(__i685__)

#define KSTK_SZ 12288
#define POOL_SIZE 4096
#define TLSFPOOL_SZ 8192
#define COROSTK_SZ 2048
#define COROMAX 32

#elif defined(__amd64__) || defined(__x86_64__) || defined(__ia64__)

/* This Is For Similarity,
 * Since x64 & IA64 Are 64 Bit, 
 * They Will Have Identical Sizes, 
 * Ofc for Unics++,
 * I Enjoy Shortcuts
 */

#define KSTK_SZ 16384
#define POOL_SIZE 4096
#define TLSFPOOL_SZ 10240
#define COROSTK_SZ 4096
#define COROMAX 48
#define ALIGNMENT __attribute__((aligned(16))

#elifdef __pdp11__

#define KSTK_SZ 4608
#define POOL_SIZE 2048
#define TLSFPOOL_SZ 5120
#define COROSTK_SZ 2048
#define COROMAX 12
#define ALIGMENT __attribute__((aligned(16))) 

#endif

#endif
