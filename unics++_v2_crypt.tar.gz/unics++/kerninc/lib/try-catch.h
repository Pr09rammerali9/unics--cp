#ifndef TRY_CATCH_H
#define TRY_CATCH_H

#define try \
    do {

#define throw_if(condition) \
    if (!(condition)) goto cleanup;

#define catch(action) \
    } while (0); \
    goto end; \
    cleanup: \
        action; \
    end: \
        ;

#endif 
