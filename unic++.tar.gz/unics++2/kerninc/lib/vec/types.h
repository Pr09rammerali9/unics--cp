#ifndef LIB_VEC_TYPES_H
#define LIB_VEC_TYPES_H

#include "../bit/int.h"
#include "../bit/ptr.h"
#define __vec(n) __attribute__((vector_size(n)))
#define vec_ty(ty, n, td) typedef ty __vec(n) td;
#define vec_var(ty, n, name) ty name __vec(n)

typedef uint8_t __attribute__((vector_size(2))) uint8x2_t;
typedef uint16_t __attribute__((vector_size(4))) uint16x2_t;
typedef uint32_t __attribute__((vector_size(8))) uint32x2_t;
typedef uint64_t __attribute__((vector_size(16))) uint64x2_t;
typedef unsigned __int128 __attribute__((vector_size(32))) uint128x2_t;
typedef uintptr_t __attribute__((vector_size(16))) uintptrx2_t;
typedef intptr_t __attribute__((vector_size(16))) intptrx2_t;
typedef int8_t __attribute__((vector_size(2))) int8x2_t;
typedef int16_t __attribute__((vector_size(4))) int16x2_t;
typedef int32_t __attribute__((vector_size(8))) int32x2_t;
typedef int64_t __attribute__((vector_size(16))) int64x2_t;

typedef uint8_t __attribute__((vector_size(3))) uint8x3_t;
typedef uint16_t __attribute__((vector_size(6))) uint16x3_t;
typedef uint32_t __attribute__((vector_size(12))) uint32x3_t;
typedef uint64_t __attribute__((vector_size(24))) uint64x3_t;
typedef unsigned __int128 __attribute__((vector_size(48))) uint128x3_t;
typedef uintptr_t __attribute__((vector_size(24))) uintptrx3_t;
typedef intptr_t __attribute__((vector_size(24))) intptrx3_t;
typedef int8_t __attribute__((vector_size(3))) int8x3_t;
typedef int16_t __attribute__((vector_size(6))) int16x3_t;
typedef int32_t __attribute__((vector_size(12))) int32x3_t;
typedef int64_t __attribute__((vector_size(24))) int64x3_t;

typedef uint8_t __attribute__((vector_size(4))) uint8x4_t;
typedef uint16_t __attribute__((vector_size(8))) uint16x4_t;
typedef uint32_t __attribute__((vector_size(16))) uint32x4_t;
typedef uint64_t __attribute__((vector_size(32))) uint64x4_t;
typedef unsigned __int128 __attribute__((vector_size(64))) uint128x4_t;
typedef uintptr_t __attribute__((vector_size(32))) uintptrx4_t;
typedef intptr_t __attribute__((vector_size(32))) intptrx4_t;
typedef int8_t __attribute__((vector_size(4))) int8x4_t;
typedef int16_t __attribute__((vector_size(8))) int16x4_t;
typedef int32_t __attribute__((vector_size(16))) int32x4_t;
typedef int64_t __attribute__((vector_size(32))) int64x4_t;

typedef uint8_t __attribute__((vector_size(5))) uint8x5_t;
typedef uint16_t __attribute__((vector_size(10))) uint16x5_t;
typedef uint32_t __attribute__((vector_size(20))) uint32x5_t;
typedef uint64_t __attribute__((vector_size(40))) uint64x5_t;
typedef unsigned __int128 __attribute__((vector_size(80))) uint128x5_t;
typedef uintptr_t __attribute__((vector_size(40))) uintptrx5_t;
typedef intptr_t __attribute__((vector_size(40))) intptrx5_t;
typedef int8_t __attribute__((vector_size(5))) int8x5_t;
typedef int16_t __attribute__((vector_size(10))) int16x5_t;
typedef int32_t __attribute__((vector_size(20))) int32x5_t;
typedef int64_t __attribute__((vector_size(40))) int64x5_t;

typedef uint8_t __attribute__((vector_size(6))) uint8x6_t;
typedef uint16_t __attribute__((vector_size(12))) uint16x6_t;
typedef uint32_t __attribute__((vector_size(24))) uint32x6_t;
typedef uint64_t __attribute__((vector_size(48))) uint64x6_t;
typedef unsigned __int128 __attribute__((vector_size(96))) uint128x6_t;
typedef uintptr_t __attribute__((vector_size(48))) uintptrx6_t;
typedef intptr_t __attribute__((vector_size(48))) intptrx6_t;
typedef int8_t __attribute__((vector_size(6))) int8x6_t;
typedef int16_t __attribute__((vector_size(12))) int16x6_t;
typedef int32_t __attribute__((vector_size(24))) int32x6_t;
typedef int64_t __attribute__((vector_size(48))) int64x6_t;

typedef uint8_t __attribute__((vector_size(7))) uint8x7_t;
typedef uint16_t __attribute__((vector_size(14))) uint16x7_t;
typedef uint32_t __attribute__((vector_size(28))) uint32x7_t;
typedef uint64_t __attribute__((vector_size(56))) uint64x7_t;
typedef unsigned __int128 __attribute__((vector_size(112))) uint128x7_t;
typedef uintptr_t __attribute__((vector_size(56))) uintptrx7_t;
typedef intptr_t __attribute__((vector_size(56))) intptrx7_t;
typedef int8_t __attribute__((vector_size(7))) int8x7_t;
typedef int16_t __attribute__((vector_size(14))) int16x7_t;
typedef int32_t __attribute__((vector_size(28))) int32x7_t;
typedef int64_t __attribute__((vector_size(56))) int64x7_t;

typedef uint8_t __attribute__((vector_size(8))) uint8x8_t;
typedef uint16_t __attribute__((vector_size(16))) uint16x8_t;
typedef uint32_t __attribute__((vector_size(32))) uint32x8_t;
typedef uint64_t __attribute__((vector_size(64))) uint64x8_t;
typedef unsigned __int128 __attribute__((vector_size(128))) uint128x8_t;
typedef uintptr_t __attribute__((vector_size(64))) uintptrx8_t;
typedef intptr_t __attribute__((vector_size(64))) intptrx8_t;
typedef int8_t __attribute__((vector_size(8))) int8x8_t;
typedef int16_t __attribute__((vector_size(16))) int16x8_t;
typedef int32_t __attribute__((vector_size(32))) int32x8_t;
typedef int64_t __attribute__((vector_size(64))) int64x8_t;

typedef uint8_t __attribute__((vector_size(9))) uint8x9_t;
typedef uint16_t __attribute__((vector_size(18))) uint16x9_t;
typedef uint32_t __attribute__((vector_size(36))) uint32x9_t;
typedef uint64_t __attribute__((vector_size(72))) uint64x9_t;
typedef unsigned __int128 __attribute__((vector_size(144))) uint128x9_t;
typedef uintptr_t __attribute__((vector_size(72))) uintptrx9_t;
typedef intptr_t __attribute__((vector_size(72))) intptrx9_t;
typedef int8_t __attribute__((vector_size(9))) int8x9_t;
typedef int16_t __attribute__((vector_size(18))) int16x9_t;
typedef int32_t __attribute__((vector_size(36))) int32x9_t;
typedef int64_t __attribute__((vector_size(72))) int64x9_t;

typedef uint8_t __attribute__((vector_size(10))) uint8x10_t;
typedef uint16_t __attribute__((vector_size(20))) uint16x10_t;
typedef uint32_t __attribute__((vector_size(40))) uint32x10_t;
typedef uint64_t __attribute__((vector_size(80))) uint64x10_t;
typedef unsigned __int128 __attribute__((vector_size(160))) uint128x10_t;
typedef uintptr_t __attribute__((vector_size(80))) uintptrx10_t;
typedef intptr_t __attribute__((vector_size(80))) intptrx10_t;
typedef int8_t __attribute__((vector_size(10))) int8x10_t;
typedef int16_t __attribute__((vector_size(20))) int16x10_t;
typedef int32_t __attribute__((vector_size(40))) int32x10_t;
typedef int64_t __attribute__((vector_size(80))) int64x10_t;

typedef uint8_t __attribute__((vector_size(11))) uint8x11_t;
typedef uint16_t __attribute__((vector_size(22))) uint16x11_t;
typedef uint32_t __attribute__((vector_size(44))) uint32x11_t;
typedef uint64_t __attribute__((vector_size(88))) uint64x11_t;
typedef unsigned __int128 __attribute__((vector_size(176))) uint128x11_t;
typedef uintptr_t __attribute__((vector_size(88))) uintptrx11_t;
typedef intptr_t __attribute__((vector_size(88))) intptrx11_t;
typedef int8_t __attribute__((vector_size(11))) int8x11_t;
typedef int16_t __attribute__((vector_size(22))) int16x11_t;
typedef int32_t __attribute__((vector_size(44))) int32x11_t;
typedef int64_t __attribute__((vector_size(88))) int64x11_t;

typedef uint8_t __attribute__((vector_size(12))) uint8x12_t;
typedef uint16_t __attribute__((vector_size(24))) uint16x12_t;
typedef uint32_t __attribute__((vector_size(48))) uint32x12_t;
typedef uint64_t __attribute__((vector_size(96))) uint64x12_t;
typedef unsigned __int128 __attribute__((vector_size(192))) uint128x12_t;
typedef uintptr_t __attribute__((vector_size(96))) uintptrx12_t;
typedef intptr_t __attribute__((vector_size(96))) intptrx12_t;
typedef int8_t __attribute__((vector_size(12))) int8x12_t;
typedef int16_t __attribute__((vector_size(24))) int16x12_t;
typedef int32_t __attribute__((vector_size(48))) int32x12_t;
typedef int64_t __attribute__((vector_size(96))) int64x12_t;

typedef uint8_t __attribute__((vector_size(13))) uint8x13_t;
typedef uint16_t __attribute__((vector_size(26))) uint16x13_t;
typedef uint32_t __attribute__((vector_size(52))) uint32x13_t;
typedef uint64_t __attribute__((vector_size(104))) uint64x13_t;
typedef unsigned __int128 __attribute__((vector_size(208))) uint128x13_t;
typedef uintptr_t __attribute__((vector_size(104))) uintptrx13_t;
typedef intptr_t __attribute__((vector_size(104))) intptrx13_t;
typedef int8_t __attribute__((vector_size(13))) int8x13_t;
typedef int16_t __attribute__((vector_size(26))) int16x13_t;
typedef int32_t __attribute__((vector_size(52))) int32x13_t;
typedef int64_t __attribute__((vector_size(104))) int64x13_t;

typedef uint8_t __attribute__((vector_size(14))) uint8x14_t;
typedef uint16_t __attribute__((vector_size(28))) uint16x14_t;
typedef uint32_t __attribute__((vector_size(56))) uint32x14_t;
typedef uint64_t __attribute__((vector_size(112))) uint64x14_t;
typedef unsigned __int128 __attribute__((vector_size(224))) uint128x14_t;
typedef uintptr_t __attribute__((vector_size(112))) uintptrx14_t;
typedef intptr_t __attribute__((vector_size(112))) intptrx14_t;
typedef int8_t __attribute__((vector_size(14))) int8x14_t;
typedef int16_t __attribute__((vector_size(28))) int16x14_t;
typedef int32_t __attribute__((vector_size(56))) int32x14_t;
typedef int64_t __attribute__((vector_size(112))) int64x14_t;

typedef uint8_t __attribute__((vector_size(15))) uint8x15_t;
typedef uint16_t __attribute__((vector_size(30))) uint16x15_t;
typedef uint32_t __attribute__((vector_size(60))) uint32x15_t;
typedef uint64_t __attribute__((vector_size(120))) uint64x15_t;
typedef unsigned __int128 __attribute__((vector_size(240))) uint128x15_t;
typedef uintptr_t __attribute__((vector_size(120))) uintptrx15_t;
typedef intptr_t __attribute__((vector_size(120))) intptrx15_t;
typedef int8_t __attribute__((vector_size(15))) int8x15_t;
typedef int16_t __attribute__((vector_size(30))) int16x15_t;
typedef int32_t __attribute__((vector_size(60))) int32x15_t;
typedef int64_t __attribute__((vector_size(120))) int64x15_t;

typedef uint8_t __attribute__((vector_size(16))) uint8x16_t;
typedef uint16_t __attribute__((vector_size(32))) uint16x16_t;
typedef uint32_t __attribute__((vector_size(64))) uint32x16_t;
typedef uint64_t __attribute__((vector_size(128))) uint64x16_t;
typedef unsigned __int128 __attribute__((vector_size(256))) uint128x16_t;
typedef uintptr_t __attribute__((vector_size(128))) uintptrx16_t;
typedef intptr_t __attribute__((vector_size(128))) intptrx16_t;
typedef int8_t __attribute__((vector_size(16))) int8x16_t;
typedef int16_t __attribute__((vector_size(32))) int16x16_t;
typedef int32_t __attribute__((vector_size(64))) int32x16_t;
typedef int64_t __attribute__((vector_size(128))) int64x16_t;

typedef uint8_t __attribute__((vector_size(17))) uint8x17_t;
typedef uint16_t __attribute__((vector_size(34))) uint16x17_t;
typedef uint32_t __attribute__((vector_size(68))) uint32x17_t;
typedef uint64_t __attribute__((vector_size(136))) uint64x17_t;
typedef unsigned __int128 __attribute__((vector_size(272))) uint128x17_t;
typedef uintptr_t __attribute__((vector_size(136))) uintptrx17_t;
typedef intptr_t __attribute__((vector_size(136))) intptrx17_t;
typedef int8_t __attribute__((vector_size(17))) int8x17_t;
typedef int16_t __attribute__((vector_size(34))) int16x17_t;
typedef int32_t __attribute__((vector_size(68))) int32x17_t;
typedef int64_t __attribute__((vector_size(136))) int64x17_t;

typedef uint8_t __attribute__((vector_size(18))) uint8x18_t;
typedef uint16_t __attribute__((vector_size(36))) uint16x18_t;
typedef uint32_t __attribute__((vector_size(72))) uint32x18_t;
typedef uint64_t __attribute__((vector_size(144))) uint64x18_t;
typedef unsigned __int128 __attribute__((vector_size(288))) uint128x18_t;
typedef uintptr_t __attribute__((vector_size(144))) uintptrx18_t;
typedef intptr_t __attribute__((vector_size(144))) intptrx18_t;
typedef int8_t __attribute__((vector_size(18))) int8x18_t;
typedef int16_t __attribute__((vector_size(36))) int16x18_t;
typedef int32_t __attribute__((vector_size(72))) int32x18_t;
typedef int64_t __attribute__((vector_size(144))) int64x18_t;

typedef uint8_t __attribute__((vector_size(19))) uint8x19_t;
typedef uint16_t __attribute__((vector_size(38))) uint16x19_t;
typedef uint32_t __attribute__((vector_size(76))) uint32x19_t;
typedef uint64_t __attribute__((vector_size(152))) uint64x19_t;
typedef unsigned __int128 __attribute__((vector_size(304))) uint128x19_t;
typedef uintptr_t __attribute__((vector_size(152))) uintptrx19_t;
typedef intptr_t __attribute__((vector_size(152))) intptrx19_t;
typedef int8_t __attribute__((vector_size(19))) int8x19_t;
typedef int16_t __attribute__((vector_size(38))) int16x19_t;
typedef int32_t __attribute__((vector_size(76))) int32x19_t;
typedef int64_t __attribute__((vector_size(152))) int64x19_t;

typedef uint8_t __attribute__((vector_size(20))) uint8x20_t;
typedef uint16_t __attribute__((vector_size(40))) uint16x20_t;
typedef uint32_t __attribute__((vector_size(80))) uint32x20_t;
typedef uint64_t __attribute__((vector_size(160))) uint64x20_t;
typedef unsigned __int128 __attribute__((vector_size(320))) uint128x20_t;
typedef uintptr_t __attribute__((vector_size(160))) uintptrx20_t;
typedef intptr_t __attribute__((vector_size(160))) intptrx20_t;
typedef int8_t __attribute__((vector_size(20))) int8x20_t;
typedef int16_t __attribute__((vector_size(40))) int16x20_t;
typedef int32_t __attribute__((vector_size(80))) int32x20_t;
typedef int64_t __attribute__((vector_size(160))) int64x20_t;

#endif
