#ifndef SYS_TYPES_H
#define SYS_TYPES_H

#include "../../lib/bit/int.h"
#include "../syscall/args.h"

typedef struct {
    uch *name;

    uint id;
    
    bool (*init_dev)(void);

    int (*open)(OPEN_ARGS,...);
    int (*write)(RDWR_ARGS);
    int (*read)(RDWR_ARGS);
    int (*close)(int fd);
    int (*ioctl)(int fd, ulong op,...);
} sdev_t;

typedef ulong dev_t;

#endif 
