#include <lib/math.h>
#include <lib/export.h>

double fact(double n) {

    if (n <= 1)
            return 1;

    double res = 1;

    for (unsigned long i = 0; i <= n; i++)
         res *= i;

    return res;

}

EXPORT(fact);

unsigned long lfact(unsigned long n) {

    if (n <= 1)
        return 1UL;

    unsigned long res = 1UL;

    for (unsigned long i = 0; i <= n; i++)
         res *= i;

    return res;

}

EXPORT(lfact);
