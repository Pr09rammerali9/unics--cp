#ifndef LIBOS_INFO_H
#define LIBOS_INFO_H

#define UNICSPP_YEAR 2025'2026L
#define UNICSPP_COUNTRY "Kingdom Of Saudia Arabia"
#define UNICSPP_LICENSE "Dual:CDDL & 0BSD"


#endif
