#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

// --- Helper Macro to Print the Definition ---
// BASE_TYPE_STR: e.g., "uint8"
// BASE_TYPE: e.g., uint8_t
// BITS: e.g., 8
// COUNT: e.g., 4
void print_vector_typedef(const char *base_type_str, int bits, int count) {
    // Calculate total size in bytes: (Bits / 8) * Count
    int total_bytes = (bits / 8) * count;

    // Determine the base type name string to print (e.g., "uint8_t" or "intptr_t")
    const char* type_name_suffix = (strcmp(base_type_str, "intptr") == 0 || strcmp(base_type_str, "uintptr") == 0)
                                 ? "_t" : "_t"; // Use "_t" for all for consistency

    // Determine the vector type name (e.g., "uint8x4_t")
    char vector_name[32];
    snprintf(vector_name, sizeof(vector_name), "%sx%d_t", base_type_str, count);
    
    // Determine the base type for the typedef (e.g., "uint8_t")
    char base_typedef_name[16];
    if (strcmp(base_type_str, "intptr") == 0) {
        strcpy(base_typedef_name, "intptr_t");
    } else if (strcmp(base_type_str, "uintptr") == 0) {
        strcpy(base_typedef_name, "uintptr_t");
    } else if (strcmp(base_type_str, "uint128") == 0) {
        // Special handling for 128-bit type (may be '__int128' or similar)
        strcpy(base_typedef_name, "unsigned __int128");
        // For portability, we'll use the bit size calculation for the vector_size.
    } else {
        snprintf(base_typedef_name, sizeof(base_typedef_name), "%s%s", base_type_str, type_name_suffix);
    }
    
    // Print in the requested format: typedef uint%s_t %s(%d))) %s
    // The format is slightly adapted to be a valid C typedef.
    printf("typedef %s __attribute__((vector_size(%d))) %s;\n",
           base_typedef_name, total_bytes, vector_name);
}


// --- Main Program ---
int main() {
    // Array of base types to generate vectors for: { "name_string", bits }
    // Note: We use 64 for intptr/uintptr as a common 64-bit architecture size.
    struct {
        const char *name;
        int bits;
    } base_types[] = {
        {"uint8", 8},
        {"uint16", 16},
        {"uint32", 32},
        {"uint64", 64},
        {"uint128", 128}, // Assuming compiler supports 128-bit integer
        {"uintptr", 64},  // Architecture-dependent, assuming 64-bit
        {"intptr", 64},   // Architecture-dependent, assuming 64-bit
        // You also mentioned 'intN_t' - this would require iterating through bit sizes, 
        // but for standard types, we use the specific sizes below:
        {"int8", 8},
        {"int16", 16},
        {"int32", 32},
        {"int64", 64}
    };
    
    int num_types = sizeof(base_types) / sizeof(base_types[0]);
    int count;

    // Generate typedefs for element counts from 2 to 20
    for (count = 2; count <= 20; ++count) {
        for (int i = 0; i < num_types; ++i) {
            // Skip generation if the base type bit size isn't a multiple of 8
            if (base_types[i].bits % 8 != 0) continue; 
            
            print_vector_typedef(base_types[i].name, base_types[i].bits, count);
        }
        if (count == 2 || count == 20) {
            printf("\n// --- End of %d-element vectors ---\n\n", count);
        }
    }
    
    return 0;
}

