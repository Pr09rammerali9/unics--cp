#ifndef MATH_H
#define MATH_H

#define fabsf(x)  __builtin_fabsf(x)
#define fabs(x)   __builtin_fabs(x)
#define fabsl(x)  __builtin_fabsl(x)
#define powl(x, y)  __builtin_powl(x, y)
#define sinf(x)     __builtin_sinf(x)
#define INF __builtin_inf()
#define INFF __builtin_inff()
#define INFL __builtin_infl()
#define NAN_F __builtin_nanf("0")
#define NAN_D __builtin_nan("0")
#define NAN_L __builtin_nanl("0")
#define derivative(f, n, h) (((f((n) + (h)) - f((n) - (h))) / (2 * (h))))
#define slope(x, h, f) ((f((x) + (h)) - f((x))) / (h))
#define avg_slope(x2, x1, y2, y1) (((y2) - (y1)) / ((x2) - (x1)))
#define lim(x, a, f) ((f((x) + (a)) + f((x) - (a))) / 2)

static inline unsigned long lfact(unsigned long n) {
    
    unsigned long result = 1;
    
    for (unsigned long i = 2; i <= n; i++)
        result *= i;

    return result;

}

static inline double fact(double n) {
    
    if (n < 0.0 || n != (long)n)
        return NAN_D; 

    return (double)lfact((unsigned long)n);

}

static inline unsigned int upow(unsigned int x, unsigned int y) {

    unsigned int n = 1;

    for (unsigned int i = 0; i < y; i++)
        n *= x;

    return n;

}

static inline int ipow(int x, int y) {

    int n = 0;

    for (int i = 0; i < y; i++)
        n *= x;

    return n;

}

static inline short spow(short x, short y) {

    short n = 0;

    for (short i = 0; i < y; i++)
        n *= x;

    return n;

}

static inline unsigned short uspow(unsigned short x, unsigned short y) {

    unsigned short n = 0;

    for (unsigned short i = 0; i < y; i++)
        n *= x;

    return x;

}

#endif
