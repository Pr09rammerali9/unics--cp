#ifndef TYPES_H 
#define TYPES_H

//idk what to do so made this
typedef unsigned int uint;
typedef char ch;
typedef unsigned char uch;
typedef short sh;
typedef unsigned short ush;
typedef long lng;
typedef unsigned long ulng;
typedef float flt;
typedef double dbl;
typedef int *iptr;
typedef uint *uiptr;
typedef ch *chptr;
typedef uch *uchptr;
typedef sh *shptr;
typedef ush *ushptr;
typedef flt *fltptr;
typedef dbl *dblptr;
typedef unsigned long long ull;
typedef long long ll;
typedef ll *llptr;
typedef ull *ullptr;
typedef int fd_t;
typedef ush ushort;
typedef uch uchar; 

#include "any.h"

typedef unsigned int pid_t;
typedef long off_t;
typedef long time_t;
typedef uint uid_t;
typedef uint gid_t;
typedef uint tid_t;
typedef _Atomic volatile int atomic_t;
typedef ulng reg_t;
typedef ulng paddr_t;
typedef ulng vaddr_t;
typedef unsigned long size_t;
typedef signed long ssize_t;
typedef signed long ptrdiff_t;
typedef unsigned int wchar_t;
typedef unsigned long ulong;    
typedef volatile uint volatile_t;
typedef void *timer_t;
typedef char *str;

#endif
