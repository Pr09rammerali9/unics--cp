#ifndef ASM_IP_H
#define ASM_IP_H

#if defined(__x86_64__) || defined(__amd64__)
    #define set_ip(regs, val) ((regs)->rip = (val))

#elif defined(__i386__)
    #define set_ip(regs, val) ((regs)->eip = (val))

#elif defined(__aarch64__) || defined(__arm__) || defined(__pdp11__) || defined(__65C816__)
    #define set_ip(regs, val) ((regs)->pc = (val))

#elif defined(__mips__)
    #define set_ip(regs, val) ((regs)->cp0_epc = (val))

#elif defined(__riscv)
    #define set_ip(regs, val) ((regs)->sepc = (val))

#endif

#endif
