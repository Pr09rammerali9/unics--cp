#ifndef MM_H
#define MM_H

#include "../../lib/bit/int.h"
#include "../../lib/def.h"

typedef struct {
    bool present;
    bool rw;
    bool usr_suprvisior;
    bool wr_through;
    bool cache_disabled;
    bool acced;
    bool dirty;
    bool pg_sz;
    bool globl;
 
    _BitInt(3) avail;
    
    uint20_t pg_tbl_addr;
} pg_dir_t;

typedef struct {
    bool present;
    bool rw;
    bool usr_suprvisior;
    bool wr_through;
    bool cache_disabled;
    bool acced;
    bool dirty;
    bool pg_sz;
    bool globl;

    _BitInt(3) avail;

    uint20_t pg_frme_addr;
} pg_tbl_t;

#define PTE_PRES 1
#define PTE_RW 2
#define PTE_USR 4
#define PTE_ACCED 0x20
#define PTE_DIRTY 0x40
#define PTE_GLOBL 0x100
#define PDE_PGSZ 0x80
#define PTE_PAT 0x80
#define PTE_NX 0x8000000000000000 

void *pgalloc(void);
void pgfree(void *addr);
void *vm_alloc(void);
void vm_free(void);
void kmmap(void *vaddr, void *paddr, int flgs);
void pgmap(void *addr, int flags);
void pmm_st(uint32_t kern_end_addr);

bool is_paddr(void *addr);
bool is_vaddr(void *addr);
bool is_pg(void *addr);

#endif
