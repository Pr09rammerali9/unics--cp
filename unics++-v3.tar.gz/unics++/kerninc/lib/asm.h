#ifndef LIBASM_H
#define LIBASM_H

#define asm_blk(blk,...) __asm__ volatile(blk __VA_ARG__)
#define mkglobl(sym) asm_blk(".globl" #sym) 
#define asm_typ_fn(l) asm_blk(".type" #l ", @function")

#endif 
