#include <lib/rc4.h>
#include <lib/export.h>

void rc4_init(rc4_ctx *ctx, const uint8_t *key, size_t len) {

    uint8_t j = 0;

    for (int i = 0; i < 256; i++)
        ctx->S[i] = i;

    for (int i = 0; i < 256; i++) {
        
        j = j + ctx->S[i] + key[i % len];
        
        uint8_t t = ctx->S[i];
        
        ctx->S[i] = ctx->S[j];
        ctx->S[j] = t;

    }

    ctx->i = 0;
    ctx->j = 0;

}

EXPORT(rc4_init);

static void rc4_keystream_gen(rc4_ctx *ctx, uint8_t *out, size_t len) {
    
    uint8_t t, k;

    size_t i;

    for (i = 0; i < len; i++) {
        
        ctx->i++;
        ctx->j = ctx->j + ctx->S[ctx->i];

        t = ctx->S[ctx->i];
        ctx->S[ctx->i] = ctx->S[ctx->j];
        ctx->S[ctx->j] = t;

        k = ctx->S[ctx->i] + ctx->S[ctx->j];
        out[i] = ctx->S[k];

    }

}

void rc4_encrypt(rc4_ctx *ctx, const uint8_t *in, uint8_t *out, size_t len) {

    uint8_t keystream_byte;
    
    size_t i;

    for (i = 0; i < len; i++) {
        
        ctx->i++;
        ctx->j = ctx->j + ctx->S[ctx->i];

        uint8_t t = ctx->S[ctx->i];

        ctx->S[ctx->i] = ctx->S[ctx->j];
        ctx->S[ctx->j] = t;

        uint8_t k = ctx->S[ctx->i] + ctx->S[ctx->j];
        keystream_byte = ctx->S[k];

        out[i] = in[i] ^ keystream_byte;

    }
    
}

EXPORT(rc4_encrypt);

void rc4_crypt(rc4_ctx *ctx, uint8_t *data, size_t len) {
    
    rc4_encrypt(ctx, data, data, len);

}

EXPORT(rc4_crypt);

void rc4_rand(rc4_ctx *ctx, uint8_t *out, size_t len) {

    rc4_keystream_gen(ctx, out, len);

}

EXPORT(rc4_rand);
