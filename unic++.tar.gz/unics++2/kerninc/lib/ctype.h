#ifndef CTYPE
#define CTYPE

/*we want to minimize the size of file, so we will write this for short:
* 1 : true
* 0 : false*/

#define to_lower(chr) ((chr >= 'A' && chr <= 'Z') ? (chr + 32) : (chr))
#define to_upper(chr) ((chr >= 'a' && chr <= 'z') ? (chr - 32) : (chr))
#define is_alpha(c) ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ? 1 : 0)
#define is_digit(c) ((c >= '0' && c <= '9') ? 1 : 0)
#define is_hex(c) (((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f')) ? 1 : 0)
#define is_ascii(c) ((c >= 0 && c <= 127) ? 1 : 0)
#define is_oct(c) ((c >= '0' && c <= '7') ? 1 : 0)
#define to_num(c) ((c >= '0' && c <= '9') ? (c - '0') : (c))
#define to_hex(c)((c >= '0' && c <= '9') ? (c - '0') : ((c >= 'A' && c <= 'F') ? (c - 'A' + 10) : ((c >= 'a' && c <= 'f') ? (c - 'a' + 10) : 0 )))
#define is_space(c) ((c == '\n' || c == '\t' || c == ' ' || c == '\v' || c == '\r' || c == '\f') ? 1 : 0)

#endif
