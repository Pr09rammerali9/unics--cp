#include <asm/x86/atom.h>
#include <lib/atomic.h>

static atom_var(bool, lk_var) = false; 


void atom_lock(void) {

    bool lk_val_2_swp = true;

    __asm__ volatile(
            "cli\n"
            "1: xchgb %b0, %1\n"
            "testb %b0, %b0\n"
            "jnz 1b\n"
            : "+q"(lk_val_2_swp),
              "=m"(lk_var)
            : "m"(lk_var)
            : "memory"
            );

}


void atom_unlock(void) {
    
    lk_var = false;
 
    __asm__ volatile("sti" ::: "memory");

}
