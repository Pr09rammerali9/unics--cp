#ifndef ASMCPU_H
#define ASMCPU_H

#include "../lib/ven.h"

typedef struct {
    ven_t ven;
    uint16_t feat;
    uint8_t feat_2;
} cpu_info_t;  

#endif
