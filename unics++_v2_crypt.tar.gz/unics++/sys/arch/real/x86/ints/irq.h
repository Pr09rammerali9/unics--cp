#ifndef IRQ_H
#define IRQ_H

#include <lib/bit/int.h>
#include <lib/def.h>

typedef struct {
    uint32_t ds,
             es,
             fs,
             gs;
    uint32_t edi,
             esi,
             ebp,
             esp_dummy,
             ebx,
             edx,
             ecx,
             eax;
    uint32_t int_n,
             err_n;
    uint32_t eip,
             eflags,
             useresp,
             cs,
             ss;
} regs_t;

void irq_install(uint8_t irq, void (*handler)(regs_t *));
void irq_uninstall(uint8_t irq);

#endif
