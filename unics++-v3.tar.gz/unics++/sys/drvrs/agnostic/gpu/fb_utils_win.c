#include <asm/defs.h>
#include <gpu/fb_utils.h>
#include <lib/mem.h>

void win_init(win_t *win, const char *name, size_t height, size_t width) {

    win->height = height;
    win->width = width;
    win->name = (char *)name;

    fb_init(&win->fb, width, height);

}

void win_mv(win_t *w, size_t nx, size_t ny) {

    w->fb.sz_x = nx;
    w->fb.sz_y = ny;

}

void win_redrw(win_t *win, fb_t *tar) {

    if (!w || !tar)
        return;

    size_t row_bytes = w->width * 3;

    for (size_t i = 0; i < w->height; i++) {

        if ((w->fb.sz_y + i) >= tar->y)
            break;

        uint24_t *dst = tar->fb[w->fb.sz_y + i] + w->fb.sz_x;
        uint24_t *src = w-fb.fb[i];

        memcpy(dst, src, row_bytes);

    }

}
