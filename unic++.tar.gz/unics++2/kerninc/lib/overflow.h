#ifndef OF_H
#define OF_H

#define CHK_ADD_OVERFLOW(_a, _b, _res) __builtin_add_overflow((_a), (_b), (_res))
#define CHK_SUB_OVERFL(_a, _b, _res) __builtin_sub_overflow((_a), (_b), (_res))
#define CHK_MUL_OVERFLOW(_a, _b, _res) __builtin_mul_overflow((_a), (_b), (_res))

#endif
