#include <asm/x86/port.h>

void outb(uint16_t port, uint8_t val) {
    
    __asm__ volatile("outb %0, %1" : : "a"(val), "Nd"(port));

}

void outw(uint16_t port, uint16_t val) {
    
    __asm__ volatile("outw %0, %1" : : "a"(val), "Nd"(port));

}

void outl(uint16_t port, uint32_t val) {

    __asm__ volatile("outl %0, %1" : : "a"(val), "Nd"(port));

}

uint8_t inb(INARG) {
    uint8_t ret = 0;

    __asm__ volatile("inb %1, %0" : "=a"(ret) : "Nd"(port));
    
    return ret;

}

uint16_t inw(INARG) {
    uint16_t ret = 0;
    
    __asm__ volatile("inw %1, %0" : "=a"(ret) : "Nd"(port));

    return ret;

}

uint32_t inl(INARG) {
    uint32_t ret = 0;
    
    __asm__ volatile("inl %1, %0" : "=a"(ret) : "Nd"(port));
 
    return ret;

}
