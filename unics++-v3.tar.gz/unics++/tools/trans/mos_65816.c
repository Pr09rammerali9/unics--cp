/*couldnt have time*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINE_LENGTH 256
#define MAX_TOKENS 4

typedef struct {
    char mnemonic[10];
    char operand1[50];
    char operand2[50];
    
    int token_count;   
} Instruction;

char* trim_whitespace(char *str) {
    char *end;
    
    while(isspace((unsigned char)*str)) str++;
    if(*str == 0) return str;

    end = str + strlen(str) - 1;
    
    while(end > str && isspace((unsigned char)*end)) end--;

    *(end + 1) = 0;

    return str;

}

void tokenize(char *line, Instruction *inst) {
    
    char *token;
    char temp_line[MAX_LINE_LENGTH];
    
    strncpy(temp_line, line, MAX_LINE_LENGTH);
    temp_line[MAX_LINE_LENGTH - 1] = '\0';

    inst->token_count = 0;
    
    token = strtok(temp_line, " \t");
    
    if (token) {
    
        strncpy(inst->mnemonic, trim_whitespace(token), 9);
        inst->mnemonic[9] = '\0';
        inst->token_count++;

    } else
        return;

    token = strtok(NULL, "\n");

    if (token) {
        char *operands_raw = trim_whitespace(token);
        char *op1 = strtok(operands_raw, ",");

        if (op1) {

            strncpy(inst->operand1, trim_whitespace(op1), 49);
            
            inst->operand1[49] = '\0';
            inst->token_count++;

            char *op2 = strtok(NULL, ",");
            
            if (op2) {
            
                strncpy(inst->operand2, trim_whitespace(op2), 49);
                
                inst->operand2[49] = '\0';
                inst->token_count++;

            } else
                inst->operand2[0] = '\0';

        } else {
            
            inst->operand1[0] = '\0';
            inst->operand2[0] = '\0';
    
        }
    
    }

}

void translate_line(const Instruction *inst, char *output) {
    
    char standard_mnemonic[10] = "";
    char final_operand[50] = "";

    if (strcmp(inst->mnemonic, "ld") == 0) {
        
        if (strcmp(inst->operand2, "%a") == 0) {

            strcpy(standard_mnemonic, "LDA");
            
            if (inst->operand1[0] == '$') {

                char *value = inst->operand1 + 1;
                long int parsed_value;
                
                int base = 10;
                
                if (strncmp(value, "0x", 2) == 0 || strncmp(value, "0X", 2) == 0) {
                
                    base = 16; 
                    value += 2;

                }
                
                parsed_value = strtol(value, NULL, base);
                
                snprintf(final_operand, 50, "#$%04lX", parsed_value & 0xFFFF);

            } else
                 snprintf(final_operand, 50, "$%s", inst->operand1);
            
        } else {
    
            snprintf(output, MAX_LINE_LENGTH, "; ERROR: Unhandled ld instruction: %s", inst->operand2);
    
            return;
        }
        
    } else if (strcmp(inst->mnemonic, "cp") == 0) {
        
        if (strcmp(inst->operand1, "%x") == 0) {

            strcpy(standard_mnemonic, "CPX");
            
            if (inst->operand2[0] == '$') {

                char *value = inst->operand2 + 1;
                long int parsed_value;
                
                int base = 10;
                
                if (strncmp(value, "0x", 2) == 0 || strncmp(value, "0X", 2) == 0) {
            
                    base = 16;
                    value += 2;

                }
                
                parsed_value = strtol(value, NULL, base);
                
                snprintf(final_operand, 50, "#$%04lX", parsed_value & 0xFFFF);

            } else 
                 snprintf(final_operand, 50, "$%s", inst->operand2);
             else {
            
            snprintf(output, MAX_LINE_LENGTH, "; ERROR: Unhandled cp instruction: %s", inst->operand1);

            return;

        }

    } else if (strcmp(inst->mnemonic, "jne") == 0) {
        
        strcpy(standard_mnemonic, "BNE");
        
        char temp_target[50];
        strncpy(temp_target, inst->operand1, 49);
        temp_target[49] = '\0';

        char *start = temp_target;
        char *end = temp_target + strlen(temp_target) - 1;

        if (*start == '(')
            start++;
        if (*end == ')') 
            *end = '\0';

        if (strncmp(start, "0x", 2) == 0 || strncmp(start, "0X", 2) == 0) 
            start += 2;

        snprintf(final_operand, 50, "$%s", start);

    } else {
    
        snprintf(output, MAX_LINE_LENGTH, "; ERROR: Unhandled Mnemonic: %s", inst->mnemonic);
        return;

    }

    if (final_operand[0] != '\0')
        snprintf(output, MAX_LINE_LENGTH, "%-5s %s", standard_mnemonic, final_operand);
    else
        snprintf(output, MAX_LINE_LENGTH, "%s", standard_mnemonic);

    char original_line[MAX_LINE_LENGTH];

    strncpy(original_line, inst->mnemonic, MAX_LINE_LENGTH - 1);

        if (inst->token_count > 1) {

        strncat(original_line, " ", MAX_LINE_LENGTH - strlen(original_line) - 1);
        strncat(original_line, inst->operand1, MAX_LINE_LENGTH - strlen(original_line) - 1);
        if (inst->token_count > 2)

            strncat(original_line, ", ", MAX_LINE_LENGTH - strlen(original_line) - 1);
            strncat(original_line, inst->operand2, MAX_LINE_LENGTH - strlen(original_line) - 1);

    }
    
    int len = strlen(output);

    if (len < 30) {
    
        while (len < 30)
            output[len++] = ' ';

        output[len] = '\0';

    } else
        strncat(output, " ", MAX_LINE_LENGTH - strlen(output) - 1);

    snprintf(output + strlen(output), MAX_LINE_LENGTH - strlen(output), "; Original: %s", original_line);

}

