#ifndef LIB_TERMIOS_H
#define LIB_TERMIOS_H

#include "bit/int.h"

typedef uint32_t tcflag_t;
typedef tcflag_t tcflg_t;
typedef uint8_t cc_t;
typedef unsigned int speed_t;

typedef struct {
    tcflg_t c_iflag,
            c_oflag,
            c_cflag,
            c_lfag;

    cc_t c_cc[32];

    speed_t c_ispeed,
            c_ospeed;
} termios_t;

#define VINTR 0
#define VQUIT 1
#define VKILL 3
#define VEOF 4
#define VTIME 5
#define VMIN 6
#define VSWTC 7
#define VSTART 8
#define VSTOP 9
#define VSUSP 10
#define VEOL 11
#define VREPRINT 12
#define VDISCARD 13
#define VWERASE 14
#define VLNEXT 15
#define VEOL2 16

#endif 
