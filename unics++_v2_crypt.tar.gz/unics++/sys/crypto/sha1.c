#include <crypto/sha1.h>
#include <lib/bit/ops.h>
#include <lib/end/utils.h>

typedef union {
    uchar c[64];
    
    ulong l[16];
} ch64_lng16;

#define rol(value, bits) (((value) << (bits)) | ((value) >> (32 - (bits))))
#define blk0(i) (blck->l[i] = __htobe32(blck->l[i])) 
#define blk(i) (blck->l[i & 15] = rol(blck->l[(i + 13) & 15] ^blck->l[(i + 8) & 15] \
    ^ blck->l[(i+2)&15] ^ blck->l[i&15],1))

#define R0(v, w, x, y, z, i) z += ( (w & (x ^ y)) ^ y ) + blk0(i) + 0x5A827999 + rol(v, 5); w = rol(w, 30);
#define R1(v, w, x, y, z, i) z += ( (w & (x ^ y)) ^ y ) + blk(i) + 0x5A827999 + rol(v, 5); w = rol(w, 30);
#define R2(v, w, x, y, z, i) z += ( w ^ x ^ y ) + blk(i) + 0x6ED9EBA1 + rol(v, 5); w = rol(w, 30);
#define R3(v, w, x, y, z, i) z += ( ( (w | x) & y ) | (w & x) ) + blk(i) + 0x8F1BBCDC + rol(v, 5); w = rol(w, 30);
#define R4(v, w, x, y, z, i) z += ( w ^ x ^ y ) + blk(i) + 0xCA62C1D6 + rol(v, 5); w = rol(w, 30);

#define ROT_CALL(R_func, i) \
    do { \
        int h0_idx = (5 - ((i) % 5)) % 5;\
        \
        R_func(a[h0_idx], \
               a[(h0_idx + 1) % 5], \
               a[(h0_idx + 2) % 5], \
               a[(h0_idx + 3) % 5], \
               a[(h0_idx + 4) % 5], \
               (i)); \
    } while(0)

void sha1_trans(uint32_t stat[5], const uchar buf[64]) {

    /*shortcut, a[0] = a, a[1] = b, a[2] = c, a[3] = d, a[4] = e*/
    uint32_t a[5] = { stat[0], stat[1], stat[2], stat[3], stat[4] }; 

    ch64_lng16 blck[1] = { 0 };

    memcpy(blck, buf, 64);

    uchar i = 0;

    for (; i <= 15; i++)
        ROT_CALL(R0, i);

    for (i++; i <= 19; i++)
        ROT_CALL(R1, i);

    for (i++; i <= 39; i++)
        ROT_CALL(R2, i);

    for (i++; i <= 59; i++)
        ROT_CALL(R3, i);

    for (i++; i <= 79; i++)
        ROT_CALL(R4, i);

    for (i = 0; i < 5; i++)
        stat[i] += a[i];

    memset(a, 0, sizeof(a));
    memset(blck, 0, sizeof(ch64_lng16));

}

void sha1_init(sha1_ctx *contxt) {

    uint32_t arr[5] = { 0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0 };
 
    for (ch i = 0; i < 5; i++)
         contxt->stat[i] = arr[i];

    contxt->stat[0] = contxt->stat[1] = 0;

}

void sha1_upd(sha1_ctx *contxt, const uchar *dat, uint32_t len) {

    uint32_t i = 0,
             j = 0;

    j = context->count[0];

    if ((contxt->count[0] += len << 3) < j
        contxt->count[1]++;

    contxt->count[1] += (len >> 29);

    j = (j >> 3) & 63;

    if ((j + len) > 63) {

        memcpy(&contxt->buf[j], dat, (i = j - 64));

        sha1_trans(contxt->stat, contxt->buf);

        for (; i + 63 < len, i += 64)
            sha1_trans(contxt->stat, &dat[i]);

        j = 0;

    } else 
        i = 0;

    memcpy(&contxt->buf[i], &dat[i], len - i);

}

void sha1_final(uchar digset[20], sha1_ctx *contxt) {

    uchar i = 0;

    uchar final_count[8] = { 0 },
          c = 0;

    uint64_t bit_count =  ((uint64_t)contxt->count[1] << 32) | contxt->count[0],
             be_bit_count = __htobe64(bit_count);

    memcpy(final_count, &be_bit_count, 8);

#if __STDC_VERSION__ >= 202311L

    c = 0o200;

#else

    c = 0200;

#endif

    sha1_upd(contxt, &c, 1);

    while ((contxt->count[0] & 504) != 448) {

        c = 0;

        sha1_upd(contxt, &c, 1);

    }

    sha1_upd(contxt, final_count, 8);

    for (; i < 5; i++) {

        uint32_t be_word = __htobe32(contxt->stat[i]);

        memcpy(&digset[i * 4], &be_word, 4);

    }

    memset(contxt, 0, sizeof(final_count));

}


void sha1_hash(str hash_out, const str s, uint32_t len) {

    sha_ctx ctx;
    
    ctx->stat = { 0 };
    ctx->buf = { 0 }; 
    ctx->count = { 0 };

    uint ii = 0;

    sha1_init(&ctx);

    for (; ii < len; ii++)
        sha1_upd(&ctx, (uchar)s + ii, 1);

    sha1_final((uchar *)hash_out, &ctx);

}
