#ifndef ASM_JMPBUF_H
#define ASM_JMPBUF_H

#include "../lib/def.h"

#if defined(__i386__) || defined(__i686__)

typedef size_t jmpbuf_t[10];

#elif defined(__x86_64__) || defined(__amd64__)

typedef size_t jmpbuf_t[16];

#elif defined(__aarch64__)

typedef size_t jmpbuf_t[20];

#elif defined(__ia64__)

typedef size_t jmpbuf_t[128];

#elif define(__aarch32__) || defined(__arm__)

typedef size_t jmpbuf_t[16];

#elifdef __mips__

typedef size_t jmpbuf_t[32];

#elif defined(__riscv) || defined(__riscv32) || defined(__riscv64)

typedef size_t jmpbuf_t[20];

#elifdef __m68k__

typedef size_t jmpbuf_t[15];

#elif defined(__hppa__) || defined(__parisc__)

typedef size_t jmpbuf_t[30];

#elifdef __sparc__

typedef size_t jmpbuf_t[32];

#elifdef __pdp11__

typedef size_t jmpbuf_t[8];

#elifdef __65C816__

typedef size_t jmpbuf_t[8];

#endif

#endif
