#ifndef TO_H
#define TO_H

#include "ctype.h"
#include "str.h"
#include "def.h"
#include "bool.h"

int atoi(const char *s);

long atol(const char *s);
long long atoll(const char *s);

#endif
