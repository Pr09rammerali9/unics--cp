#ifndef PIC_H
#define PIC_H

#include <lib/bit/int.h>
#include <asm/x86/port.h>

#define PIC1_CMD 0x20
#define PIC1_DAT 0x21
#define PIC2_CMD 0xA0
#define PIC2_DAT 0xA1
#define PIC_EOI 0x20

void pic_remap(int offset1, int offset2);
void pic_eoi(uint8_t irq);
void irq_mask(uint8_t irq);
void irq_unmask(uint8_t irq);

#endif
