#ifndef FOREACH_H
#define FOREACH_H

#include "def.h"

#define ls_foreach(pos, hd, m) \
    for (pos = cnt_of((hd)->next, typeof(*pos), m); \
         pos != (hd); \
         pos = cnt_of(pos->m.next, typeof(*pos), m))
#define in ,
#define foreach(item, arr) \
    for (size_t i = 0; i < sizeof(arr) / sizeof(arr[0]); ++i) { \
    for (item = (arr)[i]; 0; ;)

#endif
