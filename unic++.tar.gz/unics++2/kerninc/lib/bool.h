#ifndef BOOL_H
#define BOOL_H

#if __STDC_VERSION__ > 202311L

typedef enum {
    false = 0,
    true = 1
} _Bool;

typedef _Bool bool;

#endif

#endif
