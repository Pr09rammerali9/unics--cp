#include <lib/atexit.h>
#include <lib/export.h>

#define COUNT 32

static struct fl {
    struct fl *nxt;

    void (*f[COUNT])(void);
} builtin, *hd;

static int slot;

void fns_on_exit(void) {

    for (; hd; hd = hd->nxt) {

         int cur_slot = (hd == &builtin) ? slot : COUNT;

         while (cur_slot-- > 0) {

            hd->f[cur_slot]();

        }

    }

}

int atexit(void (*fn)(void)) {

    if (!hd)
        hd = &builtin;

    if (slot == COUNT) {

        struct fl *new_fl = (struct fl *)palloc(sizeof(struct fl));

        if (!new_fl)
            return -1;

        new_fl->nxt = hd;

        hd = new_fl;

        slot = 0;

    }

    hd->f[slot] = fn;

    slot++;

    return 0;
}

EXPORT(atexit);
