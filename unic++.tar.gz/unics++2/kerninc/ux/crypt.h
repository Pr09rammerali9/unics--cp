#ifndef UX_CRYPT_H
#define UX_CRYPT_H

void setkey(char *key);
void *encrypt(char *block, bool edflag);
char *crypt(char *pw, char *salt);

/*since des_* functions in sysv4 doesnt have much change in logic from unix v7, we will make them macros*/
#define des_crypt(pw, s) crypt(pw, s)
#define des_encrypt(b, e) encrypt(b, e)
#define des_setkey(k) setkey(k)

#endif
