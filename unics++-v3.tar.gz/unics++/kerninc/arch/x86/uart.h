#ifndef ARCHX_UART
#define ARCHX_UART

#include "../../asm/x86/port.h"

#define SERIAL_PORT_BASE 0x3F8

#define SERIAL_DATA_PORT(base)        (base + 0)
#define SERIAL_FIFO_COMMAND_PORT(base) (base + 2)
#define SERIAL_LINE_COMMAND_PORT(base) (base + 3)
#define SERIAL_MODEM_COMMAND_PORT(base) (base + 4)
#define SERIAL_LINE_STATUS_PORT(base) (base + 5)

#define SERIAL_LINE_ENABLE_DLAB 0x80

void arch_uart_init(void);
void arch_uart_wr(char c);
void arch_uart_puts(char s[]);
char arch_uart_rd(void);

#endif
