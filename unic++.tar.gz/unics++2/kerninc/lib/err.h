#ifndef ERR_H
#define ERR_H

#include "bit/int.h"

extern uint8_t errn;

#define EINVADDR 1
#define EINVMEM 2
#define ENOMEM 3
#define EINVFLG 4
#define EFAULT 5 
#define ECRASH 6
#define EOVF 7
#define EINVPG 8
#define ENODEV 9
#define EACC 0xA
#define EINITF 0xB
#define EINARG 0xC
#define ECRASH 0xD
#define ENOARG 0xE
#define ENOTTY 0xF
#define ENFILE 0x10
#define EMFILE 0x11
#define EBUSY 0x12
#define EISDIR 0x13
#define ENOTDIR 0x14
#define ENOTBLK 0x15
#define ENOCH 0x16
#define EBADFD 0x17
#define EXDEV 0x18
#define ENFILE 0x19
#define EFBIG 0x1A
#define EBIG 0x1B // A Big Value Was Passed To The Dumb Function
#define EROFS 0x1C
#define ENOSPC 0x1D
#define EPIPE 0x1E
#define ENM2LNG 0x1F
#define ENOTMT 0x20 //Not Empty Because English Spells Empty:Empty, mpty, mt, (and nothing)

#define is_err(ern) ((ern >= 1 && ern <= 0x20) ? 1 : 0)


char *strerr(void);



#endif
