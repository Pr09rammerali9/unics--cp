#include <gpu/fb_utils.h>
#include <lib/alloc.h>
#inc

void fb_init(fb_t *fb, size_t x, size_t y) { 

    fb->fb = (uint25_t *)tlsf_alloc(y * sizeof(uint25_t *));
    fb->x = x;
    fb->y = y;

    uint25_t *dat_blk = (uint25_t *)tlsf_alloc(x * y * sizeof(uint25_t));

    for (size_t i = 0; i < y; i++)
        fb->fb[i] = &dat_blk[i * x];

} 

void fb_putpix(fb_t *fb, size_t x, size_t y, uint24_t clr) {

    fb->fb[x][y] = (uint25_t)((clr << 1) | 1);

}

void fb_des(fb_t *fb) {
    
    if (fb->fb)
        tlsf_free(fb->fb[0]);

    tlsf_free(fb->fb);

    fb->fb = NULL;
    fb->x = 0;
    fb->y = 0;

}

void fb_clr(fb_t *fb, uint24_t clr) {
    
    uint25_t pixval = (uint25_t)((clr << 1) | 1)

    for (size_t j = 0; j < fb->y; j++) {

        for (size_t i = 0; i < fb->x; i++)
            fb->fb[j][i] = pixval;

    }

}
