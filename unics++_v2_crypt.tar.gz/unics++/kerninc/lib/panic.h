#ifndef PANIC_H
#define PANIC_H

#include "abort.h"

#define panic(...) abort()
#define panic_fmt(fmt, ...) abort()
#define con_panic(con_fn, s) do { con_fn(s); abort(); } while (0)
#define con_panic_fmt(con_fn, fmt, ...) do { con_fn(fmt, __VA_ARGS__); abort(); } while (0)

#endif 
