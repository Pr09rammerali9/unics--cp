#include <arch/x86/mm.h>
#include <lib/mem.h>
#include <lib/bit/int.h>
#include <lib/bit/ops.h>
#include <lib/mod.h>
#include <lib/compiler.h>
#include <lib/export.h>

static volatile uint64_t pg_dir[1024] attr(aligned(4096)) = { 0 }; 
static volatile uint64_t pg_dir_ptr_tab[4] attr(aligned(32)) = { 0 };

static int8_t init_pging(void) {

    volatile uint64_t first_pgtbl[512] attr(aligned(4096)) = { 0 };

    for (uint64_t i = 0; i < 512; i++)
        first_pgtbl[i] = (i * 0x1000) | PTE_PRES | _PAGE_RW; 

    pg_dir[0] = ((uint64_t)first_pgtbl) | PDE_PRES | _PAGE_RW; 
    
    pg_dir_ptr_tab[0] = ((uint64_t)pg_dir) | PDPE_PRES | _PAGE_RW;

    uint32_t cr3_val = (uint32_t)pg_dir_ptr_tab; 

    __asm__ volatile("movl %0, %%cr3"
            :
            : "r"(cr3_val)
        );

    uint32_t cr4_val = 0;
    __asm__ volatile("movl %%cr4, %0" 
            : "=r"(cr4_val)
            );

    cr4_val |= (1 << 5); 
    __asm__ volatile("movl %0, %%cr4" 
            : 
            : "r"(cr4_val)
            );

    uint32_t cr0_val = 0;

    __asm__ volatile("movl %%cr0, %0"
        : "=r"(cr0_val)
        );

    cr0_val |= 0x80000000;

    __asm__ volatile("movl %0, %%cr0"
            :
            : "r"(cr0_val)
            );

    return 0;

}

void st_pgdir(uint64_t val, uint16_t i) {

    pg_dir[i] = val;

}

uint64_t gt_pgdir(uint16_t i) {

    return pg_dir[i];

}

early_mod_init(init_pging);
