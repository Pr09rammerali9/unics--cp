#include <lib/compiler.h>
#include <lib/tty.h>
#include "gdt.h"

#define vt_panic_nohlt(vt, s) vt_putstr(vt, "[PANIC]" s, 0)

static char kstack[(1024 * 12)] attr(aligned(16)) = { 0 };

void _start_kmain() {

    extern char bss_start[], bss_end[];
    extern void kmain(void);

    char *stk_top = kstack + sizeof(kstack) - 4;

    __asm__ volatile("movl %0, %%esp"
            :
            : "r"(stk_top)
    );

    char *bss_ptr = bss_start;

    memset(bss_start, 0, (size_t)(bss_end - bss_start));

    init_gdt();

    TTY_LOG(null_handler, 25, 80);
}

#define noret attr(noreturn)

void null_handler(struct vt_t *vt) {}

void noret __stack_chk_fail(void) {

    vt_panic_nohlt(&term, "stack smashing detected! Sys hlted...");

    abort();

}

/*optional:
 * author:Pr09rammerali9
 * module:early_kmain.c
 * description:early entry after _start to init the kernel in a stable state
 * version:0.0.1
 * license:0BSD
 */
