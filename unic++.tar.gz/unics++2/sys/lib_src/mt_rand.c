#include <lib/rng.h>
#include <lib/compiler.h>
#include <lib/export.h>

#define MT19937_N 624
#define MT19937_M 397
#define MT19937_MATRIX_A 0x9908B0DFUL
#define MT19937_UPPER_MASK 0x80000000UL
#define MT19937_LOWER_MASK 0x7FFFFFFFUL
#define MT19937_TEMPERING_MASK_B 0x9D2C5680UL
#define MT19937_TEMPERING_MASK_C 0xEFC60000UL
#define MT19937_TEMPERING_SHIFT_U 11
#define MT19937_TEMPERING_SHIFT_S 7
#define MT19937_TEMPERING_SHIFT_T 15
#define MT19937_TEMPERING_SHIFT_L 18
#define MT19937_F 1812433253UL 


typedef struct {
    uint32_t mt_stat[MT19937_N];
 
    int mt_i;
} mt_stat;

static uint32_t mag0[2] = {0x0UL, MT19937_MATRIX_A};

static mt_stat *stat = NULL;

void mt_srand(unsigned seed) {

    stat->mt_stat[0] = (uint32_t)seed;

    for (stat->mt_i = 1; stat->mt_i < MT19937_N; stat->mt_i++) {
         
        stat->mt_stat[stat->mt_i] =  (MT19937_F * (stat->mt_stat[stat->mt_i - 1] ^ (stat->mt_stat[stat->mt_i - 1] >> 30)) + stat->mt_i);
        stat->mt_stat[stat->mt_i] &= 0xFFFFFFFFUL; 

    }

}

EXPORT(mt_rand);

static void mt_twist(void) {

    uint32_t y = 0;

    for (int kk = 0; kk < MT19937_N - MT19937_M; kk++) {

         y = (stat->mt_stat[kk] & MT19937_UPPER_MASK) | (stat->mt_stat[kk + 1] & MT19937_LOWER_MASK);

        stat->mt_stat[kk] = stat->mt_stat[kk + (MT19937_M - MT19937_N)] ^ (y >> 1) ^ mag0[y & 1UL];

    }

       y = (stat->mt_stat[MT19937_N - 1] & MT19937_UPPER_MASK) | (stat->mt_stat[0] & MT19937_LOWER_MASK);
    stat->mt_stat[MT19937_N - 1] = stat->mt_stat[MT19937_M - 1] ^ (y >> 1) ^ mag0[y & 0x1UL];

    stat->mt_i = 0;

}

unsigned long long mt_llrand(void) {

    if (stat->mt_i >= MT19937_N)
        mt_twist();

    uint32_t y = stat->mt_stat[stat->mt_i];

    y ^= (y >> MT19937_TEMPERING_SHIFT_U);
    y ^= (y << MT19937_TEMPERING_SHIFT_S) & MT19937_TEMPERING_MASK_B;
    y ^= (y << MT19937_TEMPERING_SHIFT_T) & MT19937_TEMPERING_MASK_C;
    y ^= (y >> MT19937_TEMPERING_SHIFT_L);

    return y;

}

EXPORT(mt_llrand);
