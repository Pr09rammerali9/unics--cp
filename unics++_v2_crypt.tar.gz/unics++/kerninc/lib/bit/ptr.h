#ifndef PTR_H
#define PTR_H 

typedef unsigned _BitInt(sizeof(void *) * 8) uintptr_t;
typedef _BitInt(sizeof(void *) * 8) intptr_t;

#endif // PTR_H
