#include "../../inc/lib/mod.h"
#include <lib/abort.h>

extern initfn __init_start[];
extern initfn __init_end[];
extern initfn __early_init_start[];
extern initfn __early_init_end[];
extern initfn __late_init_start[];
extern initfn __late_init_end[];

extern exitfn __exit_start[];
extern exitfn __exit_end[];

void kmain(void) {

    initfn cur_fn = __init_start;

    while (cur_fn != __init_end) {

        if ((*cur_fn)())
            abort();

        cur_fn++;

    }

    
}
