#include <lib/abort.h>
#include <lib/str.h>
#define SRC_IMPL
#include <sys/kern.h>
#include <lib/arg.h>
#include <asm/defs.h>

static char __kpanic_msg[PANICBUF_SZ] = { 0 };

[[noreturn]]
static void __kern_panic(const char *s) {

    __kpanic_msg = s;

    abort();

}

[[noreturn]]
static void __kern_panicf(const char *fmt,...) {

    va_list vl;

    va_start(vl, fmt);

    (void)vsprintf(__kpanic_msg, fmt, vl);

    va_end(vl);

    abort();

}

const __syskern_api syskern = {
    .panic = &__kern_panic,
    .panicfmt = &__kern_panicf
}
