#include <lib/arg.h>
#include <lib/atomic.h>
#define DB_SRC_IMPL
#include <sys/dbg.h>

const char* lvl_strings[] = {
    "LOG", "WARN", "DB", "ERR", "PANIC", "ALERT", "EMERG", "INFO"
};

int __sys_printdb(_BitInt(3) lvl, const char *file, const char *fmt, ...) {

    spinlock_t

    char line_buf[256];
    
    va_list args;
    
    int head_len = __builtin_snprintf(line_buf, sizeof(line_buf), "[%s][%s]: ", lvl_strings[(int)lvl], file);

    va_start(args, fmt);

    int body_len = __prdb_vscprf(line_buf + head_len, sizeof(line_buf) - head_len, fmt, args);

    va_end(args);

    __wrbufs(line_buf);

    if (lvl >= DBLVL_PANIC || __isbuf_full())
        __send_buf_full();

    return body_len + head_len;

}

static void __sys_klogf(const char *f) {
    
    va_list vl;

    va_start(vl);

    vscnprfmt(


const __sysdbg_ns sys_dbg = {
    .kprintdb = &__sys_printdb
};
