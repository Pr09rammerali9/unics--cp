#ifndef STDALIGN
#define STDALIGN

#define alignas _Alignas
#define alignof _Alignof
#define align(n) __attribute__((align(n)))

typedef union {
    long long ll;
    long double ld;
    void *p;
} max_align_t;

#endif
