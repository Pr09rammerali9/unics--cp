#ifndef ASSERT_H
#define ASSERT_H

#include "def.h"

#ifndef NDEBUG 

#define assert(expr, fn, ...) do {\
    if (!(expr)) {\
            fn(__VA_ARGS__); \
    } \
} while(0)
            
#endif

#endif
