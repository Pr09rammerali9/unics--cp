#include <lib/rng.h>
#include <lib/export.h>

static unsigned long long seed_num = 0;

void srand(unsigned seed) {

    seed_num = seed;

}

EXPORT(srand);

unsigned long long rand(void) {

    seed_num = 6364136223846793005ULL * seed_num + 1;

    return seed_num >> 33;

}

EXPORT(rand);
