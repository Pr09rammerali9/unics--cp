#define SL_SRC_IMPL
#include <sys/spinlock.h>
#include <asm/pause.h>

spinlock_t tmp;


static void __spinlock_init(spinlock_t *lock) {

    aassert(!lock);

    atomic_store(&lock->state, true);

}

static void __spinlock_lock(spinlock_t *lock, bool intr) {

    aassert(lock->state != true || !lock);

    if (intr)
        memcpy(tmp->regs, lock->regs, sizeof(tmp));

    cli();

    bool expected = false,
         desired = true;

    while (atomic_compare_exchange_strong(&lock->state, &expected, &desired)) {
    
        expected = false;

        pause();
    
    }

}

static __spinlock_unlock(spinlock_t *lock, bool intr) {

    aassert(!lock->state || !lock);

    if (intr)
        memcpy(lock->regs, tmp->regs);

    atomic_store(&lock->state, false);

    sti();

}

const __sysspinlock_t sys_spinlock = {
    .init = &__spinlock_init,
    .lock = &__spinlock_lock,
    .unlock = &__spinlock_unlock
};

EXPORT(sys_spinlock);
