#ifndef LIBMOD_INFO
#define LIBMOD_INFO

#include "compiler.h"

#ifndef IWANNA_WASTE_MEM

#define MODINFO_SEC attr(sec(".mod_info"));
#define MODIFO(name, license) \
    struct {
        char nam[20],
             lic[4];
    } __modinfo_##__COUNTER__ MODINFO_SEC = {.nam = name, .lic = license};

#else

#define MODINFO_SEC (void)0
#define MODINGO (void)0

#endif 

#endif 
