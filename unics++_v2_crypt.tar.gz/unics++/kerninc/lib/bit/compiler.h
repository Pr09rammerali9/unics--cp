#ifndef BIT_COMPILER_H
#define BIT_COMPILER_H

#ifdef __BYTE_ORDER__

#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__

#define BIGEND

#elif __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__

#define LILEND

#endif

#ifdef __CC65__

#define LILEND

#endif 

#ifdef __PCC__

#if __TARGET_ENDIANNES__ == __ORDER_BIG_ENDIAN__

#define BIGEND

#endif

#if __TARGET_ENDIANNES__ == __ORDER_LITTLE_ENDIAN__

#define LILEND 

#endif 

#endif

#if defined(__clang__) || defined(__GNUC__)

#define CHSZ sizeof(char) 
#define CHBIT CHAR_BIT
#define SHORT_BIT (__SIZEOF_SHORT__ * CHBIT)
#define SHORTSZ __SIZEOF_SHORT__
#define LNGSZ __SIZEOF_LONG__
#define LNGBIT (__SIZEOF_LONG__ * CHBIT)
#define LLSZ (sizeof(long long) * 8)
#define INTBIT (__SIZEOF_INT__ * 8)
#define INTSZ __SIZEOF_INT__
#define PTRSZ __SIZEOF_POINTER__
#define PTRBIT (__SIZEOF_POINTER__ * 8)
#define WORDSZ sizeof(unsigned long long int)
#define __sizeof_def 1 
#define char_bit_def 1 

typedef unsigned _BitInt(WORDSZ * 8) word_t;

#else

#define CHSZ sizeof(char)
#define CHBIT (sizeof(char) * 8)
#define SHORT_BIT (sizeof(short) * 8)
#define SHORTSZ sizeof(short)
#define LNGSZ sizeof(long)
#define LNGBIT (sizeof(long) * 8)
#define LLSZ sizeof(long long)
#define LLBIT (sizeof(long long) * 8)
#define INTBIT (sizeof(int) * 8)
#define INTSZ sizeof(int)
#define PTRSZ sizeof(void *)
#define PTRBIT (sizeof(void *) * 8)
#define WORDSIZE sizeof(unsigned long long int) 
#define __sizeof_def 0
#define char_bit_def 0

typedef unsigned _BitInt(WORDSIZE * 8) word_t;


#endif 

#ifdef __SHRT_MAX__

#define SHORTMAX __SHRT_MAX__

#endif 

#ifdef __INT_MAX__

#define INTMAX __INT_MAX__

#endif 

#ifdef __LONG_MAX__

#define LONGMAX __LONG_MAX__

#endif

#ifdef __LONG_LONG_MAX__

#define LONGLONGMAX __LONG_LONG_MAX__

#endif

#ifdef __CHAR_MAX__

#define CHMAX __CHAR_MAX__

#endif 

#ifdef __SCHAR_MAX__

#define SCHMAX __SCHAR_MAX__

#endif 

#endif 

#endif
