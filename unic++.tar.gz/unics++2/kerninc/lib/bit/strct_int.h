#ifndef STRCT_INT_H
#define STRCT_INT_H

#include "int.h"
#include "../compiler.h"

typedef struct __packed {
    uint4_t high;
    uint4_t low;
} strct_u8;

typedef struct __packed {
    strct_u8 high;
    strct_u8 low;
} strct_u16;

typedef struct __packed {
    strct_u16 high;
    strct_u16 low;
} strct_u32;

typedef struct __packed {
    strct_u32 high;
    strct_u32 low;
} strct_u64;

typedef struct __packed {
    strct_u64 high;
    strct_u64 low;
} strct_u128;

typedef struct __packed {
    strct_u128 high;
    strct_u128 low;
} strct_u256;

typedef struct __packed {
    strct_u256 high,
               low;
} strct_u512;

#endif
