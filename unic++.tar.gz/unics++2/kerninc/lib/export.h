#ifdef LEXPORT_H
#define LEXPORT_H 

#include "compiler.h"
#include "bit/ptr.h"

#define EXPORT_SEC __section(".symtbl")
#define priv static
#define pub

typedef struct {
    uintptr_t addr;

    char *name;
} kern_export;

#define EXPORT(sym) \
    extern typeof(sym) sym; \
    static const kern_export __ksym_#sym EXPORT_SEC = { \
    .addr = (uintptr_t)&sym, \
    .name = #sym \
    }  



#endif 
