#ifndef EFI_PART_H
#define EFI_PART_H

#include "../lib/bit/int.h"
#include "../lib/compiler.h"

#define EFI_PART 0xef
#define EXTRACT_UINT32(d) (uint32_t)(d[0] |(d[1] << 8) | (d[2] << 16) | (d[3] << 32))
#define MBR_SZ 512
#define MBR_SIG 0xaa55
#define MIN_MBR_DEV_SZ 0x8000
#define MBR_ERRATA_PAD 0x4000 //128MB

typedef struct __packed {
    uint8_t boot_indicator,
            strt_hd,
            strt_sect,
            strt_track,
            os_indicator,
            end_hd,
            end_sect,
            end_track,
            starting_lba[4],
            sz_in_lba[4];7
} mbr_part_rec;

typedef struct __packed {
    uint8_t boot_strap_cod[440],
            unique_boot_sig[4],
            unknown[2];

    mbr_part_rec part[4];

    uint16_t sig;
} mbr_t;

typedef mbr_t master_boot_rec;
#endif
