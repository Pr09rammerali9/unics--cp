#include <lib/rng.h>
#include <lib/assert.h>
#include <lib/export.h>

static void f(void) { for(;;); }


void read_u32_into(const uint8_t *src, size_t src_len, uint32_t *dst, size_t dst_len) {
    assert(src_len >= 4 * dst_len, f);

    for (size_t i = 0; i < dst_len; ++i) {

        size_t off = i * 4;

        dst[i] = (uint32_t)src[off] |
                 ((uint32_t)src[off + 1] << 8) |
                 ((uint32_t)src[off + 2] << 16) |
                 ((uint32_t)src[off + 3] << 24);

    }

}

EXPORT(read_u32_into);

void read_u64_into(const uint8_t *src, size_t src_len, uint64_t *dst, size_t dst_len) {

    assert(src_len >= 8 * dst_len, f);

    for (size_t i = 0; i < dst_len; ++i) {

        size_t off = i * 8;

        dst[i] = (uint64_t)src[off] |
                 ((uint64_t)src[off + 1] << 8) |
                 ((uint64_t)src[off + 2] << 16) |
                 ((uint64_t)src[off + 3] << 24) |
                 ((uint64_t)src[off + 4] << 32) |
                 ((uint64_t)src[off + 5] << 40) |
                 ((uint64_t)src[off + 6] << 48) |
                 ((uint64_t)src[off + 7] << 56);

    }

}

EXPORT(read_u64_into);
