#include <lib/str.h>
#include <lib/arg.h>
#include <lib/mem.h>
#include <lib/export.h>

static void utoa(long long val, char *sp, int rad, int upr) {

    char tmp[65] = { 0 };
    char *tp = tmp;

    unsigned long long uval = 0;

    int sign = 0;

    if (rad == 10 && val < 0) {

        sign = 1;

        uval = (unsigned long long)-val;

    } else 
        uval = (unsigned long long)val;

    if (!uval/* uval == 0*/)
        *tp++ = '0';
    else {

        while (uval > 0) {

            unsigned int dig = uval % rad;

            if (dig < 10)
                *tp++ = dig + '0';
            else
                *tp++ = dig + 10 + (upr ? 'A' : 'a');
            uval /= rad;

            }

    }

    if (sign)
        *tp++ = '-';

    *tp = '\0';

    tp--;

    while (tp >= tmp)
        *sp++ = *tp--;

    *sp = '\0';

}

void sprfmt(char *buf, const char fmt[], ...) {
    
    va_list ap;
    va_start(ap, fmt);

    char *bufp = buf;
    const char *fmtp = fmt;
    char itoa_tmp_buf[66] = { 0 };

    while (*fmtp) {

        if (*fmtp == '%') {

            fmtp++;

            switch (*fmtp) {
                case 's': {

                    char *s = va_arg(ap, char *);
                    
                    if (!s) {
                    
                        strcpy(bufp, "(null)");
                        
                        bufp += strlen("(null)");
                    
                    } else {
                    
                        strcpy(bufp, s);
                        
                        bufp += strlen(s);
                    
                    }
                    
                    break;
                }
                case 'd': {
                    long long val = va_arg(ap, long long);
                    
                    utoa(val, itoa_tmp_buf, 10, 0);
                    
                    strcpy(bufp, itoa_tmp_buf);
                    
                    bufp += strlen(itoa_tmp_buf);
                    
                    break;
                }
                case 'x': {
                    
                    unsigned long long val = va_arg(ap, unsigned long long);
                    
                    utoa((long long)val, itoa_tmp_buf, 16, 0);
                    
                    strcpy(bufp, itoa_tmp_buf);
                    
                    bufp += strlen(itoa_tmp_buf);
                    
                    break;
                }
                case 'o': {
                    unsigned long long val = va_arg(ap, unsigned long long);
                    
                    utoa((long long)val, itoa_tmp_buf, 8, 0);
                    
                    strcpy(bufp, itoa_tmp_buf);
                    
                    bufp += strlen(itoa_tmp_buf);
                    
                    break;
                }
                case 'c': {
                    
                    char c = (char)va_arg(ap, int);
                    *bufp++ = c;
                    
                    break;
                }
                case 'p': {
                    
                    void *p = va_arg(ap, void *);
                    *bufp++ = '0';
                    *bufp++ = 'x';
                    
                    utoa((long long)p, itoa_tmp_buf, 16, 0);
                    
                    strcpy(bufp, itoa_tmp_buf);
                    
                    bufp += strlen(itoa_tmp_buf);
                    
                    break;
                }
                
                case '%': {
                
                    *bufp++ = '%';
                    
                    break;
                }
                
                default: {
                
                    *bufp++ = '%';
                    *bufp++ = *fmtp;
                    
                    break;
                }
            
            }

            fmtp++;

        } else 
            *bufp++ = *fmtp++;

    }

    *bufp = '\0';

    va_end(ap);

}

EXPORT(sprfmt);
