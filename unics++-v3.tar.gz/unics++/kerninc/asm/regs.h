#ifndef _ASM_REGS_H
#define _ASM_REGS_H

#include <stddef.h>

#if defined(__x86_64__) || defined(__amd64__)
    typedef struct {
        size_t r15;
        size_t r14;
        size_t r13;
        size_t r12;
        size_t rbp;
        size_t rbx;
        size_t r11;
        size_t r10;
        size_t r9;
        size_t r8;
        size_t rax;
        size_t rcx;
        size_t rdx;
        size_t rsi;
        size_t rdi;
        size_t orig_rax;
        size_t rip;
        size_t cs;
        size_t eflags;
        size_t rsp;
        size_t ss;
    } asm_regs;

#elif defined(__i386__)

    typedef struct {
        size_t gs, fs, es, ds;
        size_t edi, esi, ebp, esp, ebx, edx, ecx, eax;
        size_t trapno, err;
        size_t eip, cs, eflags;
        size_t oldesp, ss;
    } asm_regs;

#elif defined(__aarch64__)

    typedef struct {
        size_t regs[31];
        size_t sp;
        size_t pc;
        size_t pstate;
    } asm_regs;

#elif defined(__arm__)

    typedef struct {
        size_t r[13];
        size_t sp;
        size_t lr;
        size_t pc;
        size_t cpsr;
    } asm_regs;

#elif defined(__mips__)

    typedef struct {
        size_t regs[32];
        size_t cp0_status;
        size_t cp0_cause;
        size_t cp0_epc;
    } asm_regs;

#elif defined(__riscv)

    typedef struct {
        size_t regs[31];
        size_t sepc;
        size_t sstatus;
    } asm_regs;

#elif defined(__pdp11__)

    typedef struct {
        size_t r[6];
        size_t sp;
        size_t pc;
        size_t psw;
    } asm_regs;

#elif defined(__65C816__)

    typedef struct {
        size_t a, x, y;
        size_t sp;
        size_t dp;
        size_t pbr;
        size_t pc;
        size_t psw;
    } asm_regs;

#else

    #error "asm_regs context frame is not defined for this architecture."

#endif

#endif
