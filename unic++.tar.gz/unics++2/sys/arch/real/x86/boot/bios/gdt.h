#ifndef GDT_H
#define GDT_H

#include <lib/bit/int.h>
#include <lib/bit/ops.h>

typedef uint64_t gdtd;

typedef struct {
    uint16_t limit;

    uint32_t base;
} gdt_ptr;

void init_gdt(void);

#endif
