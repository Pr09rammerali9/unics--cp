#include <lib/rng.h>
#include <lib/expect.h>
#include <lib/mem.h>


static inline void blk_rng_gen(blk_rng_t *rng) {

    rng->cor->gen(rng->cor->state, rng->ress);
    rng->i = 0;
}


void blk_rng_init(blk_rng_t *rng, blk_rng_cor_t *cor) {

    rng->cor = cor;
    rng->i = sizeof(rng->ress) / sizeof(rng->ress[0]);

}

EXPORT(blk_rng_init);

uint32_t blk_rng_nxt_u32(blk_rng_t *rng) {

    if (unexpected(rng->i >= sizeof(rng->ress) / sizeof(rng->ress[0])))
        blk_rng_gen(rng);

    uint32_t val = rng->ress[rng->i];

    rng->i++;

    return val;
}

EXPORT(blk_rng_nxt_u32);

uint64_t blk_rng_nxt_u64(blk_rng_t *rng) {

    size_t res_len = sizeof(rng->ress) / sizeof(rng->ress[0]),
           i = rng->i;

    if (unexpected(i >= res_len - 1)) {

        if (i >= res_len) {

            blk_rng_gen(rng);

            i = 0;

        } else {

            uint64_t x = rng->ress[res_len - 1],
                     y = rng->ress[0];

            blk_rng_gen(rng);

            rng->i = 1;

            return (y << 32) | x;

        }

    }

    uint64_t low = rng->ress[i],
             high = rng->ress[i + 1];

    rng->i += 2;

    return (high << 32) | low;

}

EXPORT(blk_rng_nxt_u64);

void blk_rng_fill_bytes(blk_rng_t *rng, uint8_t *dest, size_t len) {

    size_t off = 0;

    while (off < len) {

        if (unexpected(rng->i >= sizeof(rng->ress) / sizeof(rng->ress[0])))
            blk_rng_gen(rng);

        size_t avail_u32 = (sizeof(rng->ress) / sizeof(rng->ress[0])) - rng->i;
        size_t bytes_to_cp = avail_u32 * sizeof(uint32_t);
        size_t rem = len - off,
               cp_len = (bytes_to_cp < rem) ? bytes_to_cp : rem;

        memcpy(dest + off, rng->ress + rng->i, cp_len);

        rng->i += cp_len / sizeof(uint32_t);

        off += cp_len;

    }

}

EXPORT(blk_rng_fill_bytes);

static inline void blk_rng_64_gen(blk_rng_64_t *rng) {

    rng->cor->gen(rng->cor->state, rng->ress);
    rng->i = 0;
    rng->half_used = false;

}


void blk_rng_64_init(blk_rng_64_t *rng, blk_rng_cor_t *cor) {

    rng->cor = cor;
    rng->i = sizeof(rng->ress) / sizeof(rng->ress[0]);
    rng->half_used = false;

}

EXPORT(blk_rng_64_init);

uint32_t blk_rng_64_nxt_u32(blk_rng_64_t *rng) {

    size_t res_len = sizeof(rng->ress) / sizeof(rng->ress[0]);
    size_t i = rng->i - (size_t)rng->half_used;

    if (unexpected(i >= res_len)) {

        blk_rng_64_gen(rng);

        i = 0;

    }

    uint64_t val = rng->ress[i];
    uint32_t res = 0;

    if (rng->half_used) {

        res = (uint32_t)(val >> 32);

        rng->half_used = false;
        rng->i++;

    } else {

        res = (uint32_t)val;

        rng->half_used = true;

    }

    return res;

}

EXPORT(blk_rng_64_nxt_u32);

uint64_t blk_rng_64_nxt_u64(blk_rng_64_t *rng) {

    if (unexpected(rng->i >= sizeof(rng->ress) / sizeof(rng->ress[0])))
            blk_rng_64_gen(rng);

    uint64_t val = rng->ress[rng->i];

    rng->i++;

    rng->half_used = false;

    return val;

}

EXPORT(blk_rng_64_nxt_u64);

void blk_rng_64_fill_bytes(blk_rng_64_t *rng, uint8_t *dest, size_t len) {

    size_t off = 0;

    rng->half_used = false;

    while (off < len) {

        if (unexpected(rng->i >= sizeof(rng->ress) / sizeof(rng->ress[0])))
            blk_rng_64_gen(rng);

        size_t avail_u64 = (sizeof(rng->ress) / sizeof(rng->ress[0])) - rng->i,
               bytes_to_cp = avail_u64 * sizeof(uint64_t),
               rem = len - off,
               cp_len = (bytes_to_cp < rem) ? bytes_to_cp : rem;

        memcpy(dest + off, rng->ress + rng->i, cp_len);

        rng->i += cp_len / sizeof(uint64_t);

        off += cp_len;

    }

}

EXPORT(blk_rng_64_fill_bytes);
