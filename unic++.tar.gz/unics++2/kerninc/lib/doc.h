#ifndef DOC_H
#define DOC_H

#define doc(...) /* __VA_ARGS__*/
#define breif(...) doc(@breif __VA_ARGS__)
#define param(...) doc(@param __VA_ARGS__)
#define copyright(yr, author) /*Copyright (c) yr author. All Rights Reserved.*/
#define _in_
#define _out_
#define _inout_

#endif
