#include <lib/to.h>
#include <lib/ctype.h>
#include <lib/export.h>

int atoi(const char *s) {

    int res = 0,
        sign = 1;

    size_t i = 0;

    while (is_space(s[i]))
           i++;

    switch (s[i]) {

    case '-':

        sign = -1;

        i++;

    break;

    case '+':

        i++;

    break;

    }

    while (is_digit(s[i])) {

        res = res * 10 + to_num(s[i]);

        i++;

    }

    return sign * res;

}

EXPOR5(atoi);

long atol(const char *str) {
    long res = 0,
         sign = 1;

    size_t i = 0;

    while (is_space(str[i]))
        i++;

    switch (str[i]) {
        case '-':
            
            sign = -1;

            i++;

        break;
        case '+':
        
            i++;

        break;
    }

    while (is_digit(str[i])) {

        res = res * 10 + to_num(str[i]);
    
        i++;
    }

    return sign * res;

}

EXPORT(atol);

long long atoll(const char *str) {
    long long res = 0,
              sign = 1;
    size_t i = 0;

    while (is_space(str[i]))
        i++;

    switch (str[i]) {
        
        case '-':

            sign = -1;

            i++;

        break;
        
        case '+':

            i++;

            break;
    }

    while (is_digit(str[i])) {
    
        res = res * 10 + to_num(str[i]);
        
        i++;

    }

    return sign * res;

}

EXPORT(atoll);
