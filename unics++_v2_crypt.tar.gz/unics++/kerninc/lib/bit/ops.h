#ifndef OPS_H
#define OPS_H

//sense were not including int.h or stdint.h we will use unsigned long long
#define GET_BIT(reg, bit) (((reg) >> (bit)) & 1)
#define SET_BIT(reg, bit) ((reg) |= (1ULL << (bit)))
#define CLRBIT(reg, bit) ((reg) &= ~(1ULL << (bit)))
#define TOGBIT(val, pos) ((val) ^ (1ULL << (pos)))
#define TOGBIT_s(val, pos) (((pos) >= (sizeof(unsigned long long) * 8)) ? (val) : TOGBIT(val, pos))
#define CHK_ALL_BITS(val, msk) (((val) & (msk)) == (msk))
#define CHK_ANY_BIT(val, msk) (((val) & (msk)) != 0ULL)
#define COUNT_SET_BITS(val) ((unsigned int)__builtin_popcountll((val)))
#define CLR_MSKED_BITS(val, msk) ((val) & ~(msk))
#define ST_MSKED_BITS(val, msk) ((val) | (msk))
#define EXTRACT_BITS(val, start_pos, len)  (((val) >> (start_pos)) & ((1ULL << (len)) - 1ULL))
#define EXTRACT_BITS_s(val, start_pos, len)  ((((start_pos) + (len)) > (sizeof(unsigned long long) * 8) || (len) == 0) \
     ? 0ULL \
     : (((val) >> (start_pos)) & ((1ULL << (len)) - 1ULL)))
#define INSERT_BITS(val, fval, start_pos, len)  (((val) & ~(((1ULL << (len)) - 1ULL) << (start_pos))) | (((fval) & ((1ULL << (len)) - 1ULL)) << (start_pos)))
#define INSERT_BITS_s(val, fvalue, start_pos, len) ((((start_pos) + (len)) > (sizeof(unsigned long long) * 8) || (len) == 0) \
     ? (val) \
     : INSERT_BITS(val, fvalue, start_pos, len))
#define ROTATE_LEFT(val, sc) (((val) << (sc)) | ((val) >> (sizeof(val) * 8 - (sc))))
#define ROTATE_RIGHT(val, sc) (((val) >> (sc)) | ((val) << (sizeof(val) * 8 - (sc))))

#endif
